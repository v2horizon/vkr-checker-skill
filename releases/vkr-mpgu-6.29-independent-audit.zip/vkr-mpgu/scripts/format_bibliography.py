#!/usr/bin/env python3
"""
Форматирование списка литературы по ГОСТ Р 7.0.5-2008 / 7.0.100-2018
с учётом требований методички МПГУ.

Принимает JSON/YAML со списком источников, возвращает отформатированный
список литературы.

Использование:
    python format_bibliography.py sources.json
    python format_bibliography.py sources.json --output bibliography.txt
    python format_bibliography.py sources.json --output bibliography.docx
"""

import sys
import json
import argparse
from pathlib import Path


# ========== ФОРМАТИРОВАНИЕ РАЗНЫХ ТИПОВ ИСТОЧНИКОВ ==========

def format_authors_for_title(authors: list) -> str:
    """
    Фамилия, И.О. (для первого автора в заголовке записи).
    Если нет авторов или их 4+, возвращает пустую строку.
    """
    if not authors or len(authors) >= 4:
        return ""
    first = authors[0]
    return f"{first['last']}, {first['initials']}"


def format_authors_after_slash(authors: list) -> str:
    """
    И.О. Фамилия, И.О. Фамилия (после слэша в сведениях об ответственности).
    """
    if not authors:
        return ""
    parts = []
    for a in authors:
        parts.append(f"{a['initials']} {a['last']}")
    return ", ".join(parts)


def _is_cyrillic_source(src: dict) -> bool:
    """Определяет, является ли источник кириллическим (по первому автору или названию)."""
    authors = src.get("authors", [])
    if authors:
        first_char = authors[0].get("last", "")[:1].lower()
    else:
        first_char = src.get("title", "")[:1].lower()
    return 'а' <= first_char <= 'я' or first_char == 'ё'


def _join_parts(parts: list) -> str:
    """Объединяет части записи через '. – ', избегая двойных точек."""
    # Убираем финальные точки из каждой части (они появятся от join)
    cleaned = [p.rstrip(".").rstrip() for p in parts if p]
    return ". – ".join(cleaned) + "."


def format_book(src: dict) -> str:
    """
    Книга:
    Фамилия, И.О. Название [Текст] / И.О. Фамилия. – Место: Изд-во, Год. – Страниц с.
    """
    authors = src.get("authors", [])
    title = src["title"]
    subtitle = src.get("subtitle", "")
    place = src.get("place", "Б.м.")
    publisher = src.get("publisher", "Б.и.")
    year = src.get("year", "")
    pages = src.get("pages", "")
    edition = src.get("edition", "")
    translation = src.get("translation", "")

    is_ru = _is_cyrillic_source(src)
    text_marker = " [Текст]" if is_ru else ""
    pages_marker = "с." if is_ru else "p."

    full_title = title
    if subtitle:
        full_title += f": {subtitle}"
    full_title += text_marker

    header = format_authors_for_title(authors)

    parts = []
    if header:
        parts.append(f"{header} {full_title}")
    else:
        parts.append(full_title)

    # Сведения об ответственности
    if authors:
        parts[-1] += f" / {format_authors_after_slash(authors)}"

    if translation:
        parts[-1] += f"; {translation}"

    if edition:
        parts.append(edition)

    # Выходные данные
    parts.append(f"{place}: {publisher}, {year}")

    if pages:
        parts.append(f"{pages} {pages_marker}")

    return _join_parts(parts)


def format_article(src: dict) -> str:
    """
    Статья в журнале:
    Фамилия, И.О. Название [Текст] / И.О. Фамилия // Журнал. – Год. – № N. – С. X–Y.
    """
    authors = src.get("authors", [])
    title = src["title"]
    journal = src["journal"]
    year = src.get("year", "")
    volume = src.get("volume", "")
    number = src.get("number", "")
    pages = src.get("pages", "")
    doi = src.get("doi", "")

    is_ru = _is_cyrillic_source(src)
    text_marker = " [Текст]" if is_ru else ""
    pages_label = "С." if is_ru else "P."
    vol_label = "Т." if is_ru else "Vol."
    num_label = "№" if is_ru else "No."

    header = format_authors_for_title(authors)

    parts = []
    if header:
        parts.append(f"{header} {title}{text_marker}")
    else:
        parts.append(f"{title}{text_marker}")

    if authors:
        parts[-1] += f" / {format_authors_after_slash(authors)}"

    parts[-1] += f" // {journal}"

    if year:
        parts.append(str(year))

    # Том и/или номер
    vol_num = []
    if volume:
        vol_num.append(f"{vol_label} {volume}")
    if number:
        vol_num.append(f"{num_label} {number}")
    if vol_num:
        parts.append(", ".join(vol_num))

    # Страницы
    if pages:
        pages_formatted = pages.replace("-", "–")
        parts.append(f"{pages_label} {pages_formatted}")

    result = _join_parts(parts)

    if doi:
        result = result[:-1] + f". – DOI: {doi}."

    return result


def format_electronic(src: dict) -> str:
    """
    Электронный ресурс:
    Фамилия, И.О. Название [Электронный ресурс] / И.О. Фамилия. – URL: ... (дата обращения: ДД.ММ.ГГГГ).
    """
    authors = src.get("authors", [])
    title = src["title"]
    place = src.get("place", "")
    year = src.get("year", "")
    url = src["url"]
    access_date = src.get("access_date", "")
    journal = src.get("journal", "")

    header = format_authors_for_title(authors)

    parts = []
    if header:
        parts.append(f"{header} {title} [Электронный ресурс]")
    else:
        parts.append(f"{title} [Электронный ресурс]")

    if authors:
        parts[-1] += f" / {format_authors_after_slash(authors)}"

    if journal:
        parts[-1] += f" // {journal}"

    if place or year:
        loc_year = []
        if place:
            loc_year.append(place)
        if year:
            loc_year.append(str(year))
        parts.append(", ".join(loc_year))

    parts.append(f"URL: {url}")

    if access_date:
        parts[-1] += f" (дата обращения: {access_date})"

    return _join_parts(parts)


def format_dissertation(src: dict) -> str:
    """
    Диссертация:
    Фамилия, И.О. Название: Дис. ... д-ра [науки] наук [Текст] / И.О. Фамилия. – Место: Организация, Год. – Страниц с.
    """
    authors = src.get("authors", [])
    title = src["title"]
    # Два способа задать тип диссертации:
    # (а) готовой строкой thesis_type = "Дис. … д-ра филол. наук"
    # (б) компонентами degree + field + is_autoref
    thesis_type = src.get("thesis_type", "")
    degree = src.get("degree", "канд.")  # "канд." или "д-ра"
    field = src.get("field", "пед.")  # "пед.", "филол.", "психол.", "техн." и т.п.
    place = src.get("place", "Б.м.")
    organization = src.get("organization", "") or src.get("publisher", "")
    year = src.get("year", "")
    pages = src.get("pages", "")
    is_autoref = src.get("is_autoref", False)

    if thesis_type:
        doc_type = thesis_type
    else:
        # Если degree уже содержит полную формулировку «... наук» — используем её целиком,
        # не дописываем field + «наук» (иначе получается «канд. техн. наук пед. наук»)
        if "наук" in degree.lower():
            doc_type = f"автореф. дис. … {degree}" if is_autoref else f"Дис. … {degree}"
        else:
            doc_type = f"автореф. дис. … {degree} {field} наук" if is_autoref else f"Дис. … {degree} {field} наук"

    header = format_authors_for_title(authors)

    parts = []
    parts.append(f"{header} {title}: {doc_type} [Текст]")

    if authors:
        parts[-1] += f" / {format_authors_after_slash(authors)}"

    # Выходные данные: Место: Организация, Год
    if organization:
        imprint = f"{place}: {organization}"
    else:
        imprint = place
    if year:
        imprint += f", {year}"
    parts.append(imprint)

    if pages:
        parts.append(f"{pages} с.")

    return _join_parts(parts)


def format_normative(src: dict) -> str:
    """
    Нормативный документ (закон, приказ, ГОСТ):
    Название: тип-акта от ДД.ММ.ГГГГ № N [Текст]. – Источник.
    """
    title = src["title"]
    doc_type = src.get("doc_type", "")
    number = src.get("number", "")
    date = src.get("date", "")
    source_info = src.get("source", "")

    parts = [f"{title} [Текст]"]

    if doc_type and date and number:
        parts[-1] += f": {doc_type} от {date} № {number}"
    elif doc_type:
        parts[-1] += f": {doc_type}"

    if source_info:
        parts.append(source_info)

    return _join_parts(parts)


def format_source(src: dict) -> str:
    """Главный диспетчер: вызывает нужный форматтер по типу источника."""
    src_type = src.get("type", "book")
    # Алиасы типов — принимаем альтернативные названия
    type_aliases = {
        "thesis": "dissertation",
        "дисс": "dissertation",
        "диссертация": "dissertation",
        "web": "electronic",
        "online": "electronic",
        "internet": "electronic",
        "url": "electronic",
        "электронный": "electronic",
        "электронный_ресурс": "electronic",
        "нормативный": "normative",
        "закон": "normative",
        "статья": "article",
        "книга": "book",
    }
    src_type = type_aliases.get(src_type, src_type)

    formatters = {
        "book": format_book,
        "article": format_article,
        "electronic": format_electronic,
        "dissertation": format_dissertation,
        "normative": format_normative,
    }
    formatter = formatters.get(src_type)
    if formatter is None:
        # Неизвестный тип — предупреждаем и используем format_book как fallback,
        # но с явным сообщением в stderr, чтобы пользователь не пропустил
        import sys
        print(
            f"⚠️  Неизвестный тип источника «{src.get('type', '?')}» (алиасы: thesis/dissertation, "
            f"web/internet/online/electronic, article, book, normative). "
            f"Использую format_book как fallback — URL и маркер [Электронный ресурс] "
            f"могут быть потеряны! Источник: «{src.get('title', '?')[:60]}»",
            file=sys.stderr
        )
        formatter = format_book
    return formatter(src)


# ========== ГРУППИРОВКА И СОРТИРОВКА ==========

def get_sort_key(src: dict) -> tuple:
    """Ключ для сортировки: тип + язык + первое слово.

    v6.25: надёжность на edge-кейсах — если authors пришли строками (не dict),
    get_sort_key раньше падал с AttributeError. Теперь graceful degrade
    до пустого ключа.
    """
    # Приоритет: нормативные → русские → иностранные
    src_type = src.get("type", "book")
    type_order = {"normative": 0}.get(src_type, 1)

    def _first_letter_of(author):
        # Защита от строк вместо dict (если normalize не был вызван)
        if isinstance(author, dict):
            return author.get("last", "")[:1].lower()
        if isinstance(author, str):
            return author.strip()[:1].lower()
        return ""

    # Язык (по первому автору)
    authors = src.get("authors", [])
    if authors:
        first_letter = _first_letter_of(authors[0])
    else:
        first_letter = src.get("title", "")[:1].lower()
    is_cyrillic = 'а' <= first_letter <= 'я' or first_letter == 'ё'

    lang_order = 0 if is_cyrillic else 1

    # Ключ алфавита
    if authors:
        a0 = authors[0]
        alpha_key = (a0.get("last", "") if isinstance(a0, dict) else str(a0)).lower()
    else:
        alpha_key = src.get("title", "").lower()

    return (type_order, lang_order, alpha_key)


def format_bibliography(sources: list, preserve_ids: bool = False) -> tuple:
    """Форматирует список источников в ГОСТ-формат.

    Если preserve_ids=False (по умолчанию): сортирует по алфавиту
    (русские → иностранные, внутри по автору/названию) и перенумеровывает.
    ВАЖНО: возвращает также маппинг old_id → new_id, чтобы пользователь
    мог обновить ссылки [N] в тексте работы.

    Если preserve_ids=True: сохраняет исходный порядок и id, ничего не
    перенумеровывает. Используется когда пользователь сам отсортировал
    список и не хочет автосортировки.

    Возвращает (formatted_text, id_mapping), где id_mapping — dict
    {old_id: new_id} если сортировка изменила порядок, иначе {}.
    """
    # Сохраняем исходный id (если есть) — для маппинга
    for i, src in enumerate(sources):
        if "_orig_id" not in src:
            src["_orig_id"] = src.get("id", i + 1)

    if preserve_ids:
        # Сохраняем исходный порядок
        ordered = list(sources)
    else:
        ordered = sorted(sources, key=get_sort_key)

    id_mapping = {}
    lines = []
    for new_i, src in enumerate(ordered, 1):
        old_id = src["_orig_id"]
        if old_id != new_i:
            id_mapping[old_id] = new_i
        formatted = format_source(src)
        lines.append(f"{new_i}. {formatted}")

    return "\n\n".join(lines), id_mapping


# ========== I/O ==========

def load_sources(path: Path) -> list:
    """Загрузить источники из JSON или YAML."""
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".yaml" or path.suffix.lower() == ".yml":
        try:
            import yaml
        except ImportError:
            print("ERROR: pyyaml не установлен. pip install pyyaml")
            sys.exit(1)
        return yaml.safe_load(text)
    else:
        return json.loads(text)


# ========== НОРМАЛИЗАЦИЯ ВХОДНЫХ ДАННЫХ (v6.12) ==========
# Пользователи пишут JSON по-разному. Принимаем распространённые варианты,
# а при неизвестном формате — падаем с понятным сообщением.

def normalize_input_data(data):
    """Принять либо массив источников, либо {"sources": [...]} или {"items": [...]}.

    Возвращает список источников. Падает с понятным сообщением, если формат
    не распознан.
    """
    if isinstance(data, list):
        sources = data
    elif isinstance(data, dict):
        # Частые обёртки: {"sources": [...]}, {"items": [...]}, {"bibliography": [...]}
        for key in ("sources", "items", "bibliography", "refs", "references", "данные"):
            if key in data and isinstance(data[key], list):
                sources = data[key]
                break
        else:
            raise ValueError(
                "Неподдерживаемый формат JSON. Ожидается один из вариантов:\n"
                "  1) Массив источников на верхнем уровне: [{...}, {...}, ...]\n"
                "  2) Объект с ключом 'sources': {\"sources\": [{...}, ...]}\n"
                "  3) Или ключ 'items' / 'bibliography' / 'refs' / 'references'\n"
                f"Получено: dict с ключами {list(data.keys())}"
            )
    else:
        raise ValueError(
            f"Неподдерживаемый тип входных данных: {type(data).__name__}. "
            "Ожидается list или dict."
        )

    # Нормализуем каждый источник
    return [normalize_source(src, i) for i, src in enumerate(sources, 1)]


# Алиасы полей — распространённые синонимы, которые встречаются в JSON пользователей
FIELD_ALIASES = {
    "city": "place",
    "город": "place",
    "место": "place",
    "issue": "number",
    "номер": "number",
    "выпуск": "number",
    "pages_range": "pages",
    "pages_total": "pages",
    "страницы": "pages",
    "стр": "pages",
    "name": "title",
    "название": "title",
    "год": "year",
    "автор": "authors",
    "авторы": "authors",
    "journal_name": "journal",
    "журнал": "journal",
    # Для электронных ресурсов
    "ссылка": "url",
    "link": "url",
    "accessed": "access_date",
    "дата_обращения": "access_date",
    "accessed_date": "access_date",
    "container": "journal",
    "контейнер": "journal",
    "платформа": "journal",
    # Для диссертаций
    "thesis_type": "thesis_type",
    "тип_диссертации": "thesis_type",
}


def normalize_source(src, idx):
    """Нормализует один источник. Принимает алиасы полей и разные форматы authors."""
    if not isinstance(src, dict):
        raise ValueError(
            f"Источник #{idx}: ожидается объект (dict), получено {type(src).__name__}. "
            f"Значение: {src!r}"
        )

    # Применяем алиасы
    normalized = {}
    for key, val in src.items():
        canonical = FIELD_ALIASES.get(key, key)
        # Если каноническое поле уже занято — не затираем (приоритет исходного имени)
        if canonical not in normalized:
            normalized[canonical] = val

    # Нормализуем authors
    if "authors" in normalized:
        normalized["authors"] = normalize_authors(normalized["authors"], idx)

    return normalized


def normalize_authors(authors, idx):
    """Принимает authors как список строк или список словарей.

    Строка "Иванов А.Б." → {"last": "Иванов", "initials": "А.Б."}
    Строка "А.Б. Иванов" → тоже распознаётся
    Словарь {"last": ..., "initials": ...} → как есть
    """
    if authors is None:
        return []
    if isinstance(authors, str):
        # Одна строка вместо списка — тоже принимаем
        authors = [authors]
    if not isinstance(authors, list):
        raise ValueError(
            f"Источник #{idx}: поле 'authors' должно быть списком, получено {type(authors).__name__}"
        )

    result = []
    for i, author in enumerate(authors, 1):
        if isinstance(author, dict):
            # Уже в канонической форме
            result.append(author)
        elif isinstance(author, str):
            # Парсим "Иванов А.Б." или "А.Б. Иванов"
            parsed = _parse_author_string(author)
            if parsed is None:
                raise ValueError(
                    f"Источник #{idx}, автор #{i}: не могу распарсить строку «{author}». "
                    f"Ожидается формат «Фамилия И.О.» или «И.О. Фамилия», либо "
                    f"объект {{\"last\": \"Фамилия\", \"initials\": \"И.О.\"}}"
                )
            result.append(parsed)
        else:
            raise ValueError(
                f"Источник #{idx}, автор #{i}: ожидается строка или объект, "
                f"получено {type(author).__name__}: {author!r}"
            )
    return result


def _parse_author_string(s: str):
    """Парсит «Иванов А.Б.» или «А.Б. Иванов» в {last, initials}.

    Возвращает None, если не распознаётся.
    """
    import re as _re
    s = s.strip()
    # Вариант 1: Фамилия И.О. или Фамилия И.
    m = _re.match(r"^([А-ЯЁа-яёA-Za-z\-]+)\s+([А-ЯЁA-Z]\.(?:[А-ЯЁA-Z]\.)?)\s*$", s)
    if m:
        return {"last": m.group(1), "initials": m.group(2)}
    # Вариант 2: И.О. Фамилия или И. Фамилия
    m = _re.match(r"^([А-ЯЁA-Z]\.(?:[А-ЯЁA-Z]\.)?)\s+([А-ЯЁа-яёA-Za-z\-]+)\s*$", s)
    if m:
        return {"last": m.group(2), "initials": m.group(1)}
    # Вариант 3: только фамилия (одно слово) — частный случай
    m = _re.match(r"^([А-ЯЁа-яёA-Za-z\-]+)\s*$", s)
    if m:
        return {"last": m.group(1), "initials": ""}
    # Вариант 4: коллективный автор — многословное название без инициалов
    # (организации, ассоциации, госорганы — ГОСТ Р 7.0.100-2018 их допускает).
    # Маркер: нет регэкспа инициалов «Х.Х.», есть буквы, может быть несколько слов.
    if _re.search(r"[А-ЯЁа-яёA-Za-z]", s) and not _re.search(r"\b[А-ЯЁA-Z]\.", s):
        return {"last": s, "initials": "", "is_organization": True}
    return None


def save_as_docx(text: str, output_path: Path):
    """Сохранить список в .docx со стилями МПГУ."""
    try:
        from docx import Document
        from docx.shared import Pt, Mm, Cm, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    except ImportError:
        print("ERROR: python-docx не установлен. pip install python-docx")
        sys.exit(1)

    doc = Document()

    # Поля по МПГУ
    for section in doc.sections:
        section.top_margin = Mm(20)
        section.bottom_margin = Mm(20)
        section.left_margin = Mm(35)
        section.right_margin = Mm(10)

    # Стиль
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(14)
    style.font.color.rgb = RGBColor(0, 0, 0)
    style.paragraph_format.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE

    # Заголовок
    heading = doc.add_paragraph()
    heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = heading.add_run("Список использованной литературы")
    run.bold = True
    run.font.size = Pt(14)

    doc.add_paragraph()  # отступ

    # Записи
    for block in text.split("\n\n"):
        p = doc.add_paragraph(block)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.first_line_indent = Cm(0)  # Для списка литературы обычно без красной строки
        # Висячий отступ — чтобы номер выделялся
        p.paragraph_format.left_indent = Cm(0.5)
        p.paragraph_format.first_line_indent = Cm(-0.5)

    doc.save(output_path)
    print(f"✅ Сохранено: {output_path}")


# ========== MAIN ==========

def main():
    parser = argparse.ArgumentParser(
        description="Форматирование списка литературы по ГОСТ (МПГУ)"
    )
    parser.add_argument("sources_file", help="JSON или YAML файл со списком источников")
    parser.add_argument("--output", "-o", help="Путь к выходному файлу (.txt или .docx)")
    parser.add_argument(
        "--preserve-ids",
        action="store_true",
        help="Сохранить исходный порядок источников и их id (не сортировать)."
    )
    parser.add_argument(
        "--mapping",
        help="Путь к JSON-файлу, куда записать маппинг {старый_id: новый_id}. "
             "Полезно для автообновления ссылок [N] в тексте работы."
    )
    args = parser.parse_args()

    src_path = Path(args.sources_file)
    if not src_path.exists():
        print(f"❌ Файл не найден: {src_path}")
        sys.exit(1)

    sources_raw = load_sources(src_path)
    try:
        sources = normalize_input_data(sources_raw)
    except ValueError as e:
        print(f"❌ ОШИБКА во входном файле {src_path}:", file=sys.stderr)
        print(f"   {e}", file=sys.stderr)
        sys.exit(1)

    text, id_mapping = format_bibliography(sources, preserve_ids=args.preserve_ids)

    # КРИТИЧНО: если id изменились — ярко предупреждаем
    if id_mapping:
        print("=" * 70, file=sys.stderr)
        print("⚠️  ВНИМАНИЕ: сортировка ИЗМЕНИЛА номера источников!", file=sys.stderr)
        print("    Ссылки [N] в твоём тексте работы больше НЕ указывают", file=sys.stderr)
        print("    на правильные источники. Маппинг (старый → новый):", file=sys.stderr)
        for old, new in sorted(id_mapping.items()):
            print(f"      [{old}] → [{new}]", file=sys.stderr)
        print("", file=sys.stderr)
        print("    ЧТО ДЕЛАТЬ:", file=sys.stderr)
        print("    1. Пройди по тексту ВКР и обнови номера ссылок по маппингу.", file=sys.stderr)
        print("    2. После этого обязательно прогони:", file=sys.stderr)
        print("       python scripts/validate_vkr.py vkr.docx", file=sys.stderr)
        print("       (раздел «Соответствие ссылок и списка литературы»)", file=sys.stderr)
        print("    3. Альтернатива: используй --preserve-ids, чтобы оставить", file=sys.stderr)
        print("       исходный порядок и не трогать ссылки в тексте.", file=sys.stderr)
        print("=" * 70, file=sys.stderr)

    if not args.output:
        print(text)
    else:
        out_path = Path(args.output)
        if out_path.suffix.lower() == ".docx":
            save_as_docx(text, out_path)
        else:
            out_path.write_text(text, encoding="utf-8")
            print(f"✅ Сохранено: {out_path}")

    # Сохраняем маппинг в отдельный файл, если запрошен
    if args.mapping:
        mapping_path = Path(args.mapping)
        mapping_path.write_text(
            json.dumps(id_mapping, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        print(f"📝 Маппинг id сохранён: {mapping_path}")


if __name__ == "__main__":
    main()
