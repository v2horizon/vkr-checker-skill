#!/usr/bin/env python3
"""
content_ownership_check.py — Генератор вопросов комиссии по тексту ВКР.

Главная проблема LLM-ассистированных работ: студент не владеет собственным
текстом. На защите комиссия задаёт 3-5 вопросов по конкретным абзацам —
и если студент не может обосновать написанное, оценка снижена или защита
отложена.

Этот скрипт решает именно эту проблему:
1. Извлекает абзацы из ВКР
2. Для каждого абзаца формулирует 2-3 типичных вопроса комиссии
3. Студент проходит по ним до защиты и тренирует ответы

Использование:
    python content_ownership_check.py vkr.docx                  # все главы
    python content_ownership_check.py vkr.docx --section chapter3
    python content_ownership_check.py vkr.docx --sample 20       # 20 случайных
    python content_ownership_check.py vkr.docx --json

Цель — не формальная оценка, а подготовка к защите через самопроверку.
"""

import sys
import argparse
import json
import re
import random
from pathlib import Path

try:
    from docx import Document
except ImportError:
    print("ERROR: python-docx не установлен. pip install python-docx")
    sys.exit(1)


# ========== ШАБЛОНЫ ВОПРОСОВ ==========

# Паттерны, которые срабатывают на определённые конструкции в тексте.
# Каждый паттерн → набор вопросов.
QUESTION_PATTERNS = [
    {
        # Конкретное решение / выбор технологии — только в главах 2-3,
        # где реально обсуждаются выборы. В аннотации/введении/заключении
        # слова «использован», «реализован» — обзорные, не про выбор.
        "markers": [
            r"\bвыбран(а|о|ы)?\b",
            r"\bреализован(а|о|ы)?\b",
            r"\bиспользован(а|о|ы)?\b",
            r"\bприменён(а|о|ы)?\b",
            r"\bисходя из\b",
        ],
        "questions": [
            "Почему вы выбрали именно {X}, а не альтернативу?",
            "Какие альтернативы рассматривались? Какие оставили и почему отвергли?",
            "Что было бы, если бы использовали другой подход?",
        ],
        "category": "technology-choice",
        "applicable_sections": {"chapter2", "chapter3"},
    },
    {
        # Цифровые утверждения — в аннотации/содержании числа это объём/номера,
        # в заключении — итоговые метрики. Вопросы про выборку/погрешность
        # уместны только в главах 2-3, где приводятся результаты.
        "markers": [
            r"\b\d{1,3}[%]",
            r"\bоколо \d+\b",
            r"\bболее \d+\b",
            r"\bменее \d+\b",
            r"\bсоставляет \d+\b",
            r"\bсоставил[аи]? \d+\b",
        ],
        "questions": [
            "Откуда взята эта цифра? Какой источник?",
            "Как методологически измерялось? Какая выборка?",
            "Какая погрешность в этих данных?",
        ],
        "category": "quantitative-claim",
        "applicable_sections": {"chapter1", "chapter2", "chapter3"},
    },
    {
        # Метод / методология
        "markers": [
            r"\b(выбран|применён|использ\w+|реализован|предложен)\w*\s+\w*\s*(метод|подход|алгоритм|методолог)\w*\b",
            r"\b(метод|подход|алгоритм|методолог)\w*\s+\w*\s*(был|являлся|лёг в основу|применялся|использовался)\b",
            r"\bв качестве\s+\w*\s*(метод|подход|алгоритм|методолог)\w*\b",
        ],
        "questions": [
            "Расшифруйте, как этот метод работает пошагово",
            "Какие ограничения у этого метода?",
            "В каких случаях этот метод неприменим?",
        ],
        "category": "methodology",
        "applicable_sections": {"chapter1", "chapter2", "chapter3"},
    },
    {
        # Ссылки на авторов / источники — всегда есть в теории и анализе,
        # иногда во введении (актуальность). В заключении ссылок БЫТЬ НЕ ДОЛЖНО
        # по методичке, но если попали — всё равно проверить понимание.
        "markers": [
            r"\[[\d]+(?:,\s*с\.\s*\d+)?\]",
            r"\bпо мнению\b",
            r"\bсогласно\b",
            r"\bуказывает\b",
            r"\bотмечает\b",
            r"\bсчитает\b",
        ],
        "questions": [
            "Перескажите своими словами, что именно утверждает этот автор",
            "Согласны ли вы с этой позицией? Если нет — почему?",
            "Какой контраргумент существует в научной литературе?",
        ],
        "category": "source-reference",
        "applicable_sections": {"introduction", "chapter1", "chapter2", "chapter3"},
    },
    {
        # Результаты / выводы
        "markers": [
            r"\bрезультат\w*\b",
            r"\bполучен\w*\b",
            r"\bвыявлен\w*\b",
            r"\bустановлен\w*\b",
            r"\bпоказан[ао]?\b",
        ],
        "questions": [
            "Как проверялась достоверность этого результата?",
            "Что могло исказить результат? Какие факторы учитывались?",
            "Воспроизводим ли этот результат? Что нужно, чтобы повторить?",
        ],
        "category": "results",
        "applicable_sections": {"chapter2", "chapter3", "conclusion"},
    },
    {
        # Определения / ключевые понятия
        "markers": [
            r"\bпредставля\w+ собой\b",
            r"\bпод\s+\w+\s+понимается\b",
            r"\bпод\s+\w+\s+подразумевается\b",
            r"\b(под|в\s+\w+\s+смысле)\s+\w+\s+мы\s+понимаем\b",
            r"\bопределяется как\b",
            r"\bпо определению\b",
            r"\bданное понятие\b",
            r"\bданный термин\b",
        ],
        "questions": [
            "Дайте альтернативное определение — как ещё можно сформулировать?",
            "Чем это понятие отличается от смежных?",
            "Есть ли в литературе другое определение? Какое?",
        ],
        "category": "definition",
        "applicable_sections": {"chapter1", "chapter2"},
    },
    {
        # Критические замечания / позиция автора
        "markers": [
            r"\bвызывает вопросы\b",
            r"\bпредставляется\b",
            r"\bна наш взгляд\b",
            r"\bпо нашему мнению\b",
            r"\bследует отметить\b",
            r"\bтребует уточнения\b",
        ],
        "questions": [
            "Обоснуйте вашу позицию конкретнее. На какие данные она опирается?",
            "Какие контраргументы к вашей точке зрения существуют?",
            "Что бы убедило вас изменить эту позицию?",
        ],
        "category": "author-position",
        "applicable_sections": {"introduction", "chapter1", "chapter2", "chapter3", "conclusion"},
    },
    {
        # Пилотирование / эксперимент — ТОЛЬКО Глава 3. В аннотации/заключении
        # слово «выборка» упоминается обзорно, там вопрос про обоснование размера
        # бессмысленен.
        "markers": [
            r"\bпилот\w*\b",
            r"\bэксперимент\w*\b",
            r"\bапробац\w*\b",
            r"\bтестиро\w*\b",
            r"\bвыборк\w*\b",
        ],
        "questions": [
            "Почему именно такая выборка? Чем обоснован её размер?",
            "Что пошло не так во время пилотирования? Что вы изменили?",
            "Репрезентативны ли участники для генеральной совокупности?",
        ],
        "category": "pilot",
        "applicable_sections": {"chapter3"},
    },
    {
        # Архитектурные / системные решения
        "markers": [
            r"\bархитектур\w*\b",
            r"\bкомпонент\w*\b",
            r"\bмодул\w*\b",
            r"\bсервис\w*\b",
            r"\bбаза данных\b",
            r"\bAPI\b",
            r"\bсхем\w*\b",
        ],
        "questions": [
            "Нарисуйте схему этого на доске",
            "Как данные перемещаются между компонентами?",
            "Какое самое уязвимое место этой архитектуры?",
        ],
        "category": "architecture",
        # v6.25: архитектурные вопросы не имеют смысла во введении/аннотации/
        # заключении — там архитектура не описывается подробно.
        "applicable_sections": {"chapter2", "chapter3"},
    },
]

# Общие вопросы на весь текст — универсальные
GENERIC_QUESTIONS = [
    "Перескажите суть этого абзаца одним предложением",
    "Какая главная мысль? Зачем этот абзац в работе?",
    "Что конкретно нового вы добавили к существующей литературе в этом абзаце?",
    "Какой вопрос этот абзац закрывает и какой ставит?",
]


def split_paragraphs(doc: Document) -> list:
    """Извлечь значимые абзацы (без служебных: предупреждения, клятва, библиография, аннотация)."""
    paragraphs = []
    # Служебные маркеры
    service_markers = [
        "⚠️",
        "выполнена мной совершенно самостоятельно",
        "живой ручкой",
        "Отсканированная подпись",
        "[Для обновления содержания",
        "___________________",
        "Ф.И.О.",
        "Проверка на объем заимствований",
    ]
    # Паттерн записи библиографии: «NN. Фамилия, И.О. …»
    bibliography_entry_re = re.compile(r"^\d{1,3}\.\s+[А-ЯЁA-Z][а-яёa-z]+,\s")

    # Определяем границы секций: где начинается/заканчивается библиография и аннотация
    in_bibliography = False
    in_annotation = False
    for p in doc.paragraphs:
        text = p.text.strip()
        text_lower = text.lower()
        # Начало библиографии
        if text_lower in ("список использованной литературы", "список литературы", "библиография"):
            in_bibliography = True
            continue
        # Конец библиографии (начинается приложение)
        if in_bibliography and text_lower.startswith(("приложение", "клятва", "выпускная квалификационная")):
            in_bibliography = False
        # Начало аннотации
        if text_lower == "аннотация":
            in_annotation = True
            continue
        # Конец аннотации (следующий большой блок)
        if in_annotation and text_lower in ("содержание", "оглавление", "введение"):
            in_annotation = False

        if in_bibliography or in_annotation:
            continue

        # Слишком короткие / заголовочные
        if len(text) < 80:
            continue
        if text.startswith(("Глава ", "Приложение ", "Таблица ", "Рисунок ")):
            continue
        # Служебные маркеры
        if any(marker in text for marker in service_markers):
            continue
        # Остаточная запись библиографии (если секцию не поймали)
        if bibliography_entry_re.match(text):
            continue

        paragraphs.append(text)
    return paragraphs


def detect_applicable_patterns(paragraph: str, section: str = None) -> list:
    """Найти, какие паттерны срабатывают на абзаце.

    Если указан section ('introduction' | 'chapter1-3' | 'conclusion'),
    фильтрует паттерны по полю applicable_sections — например, вопросы про
    пилотирование не задаются для аннотации/введения, вопросы про выбор
    технологии не задаются для заключения.
    Если секция не указана (обзор всей работы) — применяются все паттерны.
    """
    applicable = []
    for pattern in QUESTION_PATTERNS:
        # Фильтрация по секции
        if section is not None:
            applicable_sections = pattern.get("applicable_sections")
            if applicable_sections is not None and section not in applicable_sections:
                continue
        for marker in pattern["markers"]:
            if re.search(marker, paragraph, re.IGNORECASE):
                applicable.append(pattern)
                break
    return applicable


def generate_questions_for_paragraph(paragraph: str, max_questions: int = 3,
                                      section: str = None) -> list:
    """Сгенерировать 2-3 вопроса для абзаца с учётом секции."""
    applicable = detect_applicable_patterns(paragraph, section=section)

    questions = []
    categories_used = set()

    # Специфические вопросы по паттернам
    for pattern in applicable:
        if pattern["category"] in categories_used:
            continue
        q = random.choice(pattern["questions"])
        questions.append({
            "category": pattern["category"],
            "question": q,
        })
        categories_used.add(pattern["category"])
        if len(questions) >= max_questions:
            break

    # Добавить один генерик-вопрос если не хватает
    if len(questions) < max_questions:
        q = random.choice(GENERIC_QUESTIONS)
        questions.append({
            "category": "generic",
            "question": q,
        })

    return questions[:max_questions]


def extract_section(doc: Document, section_name: str) -> list:
    """Извлечь абзацы конкретного раздела."""
    section_markers = {
        "introduction": ["введение"],
        "conclusion": ["заключение"],
        "chapter1": ["глава 1", "глава i"],
        "chapter2": ["глава 2", "глава ii"],
        "chapter3": ["глава 3", "глава iii"],
    }
    keywords = section_markers.get(section_name.lower(), [section_name.lower()])
    stop_keywords = ["введение", "глава ", "заключение", "список", "приложение"]

    collecting = False
    collected = []
    for p in doc.paragraphs:
        text = p.text.strip()
        tl = text.lower()
        if not text:
            continue
        if not collecting:
            if any(tl.startswith(kw) for kw in keywords):
                collecting = True
                continue
        else:
            # Проверка на начало нового раздела
            is_new_section = any(
                tl.startswith(sw) for sw in stop_keywords
                if not any(tl.startswith(kw) for kw in keywords)
            ) and len(tl) < 80
            if is_new_section:
                break
            if len(text) >= 80:
                collected.append(text)
    return collected


def generate_report(paragraphs: list, verbose: bool = True, section: str = None) -> dict:
    """Полный отчёт — для каждого абзаца 2-3 вопроса.

    section: если указан — паттерны фильтруются по applicable_sections,
    и генерируются только релевантные вопросы для данной секции.
    """
    items = []
    for i, p in enumerate(paragraphs, 1):
        questions = generate_questions_for_paragraph(p, max_questions=3, section=section)
        items.append({
            "paragraph_id": i,
            "preview": p[:150] + ("..." if len(p) > 150 else ""),
            "full_text": p,
            "questions": questions,
        })

    # Агрегированная статистика по категориям
    all_categories = []
    for item in items:
        for q in item["questions"]:
            all_categories.append(q["category"])

    category_counts = {}
    for c in all_categories:
        category_counts[c] = category_counts.get(c, 0) + 1

    return {
        "total_paragraphs": len(paragraphs),
        "total_questions": sum(len(i["questions"]) for i in items),
        "category_distribution": category_counts,
        "items": items,
    }


def print_report(report: dict, show_full: bool = False):
    """Красивый текстовый отчёт."""
    print("\n" + "=" * 72)
    print("  ПРОВЕРКА ВЛАДЕНИЯ МАТЕРИАЛОМ (content ownership check)")
    print("  Симуляция вопросов, которые может задать комиссия")
    print("=" * 72)
    print(f"\nВсего проанализировано абзацев: {report['total_paragraphs']}")
    print(f"Сгенерировано вопросов: {report['total_questions']}")

    if report.get("category_distribution"):
        print("\nРаспределение по типам вопросов:")
        for cat, count in sorted(report["category_distribution"].items(),
                                 key=lambda x: -x[1]):
            print(f"  • {cat}: {count}")

    print("\n" + "-" * 72)
    print("ТРЕНИРОВОЧНЫЕ ВОПРОСЫ (ответь на каждый за 60 секунд устно):")
    print("-" * 72)

    for item in report["items"]:
        print(f"\n[Абзац #{item['paragraph_id']}]")
        if show_full:
            print(f"\n{item['full_text']}\n")
        else:
            print(f"  {item['preview']}\n")
        for j, q in enumerate(item["questions"], 1):
            cat_label = f"[{q['category']}]"
            print(f"  ❓ {j}. {q['question']} {cat_label}")

    print("\n" + "=" * 72)
    print("  РЕКОМЕНДАЦИИ")
    print("=" * 72)
    print("""
1. Прогони через эти вопросы КАЖДЫЙ абзац своей работы.
2. Если на какой-то вопрос не можешь ответить за 60 секунд — этот абзац
   надо либо переписать своими словами, либо изучить глубже.
3. Особое внимание:
   - Абзацы с цифрами/процентами — комиссия их любит проверять
   - Архитектурные решения — «нарисуйте на доске» классический вопрос
   - Ссылки на источники — «перескажите своими словами»
4. Пройди по работе минимум два раза:
   - За 2 недели до защиты (выявить слабые места)
   - За 2 дня до защиты (финальная репетиция)
5. Запиши себя на телефон, отвечая на вопросы. Послушай — если звучит
   как заученное, комиссия это тоже услышит.
""")


def main():
    parser = argparse.ArgumentParser(
        description="Генератор вопросов комиссии по тексту ВКР",
    )
    parser.add_argument("docx_path", help="Путь к .docx ВКР")
    parser.add_argument("--section", help="Раздел: introduction | conclusion | chapter1 | chapter2 | chapter3")
    parser.add_argument(
        "--sample", type=int, default=25,
        help="Выборка N абзацев (по умолчанию 25 — разумный объём для устной проработки за сеанс). Для длинных работ случайная, для коротких даст все абзацы."
    )
    parser.add_argument(
        "--all", action="store_true",
        help="Прогнать ВСЕ абзацы без выборки (может быть 100+ вопросов на полной работе — используй только для финального аудита перед защитой)."
    )
    parser.add_argument("--full", action="store_true", help="Показывать полный текст абзацев")
    parser.add_argument("--json", action="store_true", help="JSON-вывод")
    parser.add_argument("--seed", type=int, default=42, help="Seed для воспроизводимости")
    args = parser.parse_args()

    random.seed(args.seed)

    path = Path(args.docx_path)
    if not path.exists():
        print(f"❌ Файл не найден: {path}")
        sys.exit(1)

    doc = Document(path)

    if args.section:
        paragraphs = extract_section(doc, args.section)
        if not paragraphs:
            print(f"❌ Раздел '{args.section}' не найден или пуст")
            sys.exit(1)
    else:
        paragraphs = split_paragraphs(doc)

    # --all отключает выборку; иначе применяем дефолтный sample
    if not args.all and args.sample and args.sample < len(paragraphs):
        paragraphs = random.sample(paragraphs, args.sample)

    report = generate_report(paragraphs, section=args.section)

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        if args.section:
            print(f"\n[Раздел: {args.section}]")
        print_report(report, show_full=args.full)


if __name__ == "__main__":
    main()
