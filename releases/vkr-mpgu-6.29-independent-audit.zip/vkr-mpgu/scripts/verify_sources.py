#!/usr/bin/env python3
"""
Верификатор источников для ВКР.

Этот скрипт — каркас/helper для проверки источников. В отличие от других
скриптов, он НЕ выполняет автоматический поиск — реальный поиск должен
делать Claude через инструмент web_search в ходе диалога.

Скрипт служит двум целям:
1. Подготовить структурированный список источников для проверки
   (из сырого текста / DOCX / JSON)
2. Визуализировать отчёт о проверке

Используется в режиме `final` скилла следующим образом:

    # 1. Claude извлекает список источников из работы и сохраняет в JSON
    python verify_sources.py --extract input.docx -o sources.json

    # 2. Claude проходит по каждому источнику:
    #    - web_search по автору + названию
    #    - поиск на cyberleninka.ru / elibrary.ru
    #    - проверка URL через web_fetch
    #    - помечает статус в sources.json: confirmed / suspicious / unconfirmed

    # 3. Вывод итогового отчёта
    python verify_sources.py --report sources.json
"""

import sys
import json
import re
import argparse
from pathlib import Path

try:
    from docx import Document
except ImportError:
    Document = None


# ========== ИЗВЛЕЧЕНИЕ ИСТОЧНИКОВ ИЗ ТЕКСТА ==========

def extract_sources_from_docx(docx_path: Path) -> list:
    """
    Извлечь список источников из раздела "Список литературы" файла .docx.
    Возвращает список с сырым текстом каждого источника.
    """
    if Document is None:
        print("ERROR: python-docx не установлен")
        sys.exit(1)

    doc = Document(docx_path)
    paragraphs = [p.text for p in doc.paragraphs]

    # Найти начало секции
    start_idx = None
    for i, p in enumerate(paragraphs):
        p_lower = p.strip().lower()
        if (p_lower.startswith("список использованной литературы")
                or p_lower == "список литературы"
                or p_lower == "библиография"):
            start_idx = i + 1
            break

    if start_idx is None:
        print("❌ Не найден раздел 'Список литературы'")
        return []

    # Найти конец секции (приложения или конец документа)
    end_idx = len(paragraphs)
    for i in range(start_idx, len(paragraphs)):
        p_lower = paragraphs[i].strip().lower()
        if p_lower.startswith("приложение") or p_lower.startswith("клятва"):
            end_idx = i
            break

    # Пройти по абзацам между ними, собрать записи
    sources = []
    for para in paragraphs[start_idx:end_idx]:
        para = para.strip()
        if not para:
            continue
        # Проверить, начинается ли с номера ("1.", "2." и т.д.)
        m = re.match(r"^(\d+)\.\s*(.+)", para)
        if m:
            idx = int(m.group(1))
            text = m.group(2)
            sources.append({
                "id": idx,
                "raw_text": text,
                "status": "pending",
                "notes": "",
                "found_url": "",
            })

    return sources


# ========== ПАРСИНГ СЫРОГО ТЕКСТА ИСТОЧНИКА ==========

def parse_source_hints(raw_text: str) -> dict:
    """
    Извлечь из сырого текста описания источника ключевые поля
    (автор, название, год и т.п.) — эвристически, для удобства поиска.
    """
    hints = {"raw": raw_text}

    # Автор: "Фамилия, И.О." в начале
    author_match = re.match(
        r"^([А-ЯЁA-Z][а-яёa-z]+),\s*([А-ЯЁA-Z]\.(?:\s*[А-ЯЁA-Z]\.)?)",
        raw_text
    )
    if author_match:
        hints["author_last"] = author_match.group(1)
        hints["author_initials"] = author_match.group(2).replace(" ", "")

    # Год: первое попадание 4-значного числа в разумном диапазоне
    year_match = re.search(r"\b(19\d{2}|20[0-3]\d)\b", raw_text)
    if year_match:
        hints["year"] = int(year_match.group(1))

    # Название: между первой точкой (после автора) и " [Текст]" или " //"
    title_match = re.search(
        r"\.\s+(.+?)(?:\s*\[Текст\]|\s*//|\s*\.\s*–)",
        raw_text
    )
    if title_match:
        hints["title"] = title_match.group(1).strip()

    # URL
    url_match = re.search(r"https?://\S+", raw_text)
    if url_match:
        hints["url"] = url_match.group(0).rstrip(".,)")

    # DOI
    doi_match = re.search(r"DOI:\s*(\S+)", raw_text, re.IGNORECASE)
    if doi_match:
        hints["doi"] = doi_match.group(1).rstrip(".")

    # Определить тип
    if "[Электронный ресурс]" in raw_text:
        hints["type"] = "electronic"
    elif " // " in raw_text:
        hints["type"] = "article"
    elif "Дис." in raw_text or "дис." in raw_text or "автореф." in raw_text:
        hints["type"] = "dissertation"
    else:
        hints["type"] = "book"

    return hints


# ========== ГЕНЕРАЦИЯ ПОИСКОВЫХ ЗАПРОСОВ ==========

def build_search_queries(hints: dict) -> list:
    """
    Сформировать набор поисковых запросов для верификации источника.
    Возвращает список запросов в порядке приоритета.
    """
    queries = []

    author = f"{hints.get('author_last', '')} {hints.get('author_initials', '')}".strip()
    title = hints.get("title", "")
    year = hints.get("year", "")

    # 1. Автор + название (основной)
    if author and title:
        queries.append({
            "engine": "web_search",
            "query": f'{author} "{title}"'.strip(),
            "purpose": "Проверить существование работы",
        })

    # 2. CyberLeninka (только для статей/русскоязычных)
    if hints.get("type") == "article" and title:
        queries.append({
            "engine": "web_search",
            "query": f'"{title}" site:cyberleninka.ru',
            "purpose": "Найти на КиберЛенинке",
        })

    # 3. eLibrary
    if author and title:
        queries.append({
            "engine": "web_search",
            "query": f'{author} {title} site:elibrary.ru',
            "purpose": "Найти на eLibrary",
        })

    # 4. DOI direct
    if hints.get("doi"):
        queries.append({
            "engine": "web_fetch",
            "query": f"https://doi.org/{hints['doi']}",
            "purpose": "Проверить DOI",
        })

    # 5. URL direct
    if hints.get("url"):
        queries.append({
            "engine": "web_fetch",
            "query": hints["url"],
            "purpose": "Проверить URL",
        })

    # 6. Для иностранных — Google Scholar
    if author and title and not re.search(r"[А-Яа-яЁё]", author):
        queries.append({
            "engine": "web_search",
            "query": f'{author} {title}',
            "purpose": "Google Scholar (для англоязычных)",
        })

    return queries


# ========== ОТЧЁТ ==========

def print_report(sources: list):
    """Вывести отчёт по источникам."""
    print("\n" + "=" * 70)
    print("  ВЕРИФИКАЦИЯ ИСТОЧНИКОВ")
    print("=" * 70 + "\n")

    confirmed = [s for s in sources if s.get("status") == "confirmed"]
    suspicious = [s for s in sources if s.get("status") == "suspicious"]
    unconfirmed = [s for s in sources if s.get("status") == "unconfirmed"]
    pending = [s for s in sources if s.get("status") == "pending"]

    print(f"Всего источников: {len(sources)}")
    print(f"  ✅ Подтверждено: {len(confirmed)}")
    print(f"  ⚠️  Подозрительно: {len(suspicious)}")
    print(f"  ❌ Не подтверждено: {len(unconfirmed)}")
    print(f"  ⏳ Ожидает проверки: {len(pending)}")
    print()

    if suspicious:
        print("\n⚠️  ТРЕБУЮТ ДОПОЛНИТЕЛЬНОЙ ПРОВЕРКИ:")
        for s in suspicious:
            print(f"  [{s['id']}] {s.get('raw_text', '')[:80]}...")
            if s.get("notes"):
                print(f"       Заметки: {s['notes']}")

    if unconfirmed:
        print("\n❌ НЕ ПОДТВЕРЖДЕНЫ (ЗАМЕНИТЬ ИЛИ УБРАТЬ):")
        for s in unconfirmed:
            print(f"  [{s['id']}] {s.get('raw_text', '')[:80]}...")
            if s.get("notes"):
                print(f"       Заметки: {s['notes']}")

    print()


# ========== MAIN ==========

def main():
    parser = argparse.ArgumentParser(
        description="Верификатор источников для ВКР"
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        "--extract",
        metavar="DOCX",
        help="Извлечь список источников из .docx и сохранить в JSON"
    )
    group.add_argument(
        "--report",
        metavar="JSON",
        help="Вывести отчёт по JSON с верифицированными источниками"
    )
    group.add_argument(
        "--queries",
        metavar="JSON",
        help="Сгенерировать поисковые запросы для источников из JSON"
    )
    parser.add_argument("-o", "--output", help="Выходной файл")

    args = parser.parse_args()

    if args.extract:
        docx_path = Path(args.extract)
        if not docx_path.exists():
            print(f"❌ Файл не найден: {docx_path}")
            sys.exit(1)

        sources = extract_sources_from_docx(docx_path)
        # Добавить эвристический разбор
        for src in sources:
            src["hints"] = parse_source_hints(src["raw_text"])

        output = Path(args.output or "sources.json")
        output.write_text(
            json.dumps(sources, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        print(f"✅ Извлечено {len(sources)} источников → {output}")
        print("\nДалее: Claude должен пройти по каждому и через web_search проверить.")
        print("Для помощи в формировании запросов: python verify_sources.py --queries sources.json")

    elif args.queries:
        json_path = Path(args.queries)
        if not json_path.exists():
            print(f"❌ Файл не найден: {json_path}")
            sys.exit(1)

        sources = json.loads(json_path.read_text(encoding="utf-8"))
        for src in sources:
            if src.get("status") == "confirmed":
                continue
            hints = src.get("hints") or parse_source_hints(src.get("raw_text", ""))
            queries = build_search_queries(hints)
            print(f"\n[{src['id']}] {src.get('raw_text', '')[:80]}...")
            for q in queries:
                print(f"  {q['engine']}: {q['query']}  ({q['purpose']})")

    elif args.report:
        json_path = Path(args.report)
        if not json_path.exists():
            print(f"❌ Файл не найден: {json_path}")
            sys.exit(1)

        sources = json.loads(json_path.read_text(encoding="utf-8"))
        print_report(sources)


if __name__ == "__main__":
    main()
