#!/usr/bin/env python3
"""
Генератор .docx файла ВКР по требованиям методички МПГУ.

Создаёт файл с правильным оформлением:
- Поля: верх 20, низ 20, лево 35, право 10 мм
- Шрифт: Times New Roman 14 pt, чёрный
- Интервал: 1,5
- Красная строка: 1,25 см
- Нумерация страниц: снизу по центру, начиная со стр. 2 (на титуле не видно)
- Главы с новой страницы, римскими цифрами
- Параграфы арабскими через точку

Использование:
    python create_vkr_docx.py input.json -o vkr.docx

Формат input.json (все поля опциональны, кроме title и chapters):
{
  "title": "Тема работы",
  "title_page": {
    "institute": "Институт международного образования",
    "direction_code": "09.03.02",
    "direction_name": "Информационные системы и технологии",
    "profile": "Разработка игр и виртуальной реальности",
    "author": "Иванов Иван Иванович",
    "_authors_collective_example": "ИЛИ для коллективной ВКР используй поле 'authors': ['Иванов Иван Иванович', 'Петров Пётр Петрович']",
    "work_type": "бакалаврская работа",
    "supervisor_position": "доцент",
    "supervisor_degree": "канд. пед. наук",
    "supervisor_name": "П.С. Петров",
    "department": "кафедра информатики и информационных технологий",
    "head_degree": "д-р пед. наук, профессор",
    "head_name": "С.И. Сидоров",
    "year": 2026
  },
  "annotation": "Текст аннотации...",
  "introduction": "Текст введения...",
  "chapters": [
    {
      "title": "Теоретические основы исследования",
      "paragraphs": [
        // Простой формат (только текст):
        {"title": "1.1. Понятие X", "text": "Абзац 1\n\nАбзац 2..."},
        // Расширенный формат со смешанным контентом (v6.9):
        {
          "title": "1.2. Архитектура",
          "blocks": [
            {"type": "text", "content": "Абзац текста..."},
            {"type": "table", "number": 1, "title": "Сравнение решений",
             "headers": ["Критерий", "Наш продукт", "Конкурент"],
             "rows": [["Цена", "0 руб", "$30/мес"], ["Локализация", "да", "нет"]]},
            {"type": "text", "content": "После таблицы — вывод..."},
            {"type": "listing", "number": 1, "caption": "Вычисление позы",
             "code": "def compute(x):\n    return x * 2", "language": "python"},
            {"type": "figure", "number": 1, "caption": "Схема архитектуры",
             "placeholder": true}
          ]
        },
        ...
      ],
      "conclusion": "Выводы по Главе I..."
    },
    ...
  ],
  "conclusion": "Текст заключения...",
  "bibliography": [
    "1. Иванов, А.Б. Название [Текст]...",
    ...
  ],
  // ИЛИ (v6.24+) то же самое структурированно — как в sources.json
  // для format_bibliography.py. Принимаются ключи: bibliography, sources,
  // items, references. Если элементы — dict, они форматируются в ГОСТ
  // автоматически; если строки — вставляются как есть.
  // "sources": [
  //   {"type": "book", "authors": ["Иванов А.Б."], "title": "...",
  //    "city": "Москва", "publisher": "...", "year": 2024, "pages": 312}
  // ],
  "appendices": [
    {"title": "Приложение 1. Название", "content": "Содержание..."}
  ]
}

Новое в v6.9: поле "blocks" в параграфе для смешанного контента.
- type: "text" — обычный текст (поле content)
- type: "table" — таблица по МПГУ (Таблица N в правом углу + полужирный заголовок по центру)
- type: "listing" — листинг кода с моноширинным шрифтом (Consolas 11)
- type: "figure" — подпись рисунка (сам рисунок вставляется в Word вручную)"""

import sys
import json
import argparse
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, Mm, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
    from docx.enum.section import WD_SECTION
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
except ImportError:
    print("ERROR: python-docx не установлен. pip install python-docx")
    sys.exit(1)


# ========== ROMAN NUMERAL HELPER ==========

ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X"}


def to_roman(n: int) -> str:
    return ROMAN.get(n, str(n))


# ========== STYLE SETUP ==========

def setup_page_margins(doc: Document):
    """Установить формат A4 и поля по МПГУ на всех секциях."""
    for section in doc.sections:
        section.page_width = Mm(210)
        section.page_height = Mm(297)
        section.top_margin = Mm(20)
        section.bottom_margin = Mm(20)
        section.left_margin = Mm(35)
        section.right_margin = Mm(10)


def setup_base_style(doc: Document):
    """Базовый стиль Normal: TNR 14, 1.5 межстрочный, красная строка."""
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    # Для корректного отображения кириллицы в Word
    rpr = style.element.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts')
        rpr.append(rfonts)
    rfonts.set(qn('w:ascii'), 'Times New Roman')
    rfonts.set(qn('w:hAnsi'), 'Times New Roman')
    rfonts.set(qn('w:cs'), 'Times New Roman')
    rfonts.set(qn('w:eastAsia'), 'Times New Roman')

    font.size = Pt(14)
    font.color.rgb = RGBColor(0, 0, 0)

    pf = style.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    pf.first_line_indent = Cm(1.25)
    pf.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)

    # Настраиваем стили Heading 1/2/3 — тоже TNR 14 pt (иначе python-docx
    # ставит по умолчанию Calibri/Cambria, что нарушает методичку)
    for heading_name in ("Heading 1", "Heading 2", "Heading 3"):
        try:
            h = doc.styles[heading_name]
            h.font.name = "Times New Roman"
            h.font.size = Pt(14)
            h.font.color.rgb = RGBColor(0, 0, 0)
            h.font.bold = True
            # Для корректного отображения кириллицы в Word — через OXML
            h_rpr = h.element.get_or_add_rPr()
            h_rfonts = h_rpr.find(qn('w:rFonts'))
            if h_rfonts is None:
                h_rfonts = OxmlElement('w:rFonts')
                h_rpr.append(h_rfonts)
            h_rfonts.set(qn('w:ascii'), 'Times New Roman')
            h_rfonts.set(qn('w:hAnsi'), 'Times New Roman')
            h_rfonts.set(qn('w:cs'), 'Times New Roman')
            h_rfonts.set(qn('w:eastAsia'), 'Times New Roman')
        except (KeyError, AttributeError):
            pass


def add_page_number_field(paragraph):
    """Добавить поле с номером страницы в абзац."""
    run = paragraph.add_run()
    # begin field
    fld_begin = OxmlElement('w:fldChar')
    fld_begin.set(qn('w:fldCharType'), 'begin')
    run._element.append(fld_begin)
    # instr text
    instr = OxmlElement('w:instrText')
    instr.text = 'PAGE'
    run._element.append(instr)
    # end field
    fld_end = OxmlElement('w:fldChar')
    fld_end.set(qn('w:fldCharType'), 'end')
    run._element.append(fld_end)


def setup_page_numbers(doc: Document):
    """Номера страниц внизу по центру; скрыть на первой странице (титуле).

    Явно выставляем <w:pgNumType w:start="1"/> в sectPr, чтобы нумерация
    всегда начиналась с 1 (титул = стр. 1, но цифра скрыта через
    different_first_page; аннотация = стр. 2 с номером). Без этого
    параметра Word и LibreOffice могут вести нумерацию по-разному при
    конвертации через разные движки.
    """
    # Делаем разные колонтитулы для первой страницы
    section = doc.sections[0]
    section.different_first_page_header_footer = True

    # Явно стартуем нумерацию с 1 через XML
    sectPr = section._sectPr
    # Удаляем старый pgNumType если был
    existing = sectPr.find(qn("w:pgNumType"))
    if existing is not None:
        sectPr.remove(existing)
    pgNumType = OxmlElement("w:pgNumType")
    pgNumType.set(qn("w:start"), "1")
    sectPr.append(pgNumType)

    # Основной футер (со 2-й страницы) — номер по центру
    footer = section.footer
    footer_para = footer.paragraphs[0]
    footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_para.paragraph_format.first_line_indent = Cm(0)
    add_page_number_field(footer_para)

    # Футер первой страницы — пустой
    first_footer = section.first_page_footer
    first_footer.paragraphs[0].text = ""


# ========== CONTENT BUILDERS ==========

def add_title_page(doc: Document, tp: dict, work_title: str):
    """
    Титульный лист по шаблону МПГУ.

    Порядок по реальному образцу 09.03.02 МПГУ (ИМО):
    1. Шапка (Министерство + университет)
    2. Авторы (жирным, по правому краю)
    3. Институт (по центру)
    4. Тема (жирным, по центру)
    5. Код направления + профиль
    6. "Выпускная квалификационная работа (бакалаврская работа)"
    7. Научный руководитель + Зав. кафедрой (справа блоком)
    8. Проверка на заимствования
    9. Москва — ГГГГ год

    КРИТИЧНО: весь титульник ставится с line_spacing=1.0 (single) в post-processing,
    чтобы не уползал на 2 страницы из-за стандартного 1.5-интервала тела работы.
    """
    # v6.25: валидация обязательных полей — до сих пор генератор молча создавал
    # титульник с «ФИО автора» или пустой строкой названия, если JSON был
    # битый. Теперь — падаем сразу, с понятным сообщением.
    if not work_title or not work_title.strip():
        raise ValueError(
            "create_vkr_docx: поле 'title' (тема работы) обязательно. "
            "Передайте непустую строку в корне JSON."
        )
    if not (tp.get("author") or tp.get("authors")):
        raise ValueError(
            "create_vkr_docx: в title_page обязательно поле 'author' (строка) "
            "или 'authors' (список строк). Без автора титульник не валиден."
        )

    # Запоминаем индекс первого абзаца титульника
    _title_start_idx = len(doc.paragraphs)

    # Шапка университета (по центру)
    lines = [
        "Министерство просвещения Российской Федерации",
        "федеральное государственное бюджетное",
        "образовательное учреждение высшего образования",
        "«Московский педагогический государственный университет»",
    ]
    for line in lines:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.line_spacing = 1.15
        run = p.add_run(line)
        run.font.size = Pt(14)

    doc.add_paragraph()

    # Авторы — поддержка и одного, и коллектива (2-4 человека)
    # Принимаем либо tp["author"] (строка), либо tp["authors"] (список строк)
    authors = tp.get("authors")
    if not authors:
        author_str = tp.get("author", "ФИО автора")
        authors = [author_str]

    for author_name in authors:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(author_name)
        run.font.size = Pt(14)
        run.bold = True

    # Институт (по центру)
    if tp.get("institute"):
        doc.add_paragraph()
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(tp["institute"])
        run.font.size = Pt(14)

    # Название (по центру, жирным — НЕ всеми заглавными, как в реальном образце!)
    doc.add_paragraph()
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run(work_title)
    run.font.size = Pt(14)
    run.bold = True

    # Код направления + профиль (по центру, как в реальном образце)
    doc.add_paragraph()
    if tp.get("direction_code") or tp.get("direction_name"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(
            f"Код и направление подготовки: "
            f"{tp.get('direction_code', '')}. {tp.get('direction_name', '')}"
        )
        run.font.size = Pt(14)

    if tp.get("profile"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(
            f"Направленность (профиль) образовательной программы:"
        )
        run.font.size = Pt(14)

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(f"{tp['profile']}.")
        run.font.size = Pt(14)

    # Тип работы (по центру)
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run("Выпускная квалификационная работа")
    run.font.size = Pt(14)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run(f"({tp.get('work_type', 'бакалаврская работа')})")
    run.font.size = Pt(14)

    # Научный руководитель (по левому краю, как в реальном образце)
    doc.add_paragraph()
    doc.add_paragraph()
    supervisor_parts = ["Научный руководитель –"]
    if tp.get("supervisor_position") or tp.get("supervisor_degree"):
        degree_parts = []
        if tp.get("supervisor_position"):
            degree_parts.append(tp["supervisor_position"])
        if tp.get("supervisor_degree"):
            degree_parts.append(tp["supervisor_degree"])
        supervisor_parts.append(", ".join(degree_parts))
    if tp.get("supervisor_name"):
        supervisor_parts.append(tp["supervisor_name"])

    for line in supervisor_parts:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(line)
        run.font.size = Pt(14)

    # Зав. кафедрой (по левому краю)
    doc.add_paragraph()
    head_lines = ["Заведующий кафедрой"]
    if tp.get("department"):
        # Нормализуем: если department начинается со слова «кафедра» — срезаем, чтобы
        # не получился дубль «Заведующий кафедрой кафедра информатики...».
        # Допустимые варианты на входе: «кафедра X», «кафедрой X», «X» — всё сводим к «X».
        dept = tp["department"].strip()
        dept_lower = dept.lower()
        for prefix in ("кафедрой ", "кафедра "):
            if dept_lower.startswith(prefix):
                dept = dept[len(prefix):]
                break
        head_lines.append(dept)
    head_lines.append("_" * 30)
    if tp.get("head_degree"):
        head_lines.append(tp["head_degree"])
    if tp.get("head_name"):
        head_lines.append(tp["head_name"])

    for line in head_lines:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(line)
        run.font.size = Pt(14)

    # Проверка на заимствования
    doc.add_paragraph()
    doc.add_paragraph()
    # python-docx игнорирует \n внутри add_run — нужно два отдельных параграфа
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run("Проверка на объем заимствований:")
    run.font.size = Pt(14)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run("_______% авторского текста")
    run.font.size = Pt(14)

    # Год, город внизу
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run(f"Москва – {tp.get('year', 2026)} год")
    run.font.size = Pt(14)

    # Post-process: ставим line_spacing=1.0 для ВСЕХ абзацев титульника.
    # Иначе интервал 1.5 (из стиля Normal) раздувает титульник на 2 страницы,
    # и аннотация уплывает со стр. 2 на стр. 3, ломая всю нумерацию методички.
    from docx.enum.text import WD_LINE_SPACING
    for p_tp in doc.paragraphs[_title_start_idx:]:
        p_tp.paragraph_format.line_spacing = 1.0
        p_tp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE

    # Разрыв страницы перед аннотацией
    doc.add_page_break()


def add_section_heading(doc: Document, text: str, centered: bool = True,
                        include_in_toc: bool = True):
    """Добавить заголовок раздела (Введение, Заключение и т.п.).

    По умолчанию применяет стиль Heading 1 — чтобы раздел попал в
    автооглавление Word (TOC). Чёрный цвет переопределяется явно
    (по методичке МПГУ). Расстояние от заголовка до текста 15 мм (42 pt).
    """
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if centered else WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(0)
    # 15 мм по методичке = ~42 pt (1 pt = 0.3528 мм)
    p.paragraph_format.space_after = Pt(42)
    run = p.add_run(text)
    run.font.size = Pt(14)
    run.bold = True
    # Чёрный цвет (Heading 1 по умолчанию синий)
    run.font.name = "Times New Roman"
    run.font.color.rgb = RGBColor(0, 0, 0)

    if include_in_toc:
        p.style = doc.styles['Heading 1']
        # Стиль мог переопределить цвет — возвращаем
        run.font.name = "Times New Roman"
        run.font.color.rgb = RGBColor(0, 0, 0)


def add_paragraphs_from_text(doc: Document, text: str):
    """Разбить text на абзацы (по \\n\\n) и добавить в документ."""
    if not text:
        return
    for para_text in text.split("\n\n"):
        para_text = para_text.strip()
        if not para_text:
            continue
        p = doc.add_paragraph(para_text)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


def add_annotation(doc: Document, text: str):
    """Аннотация."""
    add_section_heading(doc, "Аннотация", include_in_toc=False)
    add_paragraphs_from_text(doc, text)
    doc.add_page_break()


def add_contents_placeholder(doc: Document):
    """
    Содержание (оглавление) - заглушка.
    Реально заполнить его автоматически через поле TOC сложно;
    пользователь в Word нажмёт Ссылки → Оглавление → Обновить.
    """
    add_section_heading(doc, "Содержание", include_in_toc=False)

    # Вставляем поле TOC (Table of Contents)
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Cm(0)
    run = p.add_run()

    fld_begin = OxmlElement('w:fldChar')
    fld_begin.set(qn('w:fldCharType'), 'begin')
    run._element.append(fld_begin)

    instr = OxmlElement('w:instrText')
    instr.text = r'TOC \o "1-3" \h \z \u'
    run._element.append(instr)

    fld_sep = OxmlElement('w:fldChar')
    fld_sep.set(qn('w:fldCharType'), 'separate')
    run._element.append(fld_sep)

    # Placeholder text (появится до обновления)
    run2 = p.add_run(
        "[Для обновления содержания: щёлкните правой кнопкой → Обновить поле]"
    )
    run2.font.italic = True
    run2.font.size = Pt(12)

    fld_end = OxmlElement('w:fldChar')
    fld_end.set(qn('w:fldCharType'), 'end')
    run._element.append(fld_end)

    doc.add_page_break()


def add_introduction(doc: Document, text: str):
    add_section_heading(doc, "Введение")
    add_paragraphs_from_text(doc, text)
    doc.add_page_break()


def add_chapter(doc: Document, chapter: dict, idx: int):
    """Добавить главу с параграфами."""
    # Заголовок главы
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(0)
    # Расстояние заголовок-текст 15 мм ≈ 42 pt (1 pt = 0.3528 мм)
    p.paragraph_format.space_after = Pt(42)
    run = p.add_run(f"Глава {to_roman(idx)}. {chapter['title'].rstrip('.')}")
    run.font.size = Pt(14)
    run.bold = True
    # Явно чёрный цвет — стиль Heading 1 по умолчанию синий (#365F91),
    # методичка МПГУ требует чёрный
    run.font.name = "Times New Roman"
    run.font.color.rgb = RGBColor(0, 0, 0)
    # Применим стиль Heading 1 для включения в TOC
    p.style = doc.styles['Heading 1']
    # Повторно задаём цвет run — стиль мог переопределить
    run.font.name = "Times New Roman"
    run.font.color.rgb = RGBColor(0, 0, 0)

    # Параграфы
    for para in chapter.get("paragraphs", []):
        add_paragraph_subsection(doc, para)

    # Выводы по главе
    if chapter.get("conclusion"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(18)
        p.paragraph_format.space_after = Pt(12)
        run = p.add_run(f"Выводы по Главе {to_roman(idx)}")
        run.font.size = Pt(14)
        run.bold = True

        add_paragraphs_from_text(doc, chapter["conclusion"])

    doc.add_page_break()


def add_paragraph_subsection(doc: Document, para: dict):
    """Подраздел (параграф главы): заголовок + текст + опционально таблицы/листинги/рисунки.

    Поддерживаемые поля в JSON:
      - title: str — заголовок параграфа
      - text: str — текст параграфа (может быть пустой, если используются blocks)
      - blocks: list — упорядоченный список блоков (для смешанного контента).
                      Каждый блок: {"type": "text"|"table"|"listing"|"figure", ...}

    Если blocks есть, text игнорируется (или используется как первый text-блок).
    """
    # Заголовок параграфа
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(1.25)
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(12)
    run = p.add_run(para["title"].rstrip('.'))
    run.font.size = Pt(14)
    run.bold = True
    # Явно чёрный цвет — Heading 2 по умолчанию #4F81BD
    run.font.name = "Times New Roman"
    run.font.color.rgb = RGBColor(0, 0, 0)
    p.style = doc.styles['Heading 2']
    # Повторно — стиль мог переопределить
    run.font.name = "Times New Roman"
    run.font.color.rgb = RGBColor(0, 0, 0)

    # Если есть blocks — идём по ним по порядку
    blocks = para.get("blocks")
    if blocks:
        for block in blocks:
            btype = block.get("type", "text")
            if btype == "text":
                add_paragraphs_from_text(doc, block.get("content", ""))
            elif btype == "table":
                add_table_block(doc, block)
            elif btype == "listing":
                add_listing_block(doc, block)
            elif btype == "figure":
                add_figure_caption_block(doc, block)
    else:
        # Fallback: просто текст параграфа
        add_paragraphs_from_text(doc, para.get("text", ""))


def add_table_block(doc: Document, block: dict):
    """Добавить таблицу по методичке МПГУ.

    Ожидаемые поля блока:
      - number: int|str — номер таблицы (для метки «Таблица N»)
      - title: str — заголовок таблицы (полужирный, по центру, строчные кроме первой прописной)
      - headers: list[str] — заголовки столбцов
      - rows: list[list[str]] — данные таблицы
      - source: str (опционально) — ссылка на источник, если таблица заимствована

    По методичке:
      - «Таблица N» — в правом верхнем углу над заголовком (БЕЗ точки после номера)
      - Заголовок — над таблицей, по центру, полужирный, без точки в конце
      - Внутри таблицы допустим меньший шрифт (12 pt) и одинарный интервал
    """
    # Метка «Таблица N» — в правом верхнем углу
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(0)
    r = p.add_run(f"Таблица {block.get('number', '')}")
    r.font.size = Pt(14)

    # Заголовок таблицы — полужирный, по центру, без точки в конце
    title = block.get("title", "").rstrip(".")
    if title:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(title)
        r.font.size = Pt(14)
        r.bold = True

    # Сама таблица
    headers = block.get("headers", [])
    rows = block.get("rows", [])
    if not headers and not rows:
        return

    # Определяем число столбцов
    ncols = len(headers) if headers else (len(rows[0]) if rows else 0)
    if ncols == 0:
        return

    table = doc.add_table(rows=1 + len(rows), cols=ncols)
    table.style = "Table Grid"  # границы ячеек — это стандарт

    # Заголовки
    if headers:
        header_cells = table.rows[0].cells
        for i, h in enumerate(headers[:ncols]):
            cell = header_cells[i]
            cell.text = ""
            p_cell = cell.paragraphs[0]
            p_cell.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p_cell.add_run(str(h))
            r.font.size = Pt(12)
            r.bold = True

    # Данные
    for row_idx, row_data in enumerate(rows, start=1):
        cells = table.rows[row_idx].cells
        for i, val in enumerate(row_data[:ncols]):
            cell = cells[i]
            cell.text = ""
            p_cell = cell.paragraphs[0]
            p_cell.paragraph_format.first_line_indent = Cm(0)
            r = p_cell.add_run(str(val))
            r.font.size = Pt(12)

    # Ссылка на источник (если есть)
    if block.get("source"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(0)
        r = p.add_run(f"Источник: {block['source']}")
        r.font.size = Pt(12)
        r.italic = True

    # Отступ после таблицы
    doc.add_paragraph()


def add_listing_block(doc: Document, block: dict):
    """Добавить листинг кода с моноширинным шрифтом.

    Ожидаемые поля:
      - number: int|str — номер листинга (для подписи «Листинг N»)
      - caption: str — подпись листинга («Функция вычисления позы»)
      - code: str — текст листинга
      - language: str (опционально, для информации) — python / js / etc.

    По сложившемуся стандарту IT-ВКР:
      - Моноширинный шрифт (Consolas / Courier New), 11-12 pt
      - Без абзацного отступа (красной строки)
      - Подпись снизу: «Листинг N — Название» (курсив, по центру, меньший шрифт)
    """
    code = block.get("code", "")
    if not code:
        return

    # Текст листинга
    # Разбиваем по строкам кода, каждая строка — отдельный абзац с моноширинным шрифтом
    for line in code.split("\n"):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.left_indent = Cm(1.0)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        # Отключаем межстрочный 1.5 для кода — ставим одинарный
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
        # Run с моноширинным шрифтом
        r = p.add_run(line if line else " ")
        r.font.name = "Consolas"
        # Для корректного отображения в Word нужно также установить через rPr
        rfonts = r._element.get_or_add_rPr().find(qn('w:rFonts'))
        if rfonts is None:
            rfonts = OxmlElement('w:rFonts')
            r._element.get_or_add_rPr().append(rfonts)
        rfonts.set(qn('w:ascii'), 'Consolas')
        rfonts.set(qn('w:hAnsi'), 'Consolas')
        r.font.size = Pt(11)

    # Подпись листинга — снизу, курсив, по центру
    number = block.get("number", "")
    caption = block.get("caption", "")
    if number or caption:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(12)
        text = f"Листинг {number}" + (f" — {caption}" if caption else "")
        r = p.add_run(text)
        r.font.size = Pt(12)
        r.italic = True


def add_figure_caption_block(doc: Document, block: dict):
    """Добавить подпись рисунка (без самого изображения — его студент вставит в Word вручную).

    Ожидаемые поля:
      - number: int|str — номер рисунка
      - caption: str — название
      - placeholder: bool (опционально) — показывать ли заглушку вместо рисунка

    Подпись рисунка по методичке:
      - Под рисунком, по центру: «Рисунок N — Название» (без точки в конце)
    """
    # Заглушка изображения
    if block.get("placeholder", True):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(12)
        p.paragraph_format.space_after = Pt(0)
        r = p.add_run("[ Здесь вставить рисунок вручную в Word ]")
        r.font.size = Pt(12)
        r.italic = True

    # Подпись рисунка
    number = block.get("number", "")
    caption = block.get("caption", "").rstrip(".")
    if number or caption:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent = Cm(0)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(12)
        text = f"Рисунок {number}" + (f" — {caption}" if caption else "")
        r = p.add_run(text)
        r.font.size = Pt(12)


def add_conclusion(doc: Document, text: str):
    add_section_heading(doc, "Заключение")
    add_paragraphs_from_text(doc, text)
    doc.add_page_break()


def add_bibliography(doc: Document, entries: list):
    add_section_heading(doc, "Список использованной литературы")
    for entry in entries:
        p = doc.add_paragraph(entry)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        # Висячий отступ для номера
        p.paragraph_format.left_indent = Cm(0.5)
        p.paragraph_format.first_line_indent = Cm(-0.5)
    doc.add_page_break()


def add_appendices(doc: Document, appendices: list):
    for app in appendices:
        # "Приложение N" в правом верхнем углу
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.paragraph_format.first_line_indent = Cm(0)
        run = p.add_run(app.get("label", "Приложение"))
        run.font.size = Pt(14)
        run.bold = True

        # Заголовок приложения — по центру
        if app.get("title"):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.first_line_indent = Cm(0)
            p.paragraph_format.space_after = Pt(12)
            run = p.add_run(app["title"])
            run.font.size = Pt(14)
            run.bold = True

        # Содержимое
        add_paragraphs_from_text(doc, app.get("content", ""))
        doc.add_page_break()


def add_last_page(doc: Document, authors=None):
    """Добавить «Последний лист ВКР» — официальная форма МПГУ с клятвой
    о самостоятельном выполнении работы.

    По методичке МПГУ это обязательная часть ВКР (не отдельный вкладыш),
    подшивается в самом конце после приложений. Форма — таблица с
    текстом декларации и ячейками под ФИО/подпись/дату.

    authors: либо строка с ФИО одного автора, либо список строк (для
    коллективной ВКР — каждому автору своя строка декларации).
    Если None — генерируется шаблон с пропусками под ФИО.
    """
    from docx.enum.table import WD_ALIGN_VERTICAL

    # Разрыв страницы — последний лист идёт на отдельной странице
    doc.add_page_break()

    # Заголовок
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_after = Pt(18)
    r = p.add_run("Выпускная квалификационная работа")
    r.font.size = Pt(14)
    r.bold = True

    # Список авторов: для одиночной работы — одна строка, для коллективной — несколько
    if authors is None:
        authors_list = [""]
    elif isinstance(authors, str):
        authors_list = [authors]
    elif isinstance(authors, list):
        authors_list = authors if authors else [""]
    else:
        authors_list = [""]

    # Таблица: для каждого автора — одна строка с текстом декларации + строка с подписью
    n_authors = len(authors_list)
    oath_text = (
        "Выпускная квалификационная работа выполнена мной совершенно "
        "самостоятельно. Все использованные в работе материалы и концепции "
        "из опубликованной научной литературы и других источников имеют "
        "ссылки на них."
    )

    # Таблица N строк, 1 столбец — сам текст клятвы (по разу на автора)
    t_oath = doc.add_table(rows=n_authors, cols=1)
    t_oath.style = "Table Grid"
    for i in range(n_authors):
        cell = t_oath.rows[i].cells[0]
        cell.text = ""
        p_cell = cell.paragraphs[0]
        p_cell.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p_cell.paragraph_format.first_line_indent = Cm(0.5)
        r = p_cell.add_run(oath_text)
        r.font.size = Pt(14)

    # Пустая строка
    doc.add_paragraph()

    # Таблица подписей: 3 столбца (ФИО, подпись, дата), N строк
    t_sig = doc.add_table(rows=n_authors, cols=3)
    t_sig.style = "Table Grid"
    headers = ["Ф.И.О.", "подпись", "дата"]

    for i, author_name in enumerate(authors_list):
        cells = t_sig.rows[i].cells
        # ФИО
        cells[0].text = ""
        p0 = cells[0].paragraphs[0]
        p0.paragraph_format.first_line_indent = Cm(0)
        r0 = p0.add_run(author_name if author_name else "___________________")
        r0.font.size = Pt(12)
        # Подпись
        cells[1].text = ""
        p1 = cells[1].paragraphs[0]
        p1.paragraph_format.first_line_indent = Cm(0)
        r1 = p1.add_run("___________________")
        r1.font.size = Pt(12)
        # Дата
        cells[2].text = ""
        p2 = cells[2].paragraphs[0]
        p2.paragraph_format.first_line_indent = Cm(0)
        r2 = p2.add_run("___________________")
        r2.font.size = Pt(12)

    # Шапка подписей — курсив мелко под таблицей
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    r = p.add_run(
        "(Ф.И.О.)        (подпись)        (дата)"
    )
    r.font.size = Pt(10)
    r.italic = True

    # Предупреждение
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.first_line_indent = Cm(0)
    p.paragraph_format.space_before = Pt(18)
    r = p.add_run(
        "⚠️ Ф.И.О., подпись и дата ставятся ТОЛЬКО от руки живой ручкой. "
        "Отсканированная подпись не принимается."
    )
    r.font.size = Pt(10)
    r.italic = True


# ========== MAIN BUILDER ==========

def build_vkr_docx(data: dict, output_path: Path):
    """Построить .docx ВКР."""
    doc = Document()
    setup_page_margins(doc)
    setup_base_style(doc)
    setup_page_numbers(doc)

    # 1. Титульный лист
    tp = data.get("title_page", {})
    add_title_page(doc, tp, data.get("title", "Тема работы"))

    # 2. Аннотация
    if data.get("annotation"):
        add_annotation(doc, data["annotation"])

    # 3. Содержание
    add_contents_placeholder(doc)

    # 4. Введение
    if data.get("introduction"):
        add_introduction(doc, data["introduction"])

    # 5. Главы
    for idx, chapter in enumerate(data.get("chapters", []), 1):
        add_chapter(doc, chapter, idx)

    # 6. Заключение
    if data.get("conclusion"):
        add_conclusion(doc, data["conclusion"])

    # 7. Список литературы
    # v6.24: принимаем несколько канонических ключей (совместимость с
    # sources.json, используемым format_bibliography.py). Элементы могут
    # быть либо строками (пре-форматированные записи), либо dict-ами —
    # в последнем случае форматируем через format_bibliography.py.
    bib_entries = None
    for _bib_key in ("bibliography", "sources", "items", "references"):
        if data.get(_bib_key):
            bib_entries = data[_bib_key]
            break
    if bib_entries:
        if bib_entries and isinstance(bib_entries[0], dict):
            try:
                import sys as _sys
                _sys.path.insert(0, str(Path(__file__).resolve().parent))
                from format_bibliography import (
                    format_bibliography as _fmt_bib,
                    normalize_input_data as _norm_bib,
                )
                normalized = _norm_bib(bib_entries)
                formatted_text, _ = _fmt_bib(normalized, preserve_ids=False)
                bib_entries = [ln for ln in formatted_text.split("\n\n") if ln.strip()]
            except Exception as e:
                print(f"⚠️  Не удалось отформатировать структурированный список "
                      f"источников ({e}); вставляю сырые строки.")
                bib_entries = [str(x) for x in bib_entries]
        add_bibliography(doc, bib_entries)

    # 8. Приложения
    if data.get("appendices"):
        add_appendices(doc, data["appendices"])

    # 9. Последний лист ВКР (клятва — обязательная часть работы по методичке МПГУ)
    # Имя автора(ов) берём из title_page. Можно отключить через skip_last_page: true
    if not data.get("skip_last_page", False):
        authors_on_last_page = (
            data.get("title_page", {}).get("authors")
            or data.get("title_page", {}).get("author")
        )
        add_last_page(doc, authors=authors_on_last_page)

    doc.save(output_path)
    return doc


def main():
    parser = argparse.ArgumentParser(
        description="Генератор .docx ВКР по методичке МПГУ"
    )
    parser.add_argument("input_json", help="JSON с содержимым ВКР")
    parser.add_argument("-o", "--output", default="vkr.docx", help="Выходной .docx")
    args = parser.parse_args()

    in_path = Path(args.input_json)
    if not in_path.exists():
        print(f"❌ Файл не найден: {in_path}")
        sys.exit(1)

    data = json.loads(in_path.read_text(encoding="utf-8"))
    out_path = Path(args.output)

    build_vkr_docx(data, out_path)
    print(f"✅ Создан: {out_path}")
    separator = "=" * 70
    print(
        "\n" + separator + "\n"
        + "⚠️  КРИТИЧНО — БЕЗ ЭТОГО ОГЛАВЛЕНИЕ ОСТАНЕТСЯ ПУСТЫМ!\n"
        + separator + "\n"
        + "   1. Открыть файл в Word (LibreOffice НЕ гарантирует корректность).\n"
        + "   2. Найти раздел «Содержание» — там будет плейсхолдер\n"
        + "      «[Для обновления содержания: щёлкните правой кнопкой → Обновить поле]».\n"
        + "   3. Щёлкнуть правой кнопкой по плейсхолдеру → «Обновить поле»\n"
        + "      (или выделить текст содержания и нажать F9).\n"
        + "   4. Выбрать «Обновить целиком».\n"
        + "   5. Убедиться, что появился список заголовков с номерами страниц.\n"
        + "\n"
        + "   Без этого шага ВКР уйдёт на нормоконтроль с пустым оглавлением.\n"
        + separator + "\n\n"
        + "Также перед сдачей:\n"
        + "   • Проверить, что нумерация страниц начинается со стр. 2.\n"
        + "   • Прогнать через validate_vkr.py — не должно быть ошибок.\n"
        + "\n"
        + "📎 ВКЛАДЫШИ ПОСЛЕ КЛЯТВЫ (по методичке МПГУ вшиваются в конец работы):\n"
        + "   1. Отзыв научного руководителя — готовит научрук\n"
        + "   2. Разрешение на размещение ВКР — `assets/permission-template.docx`,\n"
        + "      подпись живой ручкой\n"
        + "   3. Справка о проверке в «Антиплагиат.Вуз» — выдаёт кафедра\n"
        + "   4. Для ПРОЕКТНОЙ ВКР: справка о внедрении —\n"
        + "      `assets/implementation-certificate.docx`, подпись руководителя\n"
        + "      организации, где проходил пилот (уточни у научрука обязательность)."
    )


if __name__ == "__main__":
    main()
