# Установка vkr-mpgu 6.31

В поставке находятся два файла с одинаковым содержимым:

- `vkr-mpgu-6.31-auto-workspace.skill` — контейнер для клиента, который явно
  поддерживает импорт файлов `.skill`;
- `vkr-mpgu-6.31-auto-workspace.zip` — универсальный ZIP для ручной установки,
  Claude Code, веб-систем и API.

**Выбери один вариант. Устанавливать оба файла не нужно.** Если в интерфейсе нет
команды импорта `.skill`, используй ZIP.

## Codex: ручная установка ZIP

### Windows

1. Закрой задачи Codex, которые уже используют старую версию `vkr-mpgu`.
2. Если существует `%USERPROFILE%\.codex\skills\vkr-mpgu`, переименуй её в
   `vkr-mpgu-backup` или перенеси в резервную папку.
3. Распакуй `vkr-mpgu-6.31-auto-workspace.zip` прямо в:
   `%USERPROFILE%\.codex\skills\`.
4. Проверь итоговый путь:
   `%USERPROFILE%\.codex\skills\vkr-mpgu\SKILL.md`.
5. Открой новую задачу Codex и напиши:
   `$vkr-mpgu помоги начать ВКР с нуля`.

PowerShell-вариант после резервного копирования старой папки:

```powershell
New-Item -ItemType Directory -Force "$HOME\.codex\skills" | Out-Null
Expand-Archive -LiteralPath "$HOME\Downloads\vkr-mpgu-6.31-auto-workspace.zip" -DestinationPath "$HOME\.codex\skills"
```

### macOS и Linux

1. Перемести прежнюю `~/.codex/skills/vkr-mpgu` в резервную папку, если она есть.
2. Выполни:

```bash
mkdir -p ~/.codex/skills
unzip ~/Downloads/vkr-mpgu-6.31-auto-workspace.zip -d ~/.codex/skills
```

3. Проверь наличие `~/.codex/skills/vkr-mpgu/SKILL.md`.
4. Открой новую задачу и вызови `$vkr-mpgu`.

## Импорт `.skill`

Если клиент показывает команду **Import skill**, **Install skill** или принимает
файл `.skill`, выбери `vkr-mpgu-6.31-auto-workspace.skill`. После импорта открой
новую задачу и вызови `$vkr-mpgu`.

Если такой команды нет или импорт завершился ошибкой, не переименовывай внутренние
файлы: используй ручную установку ZIP выше. Сам `.skill` также является ZIP-контейнером
с корневой папкой `vkr-mpgu`.

## Claude Code

Распакуй ZIP так, чтобы получился путь:

```text
~/.claude/skills/vkr-mpgu/SKILL.md
```

Затем начни новую сессию и вызови навык по имени `vkr-mpgu`. Для независимого
аудита среда должна поддерживать отдельные Task/subagent-контексты.

## ChatGPT, Claude.ai, Gemini и другие веб-системы

Веб-системы обычно не устанавливают папку локального навыка целиком:

1. Распакуй ZIP.
2. Помести содержимое `PORTABLE-PROMPT.md` в системные или пользовательские
   инструкции проекта.
3. Добавь `SKILL.md` в файлы знаний.
4. Для автоматического многоагентного контура обязательно добавь
   `references/continuous-audit.md` и `references/multi-agent-audit.md`.
5. Другие файлы из `references/` добавляй по текущей задаче. DOCX из `assets/` и
   Python из `scripts/` сохраняй как рабочие файлы.

Если платформа не создаёт независимые контексты, скилл остаётся работоспособным,
но аудит должен получить отметку `degraded_independence`.

## API и агентные фреймворки

Передай `PORTABLE-PROMPT.md` как постоянную инструкцию и предоставь модели
`SKILL.md` и нужные references через файловый поиск или базу знаний. Оркестратор
должен уметь создавать изолированные read-only задания, собирать JSON-отчёты и
возвращать их основному агенту.

OpenAI Skills API принимает каталог файлов или один ZIP-файл при создании навыка:
https://developers.openai.com/api/reference/python/resources/skills/methods/create

## Первый запуск

Пользователь пишет `$vkr-mpgu помоги начать ВКР с нуля` и отвечает на intake.
После ответов основной агент сам создаёт отдельную папку проекта, state, план,
черновики, каталоги источников и доказательств, audit manifest, roadmap, handoff,
журналы, exports и backups. Вручную создавать эту структуру не нужно.

В следующей локальной сессии открой ту же папку проекта. В веб-системе приложи
ZIP проекта либо state, handoff, roadmap, audit manifest и последнюю рабочую
главу. Скилл сверит хеши, восстановит следующий шаг и продолжит работу.

## Проверка установки

Правильная структура начинается так:

```text
vkr-mpgu/
├── SKILL.md
├── PORTABLE-PROMPT.md
├── agents/
├── references/
├── assets/
├── data/
└── scripts/
```

Частая ошибка — лишняя вложенность:
`.../skills/vkr-mpgu/vkr-mpgu/SKILL.md`. Перемести внутреннюю папку на один
уровень выше, чтобы `SKILL.md` лежал непосредственно в `vkr-mpgu`.

После запуска спроси: `какая версия скилла загружена?` Ожидаемый ответ:
`6.31-auto-workspace`.

SHA-256 официальных файлов поставки `.skill` и `.zip` должен совпадать со значением
в `AUTO-WORKSPACE-6.31-RU.md` рядом с архивами.
