#!/usr/bin/env python3
"""Создаёт безопасную рабочую структуру проекта ВКР.

Скрипт не перезаписывает существующие файлы. Его можно повторно запускать после
переноса проекта или частично завершённой инициализации.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


SKILL_VERSION = "6.31-auto-workspace"
AUDIT_PROTOCOL_VERSION = "6.30"
SKILL_ROOT = Path(__file__).resolve().parents[1]

DEFAULTS: dict[str, Any] = {
    "student_name": "",
    "institution": "",
    "institute": "",
    "program_code": "",
    "program_name": "",
    "supervisor": "",
    "topic": "",
    "vkr_type": "project",
    "profile": "generic",
    "mode": "standard",
    "audit_intensity": "strict",
    "deadline": "",
    "collective": False,
    "members": [],
}

ALLOWED_TYPES = {"project", "regular"}
ALLOWED_AUDIT = {"balanced", "strict", "maximum"}

DIRECTORIES = (
    "drafts",
    "sources/materials",
    "evidence/methodology",
    "evidence/product",
    "evidence/pilot",
    "audit/reports",
    "memory",
    "logs",
    "final",
    "exports",
    "backups/checkpoints",
)


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\x00", "").split())


def load_config(path: Path | None) -> dict[str, Any]:
    config = dict(DEFAULTS)
    if path is not None:
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("Config must be a JSON object")
        for key in DEFAULTS:
            if key in raw:
                config[key] = raw[key]

    for key in (
        "student_name",
        "institution",
        "institute",
        "program_code",
        "program_name",
        "supervisor",
        "topic",
        "profile",
        "mode",
        "audit_intensity",
        "deadline",
    ):
        config[key] = clean_text(config[key])

    config["vkr_type"] = clean_text(config["vkr_type"]).lower()
    if config["vkr_type"] not in ALLOWED_TYPES:
        raise ValueError("vkr_type must be project or regular")
    if config["audit_intensity"] not in ALLOWED_AUDIT:
        raise ValueError("audit_intensity must be balanced, strict or maximum")
    config["collective"] = bool(config["collective"])
    members = config.get("members", [])
    if not isinstance(members, list):
        raise ValueError("members must be an array")
    config["members"] = [clean_text(item) for item in members if clean_text(item)]
    return config


def apply_overrides(config: dict[str, Any], args: argparse.Namespace) -> None:
    for key in (
        "student_name",
        "institution",
        "program_code",
        "topic",
        "profile",
        "mode",
        "audit_intensity",
        "deadline",
        "vkr_type",
    ):
        value = getattr(args, key, None)
        if value is not None:
            config[key] = clean_text(value)
    if config["vkr_type"] not in ALLOWED_TYPES:
        raise ValueError("vkr_type must be project or regular")
    if config["audit_intensity"] not in ALLOWED_AUDIT:
        raise ValueError("audit_intensity must be balanced, strict or maximum")


def validate_root(root: Path) -> Path:
    resolved = root.expanduser().resolve(strict=False)
    skill_root = SKILL_ROOT.resolve()
    if resolved == skill_root or skill_root in resolved.parents:
        raise ValueError("Project must not be created inside the installed skill")
    if resolved.exists() and not resolved.is_dir():
        raise ValueError(f"Project path is not a directory: {resolved}")
    return resolved


def state_markdown(config: dict[str, Any], created: str) -> str:
    intake_status = (
        "captured"
        if config["topic"] and config["program_code"] and config["institution"]
        else "in_progress"
    )
    members = ", ".join(config["members"]) or "не указаны"
    return f"""# Состояние проекта ВКР

> Создано автоматически `vkr-mpgu {SKILL_VERSION}`. Подробная схема полей:
> `references/state-file-pattern.md` установленного скилла.

## Паспорт

- **Дата создания:** {created}
- **Статус intake:** {intake_status}
- **Студент:** {config['student_name'] or 'не указано'}
- **Участники коллективного проекта:** {members}
- **Вуз:** {config['institution'] or 'не указано'}
- **Институт/факультет:** {config['institute'] or 'не указано'}
- **Направление:** {config['program_code'] or 'не указано'} {config['program_name']}
- **Научный руководитель:** {config['supervisor'] or 'не указано'}
- **Тема:** {config['topic'] or 'не указано'}
- **Тип ВКР:** {config['vkr_type']}
- **Профиль требований:** {config['profile']}
- **Дедлайн:** {config['deadline'] or 'не указано'}
- **Режим:** {config['mode']}

## Текущий этап

- **Этап:** intake / plan
- **Следующее действие:** завершить intake и сформировать план
- **Открытые данные:** уточняются основным агентом по ходу интервью

## Структура работы

- **Введение:** не начато
- **Глава I:** не начато
- **Глава II:** не начато
{('- **Глава III:** не начато' + chr(10)) if config['vkr_type'] == 'project' else ''}- **Заключение:** не начато
- **Аннотация:** не начато
- **Список литературы:** 0 источников

## Независимый аудит

- **`audit_autorun`:** true
- **`audit_intensity`:** {config['audit_intensity']}
- **`protocol_version`:** {AUDIT_PROTOCOL_VERSION}
- **Режим независимости:** не определён
- **`active_run_status`:** planned
- **`pending_gates`:** intake
- **Итог:** не присвоен

## Память и продолжение

- **Handoff:** `memory/handoff.json`
- **Roadmap:** `memory/roadmap.md`
- **Последний memory checkpoint:** инициализация проекта
- **Следующее действие:** завершить intake и утвердить план

## Ключевые решения

- {created}: рабочая структура создана автоматически; существующие файлы не перезаписывать.

## История сессий

- {created}: инициализирован проект ВКР.
"""


def plan_markdown(config: dict[str, Any]) -> str:
    chapters = [
        "## Глава I. [Название]",
        "## Глава II. [Название]",
    ]
    if config["vkr_type"] == "project":
        chapters.append("## Глава III. [Название проектной главы]")
    body = "\n\n".join(chapters)
    return f"""# Рабочий план ВКР

> План уточняет основной агент после intake и сверки с методичкой программы.

## Введение

{body}

## Заключение

## Список использованной литературы

## Приложения
"""


def draft_files(config: dict[str, Any]) -> dict[str, str]:
    files = {
        "drafts/introduction.md": "# Введение\n\n<!-- Черновик создаёт основной агент после утверждения плана. -->\n",
        "drafts/chapter-1.md": "# Глава I. [Название]\n\n<!-- Черновик -->\n",
        "drafts/chapter-2.md": "# Глава II. [Название]\n\n<!-- Черновик -->\n",
        "drafts/conclusion.md": "# Заключение\n\n<!-- Черновик -->\n",
        "drafts/annotation.md": "# Аннотация\n\n<!-- Заполняется после основного текста. -->\n",
    }
    if config["vkr_type"] == "project":
        files["drafts/chapter-3.md"] = "# Глава III. [Название]\n\n<!-- Черновик проектной главы -->\n"
    return files


def initial_files(config: dict[str, Any], created: str) -> dict[str, str]:
    project_config = {"skill_version": SKILL_VERSION, **config}
    initial_handoff = {
        "schema_version": 1,
        "updated_at": created,
        "current_phase": "intake",
        "current_task": "Завершить intake и сформировать план",
        "last_completed": "Инициализация рабочей структуры",
        "next_actions": ["завершить intake", "сверить требования", "сформировать plan.md"],
        "open_questions": [],
        "open_blockers": [],
        "artifacts": {},
    }
    files = {
        "vkr-project.json": json.dumps(project_config, ensure_ascii=False, indent=2) + "\n",
        "vkr-state.md": state_markdown(config, created),
        "plan.md": plan_markdown(config),
        "sources.json": "[]\n",
        "evidence/index.json": json.dumps(
            {"methodology": [], "sources": [], "product": [], "pilot": []},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        "audit/snapshot-inputs.json": json.dumps(
            {
                "protocol_version": AUDIT_PROTOCOL_VERSION,
                "validation_profile": config["profile"],
                "inputs": [],
                "tool_versions": {},
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        "audit/manifest.json": json.dumps(
            {
                "protocol_version": AUDIT_PROTOCOL_VERSION,
                "skill_version": SKILL_VERSION,
                "snapshot_manifest_sha256": None,
                "runs": [],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        "memory/handoff.json": json.dumps(initial_handoff, ensure_ascii=False, indent=2) + "\n",
        "memory/handoff.md": """# Передача контекста следующему чату

- **Текущая фаза:** intake
- **Текущее задание:** завершить intake и сформировать план
- **Последнее завершённое:** инициализация рабочей структуры

## Следующие действия

- завершить intake
- сверить требования программы
- сформировать `plan.md`

Перед продолжением запусти `scripts/vkr_memory.py <project> status --json`.
""",
        "memory/roadmap.md": """# Roadmap ВКР

| Этап | Статус | Условие завершения |
|---|---|---|
| Intake и профиль требований | IN_PROGRESS | state заполнен, требования сверены |
| План | NOT_STARTED | план согласован и прошёл gate |
| Черновик глав | NOT_STARTED | все главы имеют законченный текст |
| Источники и доказательства | NOT_STARTED | все тезисы имеют проверяемые основания |
| Полировка и независимый аудит | NOT_STARTED | BLOCKER/MAJOR закрыты свежим recheck |
| DOCX и нормоконтроль | NOT_STARTED | финальный файл прошёл проверки |
| Подготовка к защите | NOT_STARTED | пользователь прошёл Test-30 и репетицию |
""",
        "memory/decisions.jsonl": "",
        "memory/claims-register.json": "[]\n",
        "memory/artifact-index.json": json.dumps(
            {"schema_version": 1, "updated_at": None, "artifacts": {}},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        "logs/activity.jsonl": json.dumps(
            {
                "event_type": "project_initialized",
                "timestamp": created,
                "actor": "primary_agent",
                "summary": "Создана рабочая структура проекта ВКР",
                "skill_version": SKILL_VERSION,
            },
            ensure_ascii=False,
            separators=(",", ":"),
        )
        + "\n",
        "logs/tool-runs.jsonl": "",
    }
    files.update(draft_files(config))

    tracked = (
        "vkr-project.json",
        "vkr-state.md",
        "plan.md",
        "sources.json",
        "evidence/index.json",
        "audit/snapshot-inputs.json",
        "audit/manifest.json",
    )
    artifacts = {}
    for relative in tracked:
        encoded = files[relative].encode("utf-8")
        artifacts[relative] = {
            "sha256": hashlib.sha256(encoded).hexdigest(),
            "size": len(encoded),
            "recorded_at": created,
        }
    initial_handoff["artifacts"] = artifacts
    files["memory/handoff.json"] = json.dumps(initial_handoff, ensure_ascii=False, indent=2) + "\n"
    files["memory/artifact-index.json"] = json.dumps(
        {"schema_version": 1, "updated_at": created, "artifacts": artifacts},
        ensure_ascii=False,
        indent=2,
    ) + "\n"
    return files


def initialize(root: Path, config: dict[str, Any], dry_run: bool = False) -> dict[str, Any]:
    root = validate_root(root)
    created_date = dt.date.today().isoformat()
    created: list[str] = []
    skipped: list[str] = []

    if not dry_run:
        root.mkdir(parents=True, exist_ok=True)
    for relative in DIRECTORIES:
        path = root / relative
        if path.is_dir():
            skipped.append(relative + "/")
        else:
            created.append(relative + "/")
            if not dry_run:
                path.mkdir(parents=True, exist_ok=True)

    for relative, content in initial_files(config, created_date).items():
        path = root / relative
        if path.exists():
            skipped.append(relative)
            continue
        created.append(relative)
        if not dry_run:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("x", encoding="utf-8", newline="\n") as stream:
                stream.write(content)

    return {
        "status": "dry_run" if dry_run else "initialized",
        "skill_version": SKILL_VERSION,
        "project_root": str(root),
        "created": created,
        "skipped_existing": skipped,
        "next_action": "complete_intake_and_plan",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_dir", type=Path, help="Каталог отдельного проекта ВКР")
    parser.add_argument("--config", type=Path, help="JSON с ответами intake")
    parser.add_argument("--student-name")
    parser.add_argument("--institution")
    parser.add_argument("--program-code")
    parser.add_argument("--topic")
    parser.add_argument("--vkr-type", choices=sorted(ALLOWED_TYPES))
    parser.add_argument("--profile")
    parser.add_argument("--mode")
    parser.add_argument("--audit-intensity", choices=sorted(ALLOWED_AUDIT))
    parser.add_argument("--deadline")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--json", action="store_true", dest="json_output")
    return parser


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = build_parser()
    args = parser.parse_args()
    try:
        config = load_config(args.config)
        apply_overrides(config, args)
        result = initialize(args.project_dir, config, args.dry_run)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        if args.json_output:
            print(json.dumps({"status": "error", "error": str(error)}, ensure_ascii=False))
        else:
            print(f"ERROR: {error}", file=sys.stderr)
        return 2

    if args.json_output:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Project: {result['project_root']}")
        print(f"Created: {len(result['created'])}")
        print(f"Skipped existing: {len(result['skipped_existing'])}")
        print("Next: complete intake and approve the plan")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
