#!/usr/bin/env python3
"""Read-only диагностика рабочей структуры проекта ВКР."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any


REQUIRED_FILES = (
    "vkr-project.json",
    "vkr-state.md",
    "plan.md",
    "sources.json",
    "evidence/index.json",
    "audit/snapshot-inputs.json",
    "audit/manifest.json",
    "memory/handoff.json",
    "memory/handoff.md",
    "memory/roadmap.md",
    "memory/decisions.jsonl",
    "memory/claims-register.json",
    "memory/artifact-index.json",
    "logs/activity.jsonl",
    "logs/tool-runs.jsonl",
)

REQUIRED_DIRS = (
    "drafts",
    "sources/materials",
    "evidence/methodology",
    "evidence/product",
    "evidence/pilot",
    "audit/reports",
    "memory",
    "logs",
    "final",
    "exports",
    "backups/checkpoints",
)

JSON_FILES = (
    "vkr-project.json",
    "sources.json",
    "evidence/index.json",
    "audit/snapshot-inputs.json",
    "audit/manifest.json",
    "memory/handoff.json",
    "memory/claims-register.json",
    "memory/artifact-index.json",
)

JSONL_FILES = (
    "memory/decisions.jsonl",
    "logs/activity.jsonl",
    "logs/tool-runs.jsonl",
)

PLACEHOLDER_PATTERNS = (
    re.compile(r"\[ПРОВЕРИТЬ\]", re.IGNORECASE),
    re.compile(r"\[Название[^\]]*\]", re.IGNORECASE),
    re.compile(r"<!--\s*(?:Черновик|Заполняется)", re.IGNORECASE),
    re.compile(r"\bTODO\b", re.IGNORECASE),
    re.compile(r"\bXXX\b", re.IGNORECASE),
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_snapshot_sha(snapshot: Any) -> str | None:
    if not isinstance(snapshot, dict):
        return None
    inputs = snapshot.get("inputs", [])
    if not isinstance(inputs, list):
        return None
    normalized_inputs = []
    for item in inputs:
        if not isinstance(item, dict):
            return None
        normalized_inputs.append(
            {
                "logical_id": item.get("logical_id"),
                "kind": item.get("kind"),
                "sha256": item.get("sha256"),
            }
        )
    projection = {
        "protocol_version": snapshot.get("protocol_version"),
        "validation_profile": snapshot.get("validation_profile"),
        "inputs": sorted(normalized_inputs, key=lambda item: (str(item["logical_id"]), str(item["kind"]), str(item["sha256"]))),
        "tool_versions": snapshot.get("tool_versions", {}),
    }
    encoded = json.dumps(projection, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_title(value: Any) -> str:
    return "".join(character for character in str(value or "").casefold() if character.isalnum())


def finding(code: str, severity: str, path: str, message: str) -> dict[str, str]:
    return {"code": code, "severity": severity, "path": path, "message": message}


def load_json(root: Path, relative: str, findings: list[dict[str, str]]) -> Any:
    path = root / relative
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        findings.append(finding("JSON_INVALID", "ERROR", relative, str(error)))
        return None


def check_structure(root: Path, findings: list[dict[str, str]]) -> None:
    for relative in REQUIRED_FILES:
        if not (root / relative).is_file():
            findings.append(finding("FILE_MISSING", "ERROR", relative, "Обязательный файл отсутствует"))
    for relative in REQUIRED_DIRS:
        if not (root / relative).is_dir():
            findings.append(finding("DIR_MISSING", "ERROR", relative, "Обязательный каталог отсутствует"))


def check_json_shapes(root: Path, data: dict[str, Any], findings: list[dict[str, str]]) -> None:
    project = data.get("vkr-project.json")
    if project is not None and not isinstance(project, dict):
        findings.append(finding("PROJECT_CONFIG_SHAPE", "ERROR", "vkr-project.json", "Ожидается JSON-объект"))
    elif isinstance(project, dict):
        if project.get("vkr_type") not in {"project", "regular"}:
            findings.append(finding("PROJECT_TYPE_INVALID", "ERROR", "vkr-project.json", "vkr_type должен быть project или regular"))
        for key in ("skill_version", "profile", "mode"):
            if not str(project.get(key) or "").strip():
                findings.append(finding("PROJECT_FIELD_MISSING", "ERROR", "vkr-project.json", f"Нет поля {key}"))
    sources = data.get("sources.json")
    if sources is not None and not isinstance(sources, list):
        findings.append(finding("SOURCES_SHAPE", "ERROR", "sources.json", "Ожидается JSON-массив"))
    evidence = data.get("evidence/index.json")
    if evidence is not None and not isinstance(evidence, dict):
        findings.append(finding("EVIDENCE_SHAPE", "ERROR", "evidence/index.json", "Ожидается JSON-объект"))
    elif isinstance(evidence, dict):
        for key in ("methodology", "sources", "product", "pilot"):
            if key in evidence and not isinstance(evidence[key], list):
                findings.append(finding("EVIDENCE_LIST_SHAPE", "ERROR", "evidence/index.json", f"{key} должен быть массивом"))
    for relative in ("audit/snapshot-inputs.json", "audit/manifest.json", "memory/handoff.json", "memory/artifact-index.json"):
        if data.get(relative) is not None and not isinstance(data[relative], dict):
            findings.append(finding("JSON_OBJECT_REQUIRED", "ERROR", relative, "Ожидается JSON-объект"))
    snapshot = data.get("audit/snapshot-inputs.json")
    if isinstance(snapshot, dict):
        if not isinstance(snapshot.get("inputs", []), list):
            findings.append(finding("SNAPSHOT_INPUTS_SHAPE", "ERROR", "audit/snapshot-inputs.json", "inputs должен быть массивом"))
        else:
            for index, item in enumerate(snapshot.get("inputs", []), start=1):
                if not isinstance(item, dict) or not all(str(item.get(key) or "").strip() for key in ("logical_id", "kind", "sha256")):
                    findings.append(finding("SNAPSHOT_INPUT_INVALID", "ERROR", f"audit/snapshot-inputs.json:inputs[{index}]", "У входа нужны logical_id, kind и sha256"))
    manifest = data.get("audit/manifest.json")
    if isinstance(manifest, dict) and not isinstance(manifest.get("runs", []), list):
        findings.append(finding("AUDIT_RUNS_SHAPE", "ERROR", "audit/manifest.json", "runs должен быть массивом"))
    claims = data.get("memory/claims-register.json")
    if claims is not None and not isinstance(claims, list):
        findings.append(finding("CLAIMS_SHAPE", "ERROR", "memory/claims-register.json", "Ожидается JSON-массив"))


def check_jsonl(root: Path, findings: list[dict[str, str]]) -> None:
    for relative in JSONL_FILES:
        path = root / relative
        if not path.is_file():
            continue
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as error:
                findings.append(
                    finding(
                        "JSONL_INVALID",
                        "ERROR",
                        f"{relative}:{line_number}",
                        str(error),
                    )
                )
                continue
            if not isinstance(item, dict):
                findings.append(
                    finding(
                        "JSONL_SHAPE",
                        "ERROR",
                        f"{relative}:{line_number}",
                        "Каждая строка должна быть JSON-объектом",
                    )
                )


def check_state(root: Path, stage: str, findings: list[dict[str, str]]) -> None:
    path = root / "vkr-state.md"
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    for marker in ("Тема", "Профиль требований", "Режим", "audit_intensity", "protocol_version"):
        if marker not in text:
            findings.append(finding("STATE_FIELD_MISSING", "ERROR", "vkr-state.md", f"Не найдено поле: {marker}"))
    if "не указано" in text.casefold():
        severity = "WARNING" if stage == "draft" else "ERROR"
        findings.append(finding("STATE_INCOMPLETE", severity, "vkr-state.md", "Остались незаполненные паспортные данные"))


def check_sources(sources: Any, stage: str, findings: list[dict[str, str]]) -> None:
    if not isinstance(sources, list):
        return
    if not sources and stage in {"prefinal", "final"}:
        findings.append(finding("SOURCES_EMPTY", "ERROR", "sources.json", "Список источников пуст"))
    seen: dict[str, int] = {}
    for index, source in enumerate(sources, start=1):
        path = f"sources.json[{index}]"
        if not isinstance(source, dict):
            findings.append(finding("SOURCE_SHAPE", "ERROR", path, "Источник должен быть JSON-объектом"))
            continue
        title = source.get("title") or source.get("raw_text")
        if not title:
            severity = "WARNING" if stage == "draft" else "ERROR"
            findings.append(finding("SOURCE_TITLE_MISSING", severity, path, "Нет title или raw_text"))
            continue
        doi = str(source.get("doi") or "").strip().casefold()
        key = "doi:" + doi if doi else "title:" + normalize_title(title)
        if key in seen:
            findings.append(
                finding("SOURCE_DUPLICATE", "WARNING", path, f"Возможный дубликат позиции {seen[key]}")
            )
        else:
            seen[key] = index
        status = str(source.get("status") or "").casefold()
        if stage in {"prefinal", "final"} and status not in {"confirmed", "verified"}:
            findings.append(
                finding(
                    "SOURCE_NOT_CONFIRMED",
                    "ERROR",
                    path,
                    "Перед финальным gate источник должен иметь status=confirmed или verified",
                )
            )


def check_placeholders(root: Path, stage: str, findings: list[dict[str, str]]) -> None:
    targets = [root / "plan.md", *sorted((root / "drafts").glob("*.md"))]
    for path in targets:
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8")
        count = sum(len(pattern.findall(text)) for pattern in PLACEHOLDER_PATTERNS)
        if count:
            severity = "INFO" if stage == "draft" else "ERROR"
            findings.append(
                finding("PLACEHOLDER_FOUND", severity, path.relative_to(root).as_posix(), f"Найдено маркеров: {count}")
            )


def check_text_outputs(root: Path, stage: str, findings: list[dict[str, str]]) -> None:
    if stage not in {"prefinal", "final"}:
        return
    plan = root / "plan.md"
    if not plan.read_text(encoding="utf-8").strip():
        findings.append(finding("PLAN_EMPTY", "ERROR", "plan.md", "План работы пуст"))
    for path in sorted((root / "drafts").glob("*.md")):
        if not path.read_text(encoding="utf-8").strip():
            findings.append(finding("DRAFT_EMPTY", "ERROR", path.relative_to(root).as_posix(), "Файл раздела пуст"))


def check_memory(root: Path, data: dict[str, Any], stage: str, findings: list[dict[str, str]]) -> None:
    index = data.get("memory/artifact-index.json")
    if not isinstance(index, dict):
        return
    for logical_id, recorded in index.get("artifacts", {}).items():
        path = (root / logical_id).resolve(strict=False)
        try:
            path.relative_to(root)
        except ValueError:
            findings.append(finding("MEMORY_PATH_OUTSIDE", "ERROR", logical_id, "Путь выходит за корень проекта"))
            continue
        if not path.is_file():
            findings.append(finding("ARTIFACT_MISSING", "ERROR", logical_id, "Зафиксированный файл исчез"))
            continue
        current = file_sha256(path)
        if current != recorded.get("sha256"):
            severity = "WARNING" if stage == "draft" else "ERROR"
            findings.append(finding("ARTIFACT_CHANGED", severity, logical_id, "SHA-256 не совпадает с memory index"))


def task_statuses(manifest: dict[str, Any]) -> list[str]:
    statuses: list[str] = []
    for run in manifest.get("runs", []):
        if not isinstance(run, dict):
            continue
        for task in run.get("planned_tasks", []):
            if isinstance(task, dict):
                statuses.append(str(task.get("status") or "missing"))
    return statuses


def check_audit(snapshot: Any, manifest: Any, stage: str, findings: list[dict[str, str]]) -> None:
    if not isinstance(manifest, dict):
        return
    expected_snapshot_sha = canonical_snapshot_sha(snapshot)
    actual_snapshot_sha = manifest.get("snapshot_manifest_sha256")
    if actual_snapshot_sha and expected_snapshot_sha and actual_snapshot_sha != expected_snapshot_sha:
        findings.append(
            finding(
                "AUDIT_SNAPSHOT_HASH_MISMATCH",
                "ERROR",
                "audit/manifest.json",
                "snapshot_manifest_sha256 не соответствует каноническому snapshot-inputs.json",
            )
        )
    runs = manifest.get("runs", [])
    if not isinstance(runs, list):
        findings.append(finding("AUDIT_RUNS_SHAPE", "ERROR", "audit/manifest.json", "runs должен быть массивом"))
        return
    if stage == "final" and not runs:
        findings.append(finding("AUDIT_FINAL_MISSING", "ERROR", "audit/manifest.json", "Нет финального audit-run"))
    if stage == "final" and runs:
        latest = runs[-1] if isinstance(runs[-1], dict) else {}
        if latest.get("status") != "complete":
            findings.append(finding("AUDIT_FINAL_INCOMPLETE", "ERROR", "audit/manifest.json", "Последний run не имеет status=complete"))
        tasks = latest.get("planned_tasks", []) if isinstance(latest, dict) else []
        gates = {task.get("base_gate") for task in tasks if isinstance(task, dict)}
        expected = {"MET", "SRC", "LOG", "LNG", "STY", "EVD", "TEC", "DOC", "OWN"}
        missing = sorted(expected - gates)
        if missing:
            findings.append(finding("AUDIT_GATES_MISSING", "ERROR", "audit/manifest.json", "Нет финальных gate: " + ", ".join(missing)))
        if not manifest.get("snapshot_manifest_sha256"):
            findings.append(finding("AUDIT_SNAPSHOT_HASH_MISSING", "ERROR", "audit/manifest.json", "Нет snapshot_manifest_sha256"))
    blocked = {"planned", "running", "fail", "partial", "not_recheckable", "interrupted", "error", "cancelled", "missing"}
    open_statuses = sorted(set(task_statuses(manifest)) & blocked)
    if open_statuses and stage in {"prefinal", "final"}:
        findings.append(
            finding("AUDIT_TASKS_OPEN", "ERROR", "audit/manifest.json", "Незавершённые статусы: " + ", ".join(open_statuses))
        )
    for run in runs:
        if not isinstance(run, dict):
            continue
        if run.get("targeted_recheck_queue") or run.get("blind_regression_queue"):
            severity = "WARNING" if stage == "draft" else "ERROR"
            findings.append(finding("AUDIT_RECHECK_PENDING", severity, "audit/manifest.json", "Очереди recheck не пусты"))
    if stage == "final" and runs:
        allowed = {"pass", "passed", "complete", "not_applicable"}
        unknown = sorted(
            {
                str(task.get("status") or "missing").casefold()
                for task in (runs[-1].get("planned_tasks", []) if isinstance(runs[-1], dict) else [])
                if isinstance(task, dict)
                and str(task.get("status") or "missing").casefold() not in allowed
            }
        )
        if unknown:
            findings.append(
                finding(
                    "AUDIT_TASK_STATUS_INVALID",
                    "ERROR",
                    "audit/manifest.json",
                    "Недопустимые статусы gate: " + ", ".join(unknown),
                )
            )


def check_claims(claims: Any, stage: str, findings: list[dict[str, str]]) -> None:
    if not isinstance(claims, list):
        return
    if not claims and stage == "final":
        findings.append(finding("CLAIMS_EMPTY", "ERROR", "memory/claims-register.json", "Нет реестра ключевых утверждений"))
    for index, claim in enumerate(claims, start=1):
        if not isinstance(claim, dict):
            findings.append(finding("CLAIM_SHAPE", "ERROR", f"claims[{index}]", "Claim должен быть объектом"))
            continue
        status = claim.get("status")
        if status in {"unsupported", "invalidated"}:
            severity = "WARNING" if stage == "draft" else "ERROR"
            findings.append(finding("CLAIM_UNSUPPORTED", severity, f"claims[{index}]", f"Статус: {status}"))
        elif status == "partial" and stage == "final":
            findings.append(finding("CLAIM_PARTIAL", "ERROR", f"claims[{index}]", "Частично подтверждённый тезис"))
        if stage == "final" and status not in {"confirmed", "verified"}:
            findings.append(finding("CLAIM_NOT_CONFIRMED", "ERROR", f"claims[{index}]", "Ключевое утверждение не подтверждено"))
        if stage == "final" and not (claim.get("evidence") or claim.get("source_ids") or claim.get("evidence_ids")):
            findings.append(finding("CLAIM_EVIDENCE_MISSING", "ERROR", f"claims[{index}]", "У утверждения нет ссылки на evidence/source"))


def check_final(root: Path, stage: str, findings: list[dict[str, str]]) -> None:
    if stage != "final":
        return
    docx = list((root / "final").glob("*.docx"))
    if not docx:
        findings.append(finding("FINAL_DOCX_MISSING", "ERROR", "final/", "Нет сдаваемого DOCX"))
        return
    for path in docx:
        if not zipfile.is_zipfile(path):
            findings.append(finding("FINAL_DOCX_INVALID", "ERROR", path.relative_to(root).as_posix(), "Файл не является корректным DOCX/ZIP"))
            continue
        with zipfile.ZipFile(path) as archive:
            broken = archive.testzip()
        if broken:
            findings.append(finding("FINAL_DOCX_CORRUPT", "ERROR", path.relative_to(root).as_posix(), f"Повреждённый элемент архива: {broken}"))


def diagnose(root: Path, stage: str) -> dict[str, Any]:
    root = root.expanduser().resolve(strict=True)
    findings: list[dict[str, str]] = []
    check_structure(root, findings)
    data = {relative: load_json(root, relative, findings) for relative in JSON_FILES}
    check_json_shapes(root, data, findings)
    check_jsonl(root, findings)
    check_state(root, stage, findings)
    check_sources(data.get("sources.json"), stage, findings)
    check_placeholders(root, stage, findings)
    check_text_outputs(root, stage, findings)
    check_memory(root, data, stage, findings)
    check_audit(data.get("audit/snapshot-inputs.json"), data.get("audit/manifest.json"), stage, findings)
    check_claims(data.get("memory/claims-register.json"), stage, findings)
    check_final(root, stage, findings)

    counts = {severity: sum(item["severity"] == severity for item in findings) for severity in ("ERROR", "WARNING", "INFO")}
    return {
        "status": "FAIL" if counts["ERROR"] else "PASS",
        "stage": stage,
        "project_root": str(root),
        "counts": counts,
        "findings": findings,
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_dir", type=Path)
    parser.add_argument("--stage", choices=("draft", "prefinal", "final"), default="draft")
    parser.add_argument("--json", action="store_true", dest="json_output")
    args = parser.parse_args()
    try:
        result = diagnose(args.project_dir, args.stage)
    except (OSError, ValueError) as error:
        result = {"status": "ERROR", "error": str(error)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2
    if args.json_output:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"{result['status']}: {result['counts']}")
        for item in result["findings"]:
            print(f"{item['severity']} {item['code']} {item['path']}: {item['message']}")
    return 1 if result["status"] == "FAIL" else 0


if __name__ == "__main__":
    raise SystemExit(main())
