#!/usr/bin/env python3
"""
ai_detection_heuristic.py — Стайл-чекер на известные паттерны ИИ-генерации.

ЧТО ЭТОТ СКРИПТ ДЕЛАЕТ (честная декларация):
  Проверяет текст на наличие известных паттернов, характерных для LLM-генерации:
  низкая burstiness, типичные ИИ-клише и N-граммы, бедное лексическое разнообразие,
  монотонный ритм абзацев, неудачное распределение авторских якорьков.

ЧТО ЭТОТ СКРИПТ НЕ ДЕЛАЕТ:
  - НЕ симулирует реальный Антиплагиат.Вуз (его архитектура не раскрыта публично)
  - НЕ гарантирует, что LOW-результат == работа пройдёт детектор
  - НЕ заменяет ручную проверку текста

ЦЕЛЬ: Быстрый самопроверочный чек «не похоже ли очевидно на LLM». Если скрипт
показывает HIGH/CRITICAL — работа точно не пройдёт. Если LOW — риск снижен,
но не нулевой. Это необходимое, но недостаточное условие.

МЕТРИКИ (все — эвристические, пороги откалиброваны на примерах человек vs LLM):
    1. Burstiness:           CV длин абзацев, CV длин предложений
    2. Плотность N-грамм:    29 сильных + средних ИИ-клише
    3. Лексическое:          TTR, MTLD (упрощённый), overused-слова
    4. Ритм:                 длинные серии однородных абзацев
    5. Якорьки:              плотность (не слишком много, но и есть)
    6. Starter variety:      разнообразие начал предложений
    7. Passive voice ratio:  LLM любит пассивные конструкции
    8. Readability proxy:    длина предложений vs средняя длина слова

Использование:
    python ai_detection_heuristic.py vkr.docx
    python ai_detection_heuristic.py vkr.docx --section introduction
    python ai_detection_heuristic.py vkr.docx --json

НЕ доверяй одному результату. Прогоняй до и после правок, сравнивай тренд.
"""

import sys
import re
import json
import argparse
import statistics
from pathlib import Path
from collections import Counter

try:
    from docx import Document
except ImportError:
    print("ERROR: python-docx не установлен. pip install python-docx")
    sys.exit(1)


# ========== СЛОВАРИ ==========

AI_CLICHES_PATH = Path(__file__).resolve().parent.parent / "data" / "ai_cliches.json"


def _load_ai_ngrams():
    """Загрузка N-грамм из централизованного data/ai_cliches.json.
    Единый источник истины с validate_vkr.py. При сбое загрузки —
    минимальный встроенный fallback, чтобы детектор не падал.

    Возвращает кортеж (strong_list, medium_list).
    """
    try:
        with open(AI_CLICHES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("strong", []), data.get("medium", [])
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(
            f"ВНИМАНИЕ: не удалось загрузить {AI_CLICHES_PATH}: {e}",
            file=sys.stderr,
        )
        print("Используется минимальный fallback-список N-грамм.", file=sys.stderr)
        fallback_strong = [
            "стоит отметить",
            "важно отметить",
            "важно подчеркнуть",
            "следует отметить",
            "необходимо отметить",
            "в современном мире",
            "давайте рассмотрим",
            "как мы можем видеть",
            "в эпоху стремительного",
            "благодаря развитию информационных технологий",
        ]
        fallback_medium = [
            "в свою очередь",
            "вместе с тем",
            "таким образом",
            "на сегодняшний день",
            "существует множество",
            "играет важную роль",
            "обладает рядом преимуществ",
            "современные технологии позволяют",
            "рассматриваемый подход",
            "позволяет значительно оптимизировать",
        ]
        return fallback_strong, fallback_medium


# N-граммы, типичные для ИИ-текста на русском академическом
AI_NGRAMS_STRONG, AI_NGRAMS_MEDIUM = _load_ai_ngrams()

AI_WORDS_OVERUSED = {
    "ключевой", "важный", "значительный", "существенный", "комплексный",
    "эффективный", "инновационный", "актуальный", "современный", "системный",
    "оптимальный", "уникальный", "универсальный",
}

# Слова-индикаторы авторской позиции (якорьки)
# ВНИМАНИЕ (v6.16): это **fallback**-список общих оборотов для случаев,
# когда в state-файле НЕТ personal_style_profile (первая сессия, минимальный intake).
# Фразы здесь **общие**, использовать их буквально — риск кросс-матчинга
# (разные пользователи скилла получат одни и те же обороты в похожих позициях).
#
# Правильное поведение Claude: сначала пытаться читать personal_style_profile из
# state-файла пользователя и использовать ЕГО индивидуальные якорьки.
# Этот список — только для грубой оценки наличия/отсутствия авторской позиции
# в тексте, не для рекомендаций.
#
# Удалены в v6.11: «на наш взгляд», «по нашему мнению» (запрещено методичкой).
# Удалены в v6.16: «представляется обоснованным», «представляется целесообразным»,
# «в контексте настоящей работы» — они же фигурируют в humanizer-techniques.md:164
# и intake-interview.md как примеры с явным предупреждением «не копировать буквально».
# Оставлять их в положительном списке — значит награждать буквальное копирование.
AUTHOR_ANCHORS = [
    "в рассматриваемом контексте",
    "данное соображение учитывалось",
    "необходимо оговориться",
    "при всех оговорках",
    "если следовать данной логике",
    "с точки зрения практической",
    "с учётом сказанного",
    "с позиции научной",
    "представляется небеспочвенным",
]

# Личные местоимения (не должны встречаться)
PERSONAL_PRONOUNS = [
    r"\bя\b", r"\bмне\b", r"\bменя\b", r"\bмной\b",
    r"\bмы\b", r"\bнас\b", r"\bнам\b", r"\bнами\b",
]


# ========== АНАЛИЗ ТЕКСТА ==========

def split_sentences(text: str) -> list:
    """Разбить текст на предложения."""
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if s.strip() and len(s) > 5]


def split_paragraphs_from_doc(doc: Document) -> list:
    """Собрать абзацы из документа, игнорируя заголовки и пустые."""
    paragraphs = []
    for p in doc.paragraphs:
        text = p.text.strip()
        if len(text) < 30:  # заголовки и короткие метки игнорируем
            continue
        paragraphs.append(text)
    return paragraphs


def compute_burstiness(paragraphs: list) -> dict:
    """
    Burstiness = CV (coefficient of variation) длин.
    Человеческий текст: CV > 0.35
    ИИ-текст: CV < 0.25 обычно.
    """
    if not paragraphs:
        return {"error": "Нет абзацев для анализа"}

    # Длина абзацев в символах
    para_lens = [len(p) for p in paragraphs]
    para_mean = statistics.mean(para_lens) if para_lens else 0
    para_stdev = statistics.stdev(para_lens) if len(para_lens) > 1 else 0
    para_cv = para_stdev / para_mean if para_mean > 0 else 0

    # Длина предложений в словах
    all_sentences = []
    for p in paragraphs:
        all_sentences.extend(split_sentences(p))

    sent_lens = [len(s.split()) for s in all_sentences]
    sent_mean = statistics.mean(sent_lens) if sent_lens else 0
    sent_stdev = statistics.stdev(sent_lens) if len(sent_lens) > 1 else 0
    sent_cv = sent_stdev / sent_mean if sent_mean > 0 else 0

    # Оценка
    verdict = "human-like"
    if para_cv < 0.25 or sent_cv < 0.30:
        verdict = "AI-like (too uniform)"
    elif para_cv < 0.35 or sent_cv < 0.40:
        verdict = "slightly suspicious"

    return {
        "paragraph_count": len(paragraphs),
        "paragraph_mean_chars": round(para_mean, 1),
        "paragraph_stdev_chars": round(para_stdev, 1),
        "paragraph_cv": round(para_cv, 3),
        "sentence_count": len(all_sentences),
        "sentence_mean_words": round(sent_mean, 1),
        "sentence_stdev_words": round(sent_stdev, 1),
        "sentence_cv": round(sent_cv, 3),
        "verdict": verdict,
    }


def compute_ngram_density(text: str) -> dict:
    """Плотность характерных ИИ-N-грамм."""
    text_lower = text.lower()
    total_words = len(text.split())

    strong_hits = []
    for ng in AI_NGRAMS_STRONG:
        count = text_lower.count(ng)
        if count > 0:
            strong_hits.append((ng, count))

    medium_hits = []
    for ng in AI_NGRAMS_MEDIUM:
        count = text_lower.count(ng)
        if count > 0:
            medium_hits.append((ng, count))

    total_strong = sum(c for _, c in strong_hits)
    total_medium = sum(c for _, c in medium_hits)

    # Плотность: клише на 1000 слов
    strong_per_1k = (total_strong / total_words * 1000) if total_words > 0 else 0
    medium_per_1k = (total_medium / total_words * 1000) if total_words > 0 else 0

    # Оценка
    verdict = "acceptable"
    if strong_per_1k > 0.5:
        verdict = "AI-like (too many strong cliches)"
    elif strong_per_1k > 0.2 or medium_per_1k > 3.0:
        verdict = "slightly suspicious"

    return {
        "total_words": total_words,
        "strong_cliches_count": total_strong,
        "medium_cliches_count": total_medium,
        "strong_per_1k_words": round(strong_per_1k, 2),
        "medium_per_1k_words": round(medium_per_1k, 2),
        "top_strong": sorted(strong_hits, key=lambda x: -x[1])[:5],
        "top_medium": sorted(medium_hits, key=lambda x: -x[1])[:5],
        "verdict": verdict,
    }


def compute_lexical_diversity(text: str) -> dict:
    """
    Лексическое разнообразие: TTR (type-token ratio) и MTLD-like метрика.
    Человеческий текст на 10000 слов: TTR ~0.35-0.55
    ИИ-текст: TTR ниже, словарь беднее.
    """
    # Нормализация: только слова, в нижнем регистре
    words = re.findall(r'\b[а-яёa-z]+\b', text.lower())
    total_words = len(words)

    if total_words < 100:
        return {"error": "Слишком мало слов для оценки"}

    unique_words = set(words)
    ttr = len(unique_words) / total_words

    # MTLD-подобная метрика: средняя длина «отрезка» с TTR > 0.72
    # (упрощённый вариант)
    def mtld_segment(tokens, threshold=0.72):
        types = set()
        token_count = 0
        factors = 0
        for w in tokens:
            types.add(w)
            token_count += 1
            if token_count > 0 and len(types) / token_count < threshold:
                factors += 1
                types = set()
                token_count = 0
        if token_count > 0:
            factors += (1 - len(types) / token_count) / (1 - threshold)
        return len(tokens) / factors if factors > 0 else len(tokens)

    mtld = mtld_segment(words)

    # Проверка на пересыщение "слов-паразитов" ИИ
    overused_count = sum(1 for w in words if w in AI_WORDS_OVERUSED)
    overused_per_1k = (overused_count / total_words * 1000) if total_words > 0 else 0

    verdict = "diverse"
    if ttr < 0.18 or mtld < 45:
        verdict = "AI-like (poor vocabulary)"
    elif ttr < 0.25 or mtld < 60:
        verdict = "slightly poor"

    if overused_per_1k > 12:
        verdict += "; overused buzzwords"

    return {
        "total_words": total_words,
        "unique_words": len(unique_words),
        "type_token_ratio": round(ttr, 3),
        "mtld_approx": round(mtld, 1),
        "overused_words_per_1k": round(overused_per_1k, 2),
        "verdict": verdict,
    }


def compute_author_anchors(text: str) -> dict:
    """Плотность авторских якорьков — не перебор ли?"""
    text_lower = text.lower()
    total_words = len(text.split())

    anchor_hits = []
    for anchor in AUTHOR_ANCHORS:
        count = text_lower.count(anchor)
        if count > 0:
            anchor_hits.append((anchor, count))

    total = sum(c for _, c in anchor_hits)
    per_1k = (total / total_words * 1000) if total_words > 0 else 0

    verdict = "balanced"
    if per_1k > 1.5:
        verdict = "too many (sounds like PhD, not bachelor)"
    elif per_1k < 0.2 and total_words > 3000:
        verdict = "no author voice (sounds AI-generic)"

    return {
        "total_anchors": total,
        "unique_anchors_used": len(anchor_hits),
        "anchors_per_1k_words": round(per_1k, 2),
        "hits": sorted(anchor_hits, key=lambda x: -x[1]),
        "verdict": verdict,
    }


def check_pronouns(text: str) -> dict:
    """Проверка личных местоимений (должно быть 0).

    Важно: инициалы типа «И.Я.», «Я.Л.» удаляются из текста перед
    проверкой, иначе regex \\bя\\b с re.IGNORECASE триггерит на «Я»
    в инициалах педагогов-классиков (Лернер И.Я., Коломинский Я.Л.).
    """
    # Фильтрация инициалов: «И.Я.», «И. Я.», «А.Б.В.»
    initial_pattern = re.compile(
        r"\b[А-ЯЁA-Z]\.\s?[А-ЯЁA-Z]\.(?:\s?[А-ЯЁA-Z]\.)?"
    )
    clean_text = initial_pattern.sub(" ", text)
    # Одиночные инициалы перед фамилией
    clean_text = re.sub(r"\b[А-ЯЁA-Z]\.", " ", clean_text)

    found = []
    for pat in PERSONAL_PRONOUNS:
        matches = re.findall(pat, clean_text, re.IGNORECASE)
        if matches:
            found.append((pat.strip(r'\b'), len(matches)))

    return {
        "found_pronouns": found,
        "total": sum(c for _, c in found),
        "verdict": "clean" if not found else "BAD: personal pronouns present",
    }


def check_paragraph_rhythm(paragraphs: list) -> dict:
    """Проверка на монотонность ритма — не идут ли подряд одинаковые абзацы."""
    if len(paragraphs) < 5:
        return {"skipped": "Too few paragraphs"}

    lens = [len(p) for p in paragraphs]
    # Ищем группы подряд идущих абзацев с похожей длиной (±20%)
    max_run = 1
    current_run = 1
    for i in range(1, len(lens)):
        prev = lens[i-1]
        curr = lens[i]
        if prev > 0 and abs(curr - prev) / prev < 0.20:
            current_run += 1
            max_run = max(max_run, current_run)
        else:
            current_run = 1

    verdict = "good"
    if max_run >= 5:
        verdict = "AI-like (long run of similar paragraphs)"
    elif max_run >= 4:
        verdict = "slightly monotonous"

    return {
        "max_consecutive_similar_paragraphs": max_run,
        "verdict": verdict,
    }


def check_sentence_starter_variety(paragraphs: list) -> dict:
    """
    LLM часто начинает предложения одинаковыми словами.
    Проверка: разнообразие первых 1-2 слов предложений.
    """
    if not paragraphs:
        return {"error": "No paragraphs"}

    all_sentences = []
    for p in paragraphs:
        all_sentences.extend(split_sentences(p))

    if len(all_sentences) < 10:
        return {"skipped": "Too few sentences"}

    starters = []
    for s in all_sentences:
        words = s.split()[:2]
        starter = " ".join(words).lower()
        # Убираем пунктуацию
        starter = re.sub(r'[^\w\s]', '', starter)
        if starter:
            starters.append(starter)

    unique_starters = set(starters)
    variety_ratio = len(unique_starters) / len(starters) if starters else 0

    # Top-3 повторяющихся
    starter_counts = {}
    for s in starters:
        starter_counts[s] = starter_counts.get(s, 0) + 1
    top_repeated = sorted(
        [(s, c) for s, c in starter_counts.items() if c >= 3],
        key=lambda x: -x[1]
    )[:5]

    verdict = "diverse"
    if variety_ratio < 0.50:
        verdict = "AI-like (monotonous starters)"
    elif variety_ratio < 0.65:
        verdict = "slightly monotonous"

    return {
        "total_sentences": len(starters),
        "unique_starters": len(unique_starters),
        "variety_ratio": round(variety_ratio, 3),
        "top_repeated": top_repeated,
        "verdict": verdict,
    }


def check_passive_voice_ratio(text: str) -> dict:
    """
    Пассивный залог: LLM его переиспользует. Человек чередует.
    Эвристика: ищем причастия на -н/-т + окончания + 'был/была/было/были'
    или отдельные конструкции типа 'проведён/проведено/получены'.
    """
    # Простые маркеры пассива (русский)
    # Расширенный список глаголов, характерных для безличного научного стиля
    # (методичка МПГУ прямо требует таких конструкций: «был проведён», «разработана методика»)
    passive_markers = re.findall(
        r"\b(?:был[аиоы]?|будет|будут|бывают)\s+\w+[нт][ао]?\b|"
        r"\b\w+[нт][ао]?\s+был[аиоы]?\b|"
        r"\b(?:проведён[аоы]?|проведены|проведена|получен[аоы]?|получены|получена|"
        r"выявлен[аоы]?|выявлены|выявлена|установлен[аоы]?|установлены|установлена|"
        r"реализован[аоы]?|реализованы|реализована|рассмотрен[аоы]?|рассмотрены|рассмотрена|"
        r"выполнен[аоы]?|выполнены|выполнена|построен[аоы]?|построены|построена|"
        r"определён[аоы]?|определены|определена|изучен[аоы]?|изучены|изучена|"
        r"разработан[аоы]?|разработаны|разработана|"
        r"предложен[аоы]?|предложены|предложена|"
        r"применён[аоы]?|применены|применена|"
        r"внедрён[аоы]?|внедрены|внедрена|"
        r"описан[аоы]?|описаны|описана|"
        r"представлен[аоы]?|представлены|представлена|"
        r"приведён[аоы]?|приведены|приведена|"
        r"рассчитан[аоы]?|рассчитаны|рассчитана|"
        r"сформулирован[аоы]?|сформулированы|сформулирована|"
        r"обоснован[аоы]?|обоснованы|обоснована|"
        r"апробирован[аоы]?|апробированы|апробирована|"
        r"достигнут[аоы]?|достигнуты|достигнута|"
        r"отражён[аоы]?|отражены|отражена|"
        r"использован[аоы]?|использованы|использована|"
        r"создан[аоы]?|созданы|создана|"
        r"сделан[аоы]?|сделаны|сделана|"
        r"проанализирован[аоы]?|проанализированы|проанализирована)\b",
        text.lower(),
    )

    total_sentences = len(split_sentences(text))
    if total_sentences == 0:
        return {"skipped": "No sentences"}

    ratio = len(passive_markers) / total_sentences

    verdict = "balanced"
    if ratio > 0.70:
        verdict = "AI-like (excessive passive voice)"
    elif ratio > 0.50:
        verdict = "slightly heavy passive"
    elif ratio < 0.15:
        # В научном тексте так низко не бывает
        verdict = "unusually low passive (unusual for academic text)"

    return {
        "passive_markers_count": len(passive_markers),
        "sentences_count": total_sentences,
        "ratio": round(ratio, 3),
        "verdict": verdict,
    }


def check_readability_proxy(paragraphs: list) -> dict:
    """
    Простая proxy-метрика читаемости.
    LLM часто пишет либо слишком ровно (все предложения 15-20 слов),
    либо неестественно сложно (все 25+).
    
    Считаем: средняя длина слова и распределение длин предложений.
    """
    all_sentences = []
    for p in paragraphs:
        all_sentences.extend(split_sentences(p))
    if len(all_sentences) < 10:
        return {"skipped": "Too few sentences"}

    # Распределение длин предложений
    sent_lens_words = [len(s.split()) for s in all_sentences]

    # Доля «коротких» (<8 слов) и «длинных» (>25 слов)
    short_ratio = sum(1 for l in sent_lens_words if l < 8) / len(sent_lens_words)
    long_ratio = sum(1 for l in sent_lens_words if l > 25) / len(sent_lens_words)
    medium_ratio = 1 - short_ratio - long_ratio

    # Средняя длина слова
    all_words = []
    for s in all_sentences:
        all_words.extend([w for w in re.findall(r'\b[а-яёa-z]+\b', s.lower()) if len(w) > 1])
    avg_word_len = sum(len(w) for w in all_words) / len(all_words) if all_words else 0

    verdict = "natural"
    if short_ratio < 0.05 and long_ratio < 0.10:
        # Всё в диапазоне 8-25 слов = слишком ровно
        verdict = "AI-like (all sentences same length range)"
    elif medium_ratio > 0.90:
        verdict = "slightly uniform"

    return {
        "short_sentences_pct": round(short_ratio * 100, 1),
        "medium_sentences_pct": round(medium_ratio * 100, 1),
        "long_sentences_pct": round(long_ratio * 100, 1),
        "avg_word_length_chars": round(avg_word_len, 2),
        "verdict": verdict,
    }


# ========== AGGREGATE RISK SCORE ==========

# Посекционные множители весов: теоретическая глава звучит академичнее по природе,
# проектная должна быть живее и с конкретикой.
# Ключ — тип секции. Значения — множители для категорий риска.
# Если множитель < 1.0 — секция более терпима к этому виду риска.
# Если множитель > 1.0 — секция жёстче штрафуется за этот вид риска.
SECTION_WEIGHT_MULTIPLIERS = {
    # Полный документ — стандартные веса
    "full": {
        "burstiness": 1.0, "ngrams": 1.0, "lexical": 1.0, "rhythm": 1.0,
        "starters": 1.0, "passive": 1.0, "readability": 1.0, "anchors": 1.0,
    },
    # Введение — строгие пороги, это визитка работы. Клише и пассив особенно штрафуются.
    "introduction": {
        "burstiness": 1.0, "ngrams": 1.3, "lexical": 1.0, "rhythm": 1.0,
        "starters": 1.0, "passive": 1.3, "readability": 1.0, "anchors": 0.7,
    },
    # Заключение — без ссылок и цитат, по методичке формальное и сухое.
    # Якорьки тут наоборот штрафуются (если «представляется обоснованным» в заключении — звучит фальшиво).
    "conclusion": {
        "burstiness": 0.8, "ngrams": 1.2, "lexical": 0.8, "rhythm": 0.8,
        "starters": 0.8, "passive": 1.2, "readability": 0.8, "anchors": 1.5,
    },
    # Теоретическая глава — по природе академичная, шаблонность более допустима.
    # Burstiness, ритм и разнообразие стартов тут смягчены — в теории это норма.
    "chapter1": {
        "burstiness": 0.7, "ngrams": 1.0, "lexical": 0.8, "rhythm": 0.7,
        "starters": 0.7, "passive": 1.0, "readability": 0.8, "anchors": 0.8,
    },
    # Аналитическая глава — с собственными данными, должна быть живее теоретической.
    "chapter2": {
        "burstiness": 1.0, "ngrams": 1.0, "lexical": 1.0, "rhythm": 1.0,
        "starters": 1.0, "passive": 1.0, "readability": 1.0, "anchors": 1.0,
    },
    # Проектная глава — главный полигон конкретики (версии, цифры, решения).
    # Здесь шаблонность бьёт сильнее: если описание продукта звучит как ИИ — это «красный флаг».
    "chapter3": {
        "burstiness": 1.2, "ngrams": 1.3, "lexical": 1.2, "rhythm": 1.2,
        "starters": 1.2, "passive": 1.0, "readability": 1.0, "anchors": 1.0,
    },
}

# Посекционные пороги уровней риска. Теоретическая глава может иметь больший score
# при том же уровне риска — потому что теория по природе более шаблонна.
SECTION_LEVEL_THRESHOLDS = {
    # "full" / "introduction" / "chapter2" / "chapter3" — стандартные
    "full":         {"LOW": 20, "MODERATE": 40, "HIGH": 60},
    "introduction": {"LOW": 18, "MODERATE": 36, "HIGH": 55},  # строже: визитка работы
    "conclusion":   {"LOW": 18, "MODERATE": 36, "HIGH": 55},  # строже
    "chapter1":     {"LOW": 25, "MODERATE": 48, "HIGH": 68},  # мягче: теория академична
    "chapter2":     {"LOW": 20, "MODERATE": 40, "HIGH": 60},
    "chapter3":     {"LOW": 22, "MODERATE": 42, "HIGH": 62},
}


def aggregate_risk(results: dict, section_type: str = "full") -> dict:
    """Сводная оценка риска в баллах от 0 до 100.

    `section_type`: 'full' | 'introduction' | 'conclusion' | 'chapter1' | 'chapter2' | 'chapter3'.
    Разные секции имеют разные веса штрафов и разные пороги уровней риска,
    потому что теоретическая глава по природе шаблоннее проектной, и одни
    и те же пороги на весь документ дают искажённую картину.
    """
    weights = SECTION_WEIGHT_MULTIPLIERS.get(section_type, SECTION_WEIGHT_MULTIPLIERS["full"])
    thresholds = SECTION_LEVEL_THRESHOLDS.get(section_type, SECTION_LEVEL_THRESHOLDS["full"])

    score = 0.0
    flags = []

    # Burstiness
    b = results.get("burstiness", {})
    if "too uniform" in b.get("verdict", ""):
        score += 30 * weights["burstiness"]
        flags.append("LOW burstiness (too uniform)")
    elif "suspicious" in b.get("verdict", ""):
        score += 15 * weights["burstiness"]
        flags.append("Moderate burstiness risk")

    # N-grams
    n = results.get("ngrams", {})
    if "too many strong" in n.get("verdict", ""):
        score += 30 * weights["ngrams"]
        flags.append("Too many AI strong cliches")
    elif "suspicious" in n.get("verdict", ""):
        score += 15 * weights["ngrams"]
        flags.append("Elevated AI cliches")

    # Lexical diversity
    l = results.get("lexical", {})
    if "AI-like" in l.get("verdict", ""):
        score += 20 * weights["lexical"]
        flags.append("Poor lexical diversity")
    elif "poor" in l.get("verdict", "") and "AI" not in l.get("verdict", ""):
        score += 10 * weights["lexical"]
        flags.append("Somewhat limited vocabulary")
    if "overused" in l.get("verdict", ""):
        score += 5 * weights["lexical"]
        flags.append("Overused AI buzzwords")

    # Paragraph rhythm
    r = results.get("rhythm", {})
    if "AI-like" in r.get("verdict", ""):
        score += 15 * weights["rhythm"]
        flags.append("Monotonous paragraph rhythm")

    # Sentence starter variety
    starters = results.get("starters", {})
    if "AI-like" in starters.get("verdict", ""):
        score += 15 * weights["starters"]
        flags.append("Monotonous sentence starters")
    elif "slightly monotonous" in starters.get("verdict", ""):
        score += 7 * weights["starters"]
        flags.append("Somewhat repetitive sentence starts")

    # Passive voice
    passive = results.get("passive", {})
    if "excessive passive" in passive.get("verdict", ""):
        score += 10 * weights["passive"]
        flags.append("Excessive passive voice (AI tendency)")

    # Readability
    readability = results.get("readability", {})
    if "same length range" in readability.get("verdict", ""):
        score += 10 * weights["readability"]
        flags.append("All sentences same length range (AI tendency)")

    # Author anchors (in BOTH directions)
    a = results.get("anchors", {})
    if "too many" in a.get("verdict", ""):
        score += 10 * weights["anchors"]
        flags.append("Too many author anchors (sounds like PhD)")
    elif "no author voice" in a.get("verdict", ""):
        score += 10 * weights["anchors"]
        flags.append("No author voice (sounds AI-generic)")

    # Pronouns — одинаково по всем секциям (хард-правило методички)
    p = results.get("pronouns", {})
    if p.get("total", 0) > 0:
        score += 5
        flags.append("Personal pronouns found")

    # Score capping и округление
    score = min(round(score, 1), 100)

    # Посекционные пороги уровня риска
    if score < thresholds["LOW"]:
        risk_level = "LOW"
    elif score < thresholds["MODERATE"]:
        risk_level = "MODERATE"
    elif score < thresholds["HIGH"]:
        risk_level = "HIGH"
    else:
        risk_level = "CRITICAL"

    return {
        "risk_score": score,
        "risk_level": risk_level,
        "section_type": section_type,
        "flags": flags,
    }


# ========== MAIN ==========

def analyze_text(text: str, paragraphs: list, section_type: str = "full") -> dict:
    results = {
        "burstiness": compute_burstiness(paragraphs),
        "ngrams": compute_ngram_density(text),
        "lexical": compute_lexical_diversity(text),
        "anchors": compute_author_anchors(text),
        "pronouns": check_pronouns(text),
        "rhythm": check_paragraph_rhythm(paragraphs),
        "starters": check_sentence_starter_variety(paragraphs),
        "passive": check_passive_voice_ratio(text),
        "readability": check_readability_proxy(paragraphs),
    }
    results["risk"] = aggregate_risk(results, section_type=section_type)
    return results


def extract_section(doc: Document, section_name: str) -> tuple:
    """Извлечь текст конкретного раздела (например, 'introduction', 'conclusion')."""
    section_keywords = {
        "introduction": ["введение"],
        "conclusion": ["заключение"],
        "chapter1": ["глава 1", "глава i"],
        "chapter2": ["глава 2", "глава ii"],
        "chapter3": ["глава 3", "глава iii"],
    }
    keywords = section_keywords.get(section_name, [section_name.lower()])
    stop_keywords = ["введение", "глава", "заключение", "список", "приложение"]

    collecting = False
    collected = []
    for p in doc.paragraphs:
        text_lower = p.text.strip().lower()
        if not text_lower:
            continue
        if not collecting:
            if any(text_lower.startswith(kw) for kw in keywords):
                collecting = True
                continue
        else:
            # Проверка: не начался ли новый раздел
            if any(text_lower.startswith(sw) and text_lower not in keywords
                   for sw in stop_keywords) and len(text_lower) < 60:
                break
            collected.append(p.text)

    full_text = "\n\n".join(collected)
    paragraphs = [p for p in collected if len(p.strip()) > 30]
    return full_text, paragraphs


def print_report(results: dict):
    """Текстовый отчёт."""
    print("\n" + "=" * 70)
    print("  ЭВРИСТИЧЕСКИЙ ДЕТЕКТОР ИИ-ТЕКСТА")
    print("=" * 70)

    risk = results["risk"]
    level = risk["risk_level"]
    emoji = {"LOW": "◎", "MODERATE": "⚠️", "HIGH": "🔴", "CRITICAL": "🚨"}.get(level, "❓")

    print(f"\n{emoji} Риск: {level} ({risk['risk_score']}/100)")
    if risk["flags"]:
        print("\nТревожные сигналы:")
        for f in risk["flags"]:
            print(f"  • {f}")

    print(f"\n📊 Burstiness (рваность текста):")
    b = results["burstiness"]
    print(f"   Абзацев: {b.get('paragraph_count', '?')}")
    print(f"   Средняя длина абзаца: {b.get('paragraph_mean_chars', '?')} символов")
    print(f"   CV абзацев: {b.get('paragraph_cv', '?')} (цель: >0.35)")
    print(f"   CV предложений: {b.get('sentence_cv', '?')} (цель: >0.40)")
    print(f"   Вердикт: {b.get('verdict', '?')}")

    print(f"\n🔍 Плотность ИИ-клише:")
    n = results["ngrams"]
    print(f"   Сильных клише: {n.get('strong_cliches_count', '?')} ({n.get('strong_per_1k_words', '?')}/1000 слов)")
    print(f"   Средних клише: {n.get('medium_cliches_count', '?')} ({n.get('medium_per_1k_words', '?')}/1000 слов)")
    if n.get("top_strong"):
        print("   Топ сильных:")
        for ng, c in n["top_strong"]:
            print(f"     • «{ng}»: {c} раз")
    print(f"   Вердикт: {n.get('verdict', '?')}")

    print(f"\n📚 Лексическое разнообразие:")
    l = results["lexical"]
    print(f"   Type-Token Ratio: {l.get('type_token_ratio', '?')} (цель: >0.25)")
    print(f"   MTLD-approx: {l.get('mtld_approx', '?')} (цель: >60)")
    print(f"   «Буззворды» на 1k слов: {l.get('overused_words_per_1k', '?')} (норма <10)")
    print(f"   Вердикт: {l.get('verdict', '?')}")

    print(f"\n✍️  Авторские якорьки:")
    a = results["anchors"]
    print(f"   Всего использований: {a.get('total_anchors', '?')}")
    print(f"   Разных якорьков: {a.get('unique_anchors_used', '?')} (оптимум 2-3)")
    print(f"   Плотность на 1k слов: {a.get('anchors_per_1k_words', '?')} (норма 0.3-1.0)")
    print(f"   Вердикт: {a.get('verdict', '?')}")

    print(f"\n🎵 Ритм абзацев:")
    r = results["rhythm"]
    print(f"   Макс. серия похожих абзацев: {r.get('max_consecutive_similar_paragraphs', '?')}")
    print(f"   Вердикт: {r.get('verdict', '?')}")

    print(f"\n🎯 Разнообразие начал предложений:")
    s = results.get("starters", {})
    if "error" in s or "skipped" in s:
        print(f"   {s.get('error') or s.get('skipped')}")
    else:
        print(f"   Уникальных стартов: {s.get('unique_starters', '?')} из {s.get('total_sentences', '?')}")
        print(f"   Коэффициент разнообразия: {s.get('variety_ratio', '?')} (цель: >0.65)")
        if s.get("top_repeated"):
            print("   Топ повторяющихся:")
            for starter, cnt in s["top_repeated"][:3]:
                print(f"     • «{starter}»: {cnt} раз")
        print(f"   Вердикт: {s.get('verdict', '?')}")

    print(f"\n⚡ Пассивный залог:")
    passive = results.get("passive", {})
    if "skipped" in passive:
        print(f"   {passive.get('skipped')}")
    else:
        print(f"   Маркеры пассива: {passive.get('passive_markers_count', '?')} "
              f"({passive.get('ratio', '?')} на предложение)")
        print(f"   Вердикт: {passive.get('verdict', '?')}")

    print(f"\n📖 Распределение длин предложений:")
    rd = results.get("readability", {})
    if "skipped" in rd:
        print(f"   {rd.get('skipped')}")
    else:
        print(f"   Коротких (<8 слов): {rd.get('short_sentences_pct', '?')}%")
        print(f"   Средних (8-25 слов): {rd.get('medium_sentences_pct', '?')}%")
        print(f"   Длинных (>25 слов): {rd.get('long_sentences_pct', '?')}%")
        print(f"   Вердикт: {rd.get('verdict', '?')}")

    print(f"\n🚫 Личные местоимения:")
    p = results["pronouns"]
    print(f"   {p.get('verdict', '?')}")

    print("\n" + "=" * 70)

    # Рекомендации
    print("\n💡 РЕКОМЕНДАЦИИ:")
    if level == "LOW":
        print("   Поверхностные ИИ-маркеры не обнаружены. Это НЕОБХОДИМОЕ,")
        print("   но НЕ ДОСТАТОЧНОЕ условие — реальный детектор Антиплагиат.Вуз")
        print("   использует нейросетевой классификатор, который этот скрипт")
        print("   не симулирует. Низкий результат здесь ≠ гарантия прохождения.")
    elif level == "MODERATE":
        print("   Текст близок к норме, но есть что улучшить. Пройдись по флагам выше.")
    elif level == "HIGH":
        print("   ВНИМАНИЕ: текст может быть помечен как ИИ. Переработай:")
        print("   - Разбей монотонные блоки")
        print("   - Убери лишние клише")
        print("   - Добавь конкретные имена/цифры/технические детали")
    else:  # CRITICAL
        print("   🚨 ОПАСНО: текст сильно похож на ИИ-генерацию.")
        print("   Требуется серьёзная переработка перед сдачей.")
    print()


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Эвристический детектор ИИ-текста для ВКР")
    parser.add_argument("docx_path", help="Путь к .docx файлу")
    parser.add_argument("--section",
                        help="Анализировать только раздел: introduction | conclusion | chapter1-3")
    parser.add_argument("--per-section", action="store_true",
                        help="Проанализировать каждую секцию отдельно с её порогами и вывести сводку")
    parser.add_argument("--json", action="store_true", help="Вывод в JSON")
    args = parser.parse_args()

    path = Path(args.docx_path)
    if not path.exists():
        print(f"❌ Файл не найден: {path}")
        sys.exit(1)

    doc = Document(path)

    if args.per_section:
        # Посекционный режим: разбиваем на 5 стандартных секций
        section_names = ["introduction", "chapter1", "chapter2", "chapter3", "conclusion"]
        per_section_results = {}
        for sname in section_names:
            text, paragraphs = extract_section(doc, sname)
            if paragraphs:
                per_section_results[sname] = analyze_text(text, paragraphs, section_type=sname)

        if args.json:
            print(json.dumps(per_section_results, ensure_ascii=False, indent=2))
        else:
            print(f"\n{'='*70}")
            print("  ПОСЕКЦИОННЫЙ АНАЛИЗ (разные пороги по типу главы)")
            print(f"{'='*70}\n")
            for sname, res in per_section_results.items():
                risk = res["risk"]
                print(f"📄 {sname.upper()}:")
                print(f"   Score: {risk['risk_score']}/100 — Уровень: {risk['risk_level']}")
                if risk["flags"]:
                    print(f"   Флаги: {', '.join(risk['flags'][:5])}")
                print()
            print("ℹ️  Пороги различаются: теоретическая глава (chapter1) толерантнее к шаблонности,")
            print("    проектная (chapter3) и введение/заключение — строже. Это нормально:")
            print("    теория по природе академичная, а проектное описание должно быть живым.")
        return

    if args.section:
        text, paragraphs = extract_section(doc, args.section)
        if not paragraphs:
            print(f"❌ Раздел '{args.section}' не найден или пуст")
            sys.exit(1)
        section_type = args.section
    else:
        paragraphs = split_paragraphs_from_doc(doc)
        text = "\n\n".join(paragraphs)
        section_type = "full"

    results = analyze_text(text, paragraphs, section_type=section_type)

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        if args.section:
            print(f"\n[Анализ раздела: {args.section}, применены пороги для этого типа]")
        print_report(results)


if __name__ == "__main__":
    main()
