#!/usr/bin/env python3
"""Долговременная память проекта ВКР: status и атомарный checkpoint."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import sys
import tempfile
import uuid
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def read_json(path: Path, default: Any) -> Any:
    if not path.is_file():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", newline="\n", dir=path.parent, delete=False
    ) as stream:
        stream.write(text)
        temporary = Path(stream.name)
    os.replace(temporary, path)


def atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", newline="\n", dir=path.parent, delete=False
    ) as stream:
        stream.write(text)
        temporary = Path(stream.name)
    os.replace(temporary, path)


def append_jsonl(path: Path, item: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def project_root(path: Path) -> Path:
    root = path.expanduser().resolve(strict=True)
    if not root.is_dir():
        raise ValueError(f"Project root is not a directory: {root}")
    if not (root / "vkr-state.md").is_file():
        raise ValueError(f"vkr-state.md not found in project root: {root}")
    return root


def resolve_project_file(root: Path, value: str) -> tuple[str, Path]:
    candidate = (root / value).resolve(strict=False)
    try:
        relative = candidate.relative_to(root)
    except ValueError as error:
        raise ValueError(f"Tracked file is outside project root: {value}") from error
    logical_id = relative.as_posix()
    return logical_id, candidate


def artifact_records(root: Path, files: list[Any], timestamp: str) -> dict[str, dict[str, Any]]:
    if not isinstance(files, list):
        raise ValueError("event.files must be an array")
    result: dict[str, dict[str, Any]] = {}
    for value in files:
        if not isinstance(value, str) or not value.strip():
            raise ValueError("event.files must contain non-empty relative paths")
        logical_id, path = resolve_project_file(root, value)
        if not path.is_file():
            raise ValueError(f"Tracked file does not exist: {logical_id}")
        result[logical_id] = {
            "sha256": sha256(path),
            "size": path.stat().st_size,
            "recorded_at": timestamp,
        }
    return result


def read_jsonl_tail(path: Path, limit: int) -> list[dict[str, Any]]:
    if not path.is_file() or limit <= 0:
        return []
    lines = path.read_text(encoding="utf-8").splitlines()[-limit:]
    events: list[dict[str, Any]] = []
    for line in lines:
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            events.append({"event_type": "CORRUPT_LOG_LINE", "raw_sha256": hashlib.sha256(line.encode()).hexdigest()})
        else:
            if isinstance(value, dict):
                events.append(value)
    return events


def changed_artifacts(root: Path, index: dict[str, Any]) -> dict[str, list[dict[str, str]]]:
    changed: list[dict[str, str]] = []
    missing: list[dict[str, str]] = []
    for logical_id, previous in index.get("artifacts", {}).items():
        _, path = resolve_project_file(root, logical_id)
        if not path.is_file():
            missing.append({"logical_id": logical_id, "previous_sha256": previous.get("sha256", "")})
            continue
        current = sha256(path)
        if current != previous.get("sha256"):
            changed.append(
                {
                    "logical_id": logical_id,
                    "previous_sha256": previous.get("sha256", ""),
                    "current_sha256": current,
                }
            )
    return {"changed": changed, "missing": missing}


def render_handoff(handoff: dict[str, Any]) -> str:
    def bullets(values: Any, empty: str = "нет") -> str:
        if not isinstance(values, list) or not values:
            return f"- {empty}"
        return "\n".join(f"- {value}" for value in values)

    artifacts = handoff.get("artifacts", {})
    artifact_lines = [f"- `{key}` — `{value.get('sha256', '')}`" for key, value in sorted(artifacts.items())]
    return f"""# Передача контекста следующему чату

- **Обновлено:** {handoff.get('updated_at', 'не указано')}
- **Текущая фаза:** {handoff.get('current_phase', 'не указано')}
- **Текущее задание:** {handoff.get('current_task', 'не указано')}
- **Последнее завершённое:** {handoff.get('last_completed', 'не указано')}
- **Последнее событие:** {handoff.get('last_event_id', 'не указано')}

## Следующие действия

{bullets(handoff.get('next_actions'))}

## Открытые вопросы

{bullets(handoff.get('open_questions'))}

## Блокеры

{bullets(handoff.get('open_blockers'))}

## Зафиксированные артефакты

{chr(10).join(artifact_lines) if artifact_lines else '- нет'}

Перед продолжением запусти `scripts/vkr_memory.py <project> status --json` и
сверь эти хеши с файлами и `audit/manifest.json`.
"""


def status(root: Path, tail: int) -> dict[str, Any]:
    memory = root / "memory"
    logs = root / "logs"
    handoff = read_json(memory / "handoff.json", {})
    index = read_json(
        memory / "artifact-index.json",
        {"schema_version": SCHEMA_VERSION, "updated_at": None, "artifacts": {}},
    )
    if not isinstance(handoff, dict):
        raise ValueError("memory/handoff.json must be a JSON object")
    if not isinstance(index, dict) or not isinstance(index.get("artifacts", {}), dict):
        raise ValueError("memory/artifact-index.json must contain an artifacts object")
    changes = changed_artifacts(root, index)
    audit = read_json(root / "audit" / "manifest.json", {})
    if not isinstance(audit, dict) or not isinstance(audit.get("runs", []), list):
        raise ValueError("audit/manifest.json must contain a runs array")
    return {
        "status": "ok" if not changes["changed"] and not changes["missing"] else "external_changes_detected",
        "project_root": str(root),
        "handoff": handoff,
        "artifact_changes": changes,
        "audit_summary": {
            "snapshot_manifest_sha256": audit.get("snapshot_manifest_sha256"),
            "runs": [
                {
                    "run_id": item.get("run_id"),
                    "checkpoint_id": item.get("checkpoint_id"),
                    "status": item.get("status"),
                }
                for item in audit.get("runs", [])[-5:]
                if isinstance(item, dict)
            ],
        },
        "recent_events": read_jsonl_tail(logs / "activity.jsonl", tail),
    }


def record(root: Path, event_path: Path) -> dict[str, Any]:
    event = json.loads(event_path.read_text(encoding="utf-8"))
    if not isinstance(event, dict):
        raise ValueError("Event must be a JSON object")
    if not isinstance(event.get("event_type"), str) or not event["event_type"].strip():
        raise ValueError("event_type is required")
    if not isinstance(event.get("summary"), str) or not event["summary"].strip():
        raise ValueError("summary is required")

    decisions = event.get("decisions", [])
    if not isinstance(decisions, list):
        raise ValueError("decisions must be an array")
    for decision in decisions:
        if not isinstance(decision, dict) or not decision.get("decision"):
            raise ValueError("Each decision must be an object with decision")

    timestamp = utc_now()
    event_id = f"evt-{uuid.uuid4()}"
    records = artifact_records(root, event.get("files", []), timestamp)
    index_path = root / "memory" / "artifact-index.json"
    index = read_json(
        index_path,
        {"schema_version": SCHEMA_VERSION, "updated_at": None, "artifacts": {}},
    )
    if not isinstance(index, dict) or not isinstance(index.get("artifacts", {}), dict):
        raise ValueError("memory/artifact-index.json must contain an artifacts object")
    handoff_path = root / "memory" / "handoff.json"
    handoff = read_json(handoff_path, {"schema_version": SCHEMA_VERSION})
    if not isinstance(handoff, dict):
        raise ValueError("memory/handoff.json must be a JSON object")

    logged = {
        **event,
        "event_id": event_id,
        "timestamp": timestamp,
        "actor": "primary_agent",
        "artifacts": records,
    }
    append_jsonl(root / "logs" / "activity.jsonl", logged)
    if event["event_type"] == "tool_run":
        append_jsonl(root / "logs" / "tool-runs.jsonl", logged)

    for decision in decisions:
        append_jsonl(
            root / "memory" / "decisions.jsonl",
            {
                **decision,
                "decision_id": f"dec-{uuid.uuid4()}",
                "event_id": event_id,
                "timestamp": timestamp,
                "actor": "primary_agent",
            },
        )

    index.setdefault("artifacts", {}).update(records)
    index["schema_version"] = SCHEMA_VERSION
    index["updated_at"] = timestamp
    atomic_json(index_path, index)

    for key in (
        "current_phase",
        "current_task",
        "last_completed",
        "next_actions",
        "open_questions",
        "open_blockers",
    ):
        if key in event:
            handoff[key] = event[key]
    handoff.update(
        {
            "schema_version": SCHEMA_VERSION,
            "updated_at": timestamp,
            "last_event_id": event_id,
            "last_event_type": event["event_type"],
            "last_summary": event["summary"],
            "artifacts": index["artifacts"],
        }
    )
    atomic_json(handoff_path, handoff)
    atomic_text(root / "memory" / "handoff.md", render_handoff(handoff))

    return {
        "status": "recorded",
        "event_id": event_id,
        "timestamp": timestamp,
        "tracked_artifacts": records,
        "handoff": handoff,
    }


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("project_dir", type=Path)
    sub = result.add_subparsers(dest="command", required=True)

    status_parser = sub.add_parser("status", help="Восстановить состояние и проверить хеши")
    status_parser.add_argument("--tail", type=int, default=10)
    status_parser.add_argument("--json", action="store_true", dest="json_output")

    record_parser = sub.add_parser("record", help="Записать checkpoint основного агента")
    record_parser.add_argument("--event", type=Path, required=True)
    record_parser.add_argument("--json", action="store_true", dest="json_output")
    return result


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = parser().parse_args()
    try:
        root = project_root(args.project_dir)
        if args.command == "status":
            result = status(root, max(0, args.tail))
        else:
            result = record(root, args.event)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        result = {"status": "error", "error": str(error)}
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2

    if args.json_output:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Status: {result['status']}")
        if result.get("event_id"):
            print(f"Event: {result['event_id']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
