#!/usr/bin/env python3
"""
Валидатор ВКР для МПГУ.

Проверяет готовый .docx на:
- Соответствие требованиям методички МПГУ (шрифт, поля, интервал, отступ)
- Структурные элементы (титул, аннотация, содержание, введение, главы, заключение, список литературы)
- Наличие личных местоимений в тексте
- Признаки ИИ-текста (ИИ-клише, одинаковые длины абзацев)
- Типичные ошибки оформления

Использование:
    python validate_vkr.py path/to/vkr.docx
    python validate_vkr.py path/to/vkr.docx --profile mpgu-09-project
    python validate_vkr.py path/to/vkr.docx --profile mpgu-09-regular --json
"""

import sys
import argparse
import json
import re
import statistics
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Mm, Pt
except ImportError:
    print("ERROR: python-docx не установлен. Выполни: pip install python-docx")
    sys.exit(1)


# ========== КОНСТАНТЫ: ТРЕБОВАНИЯ МЕТОДИЧКИ МПГУ ==========

REQUIREMENTS = {
    "font_name": "Times New Roman",
    "font_size_pt": 14,
    "line_spacing": 1.5,
    "page_width_mm": 210,
    "page_height_mm": 297,
    "top_margin_mm": 20,
    "bottom_margin_mm": 20,
    "left_margin_mm": 35,
    "right_margin_mm": 10,
    "first_line_indent_cm": 1.25,
    "min_pages": 40,
    "max_pages_regular": 60,
    "max_pages_project": 50,
}

VALIDATION_PROFILES = (
    "generic",
    "mpgu-09-regular",
    "mpgu-09-project",
)

# ========== СПИСКИ ДЛЯ ПРОВЕРКИ ТЕКСТА ==========

PERSONAL_PRONOUNS = [
    # 1-е лицо единственное
    r"\bя\b", r"\bмне\b", r"\bменя\b", r"\bмной\b", r"\bмною\b",
    # 1-е лицо множественное
    r"\bмы\b", r"\bнас\b", r"\bнам\b", r"\bнами\b",
    # Притяжательные 1-го лица ед.ч. — все падежи и роды
    r"\bмой\b", r"\bмоя\b", r"\bмоё\b", r"\bмои\b",
    r"\bмоего\b", r"\bмоему\b", r"\bмоим\b", r"\bмоём\b",
    r"\bмоей\b", r"\bмоею\b", r"\bмоих\b", r"\bмоими\b",
    # Притяжательные 1-го лица мн.ч. — все падежи и роды
    r"\bнаш\b", r"\bнаша\b", r"\bнаше\b", r"\bнаши\b",
    r"\bнашего\b", r"\bнашему\b", r"\bнашим\b", r"\bнашем\b",
    r"\bнашей\b", r"\bнашею\b", r"\bнаших\b", r"\bнашими\b",
]

# Важно: даже «наш» в «наш взгляд» — запрещён в МПГУ. Раньше помечали как soft,
# теперь везде как error (методичка однозначна). Оставляем список пустым
# для совместимости.
PRONOUNS_SOFT = []

AI_CLICHES_PATH = Path(__file__).resolve().parent.parent / "data" / "ai_cliches.json"


def _load_ai_cliches():
    """Загрузка централизованного словаря клише из data/ai_cliches.json.
    Единый источник истины с ai_detection_heuristic.py.
    Валидатор использует объединённый список strong + medium.
    При ошибке загрузки — минимальный встроенный fallback.
    """
    try:
        with open(AI_CLICHES_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("strong", []) + data.get("medium", [])
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(
            f"ВНИМАНИЕ: не удалось загрузить {AI_CLICHES_PATH}: {e}",
            file=sys.stderr,
        )
        print("Используется минимальный fallback-список клише.", file=sys.stderr)
        return [
            "стоит отметить",
            "важно отметить",
            "важно подчеркнуть",
            "следует отметить",
            "необходимо отметить",
            "в свою очередь",
            "таким образом",
            "на сегодняшний день",
            "в современном мире",
            "давайте рассмотрим",
        ]


AI_CLICHES = _load_ai_cliches()


def _load_cliche_allowlist():
    """v6.26-friends: загрузка персонального cliche_allowlist из state-файла.

    Ищет файл `vkr-state.md` в текущей директории или родительских до 3 уровней.
    Парсит YAML-блок (frontmatter или просто `cliche_allowlist:` где-то в тексте).
    Возвращает список фраз (lowercase), которые НЕ считаются ИИ-клише
    у конкретного пользователя.

    Зачем: при friend-sharing каждый студент имеет свои 5-7 «допустимых»
    клише (генерируется через user_seed). Это снижает общую негативную
    сигнатуру у группы пользователей одного скилла.

    Пустой список → проверка работает как раньше (без allowlist).
    """
    import re
    candidates = []
    try:
        from pathlib import Path as _P
        cwd = _P.cwd()
        for parent in [cwd] + list(cwd.parents)[:3]:
            for name in ("vkr-state.md", ".vkr-state.md", "VKR-STATE.md"):
                p = parent / name
                if p.exists():
                    candidates.append(p)
    except Exception:
        return []

    if not candidates:
        return []

    state_path = candidates[0]
    try:
        text = state_path.read_text(encoding="utf-8")
    except Exception:
        return []

    # Ищем `cliche_allowlist:` затем YAML-list под ним
    m = re.search(
        r"^\s*cliche_allowlist\s*:\s*\n((?:\s+-\s+.+\n)+)",
        text,
        re.MULTILINE,
    )
    if not m:
        # Альтернативный inline формат: cliche_allowlist: ["a", "b"]
        m2 = re.search(
            r"^\s*cliche_allowlist\s*:\s*\[(.*?)\]\s*$",
            text,
            re.MULTILINE,
        )
        if m2:
            items = [
                s.strip().strip('"').strip("'").lower()
                for s in m2.group(1).split(",")
                if s.strip()
            ]
            return items
        return []

    items = []
    for line in m.group(1).splitlines():
        line = line.strip()
        if line.startswith("-"):
            phrase = line[1:].strip().strip('"').strip("'")
            if phrase:
                items.append(phrase.lower())
    return items


CLICHE_ALLOWLIST = _load_cliche_allowlist()

STRUCTURAL_HEADERS = [
    "аннотация",
    "содержание",
    "оглавление",
    "введение",
    "заключение",
    "список использованной литературы",
    "список литературы",
    "библиография",
    "приложение",
]


def check(condition: bool, message: str, severity: str = "error"):
    """Создать запись результата проверки."""
    return {
        "ok": bool(condition),
        "message": message,
        "severity": severity,  # "error" | "warning" | "info"
    }


def mm_from_emu(emu: int) -> float:
    """EMU → мм. 914400 EMU = 1 дюйм = 25.4 мм."""
    return round(emu / 914400 * 25.4, 1)


def pt_from_emu(emu: int) -> float:
    """EMU → pt."""
    return round(emu / 914400 * 72, 1)


# ========== ПРОВЕРКИ ==========

def check_page_size(doc: Document) -> list:
    """Проверка формата A4 во всех секциях."""
    if not doc.sections:
        return [check(False, "В документе нет секций — невозможно проверить формат страницы")]

    results = []
    for index, section in enumerate(doc.sections, 1):
        width = mm_from_emu(section.page_width)
        height = mm_from_emu(section.page_height)
        is_a4 = (
            abs(width - REQUIREMENTS["page_width_mm"]) < 1
            and abs(height - REQUIREMENTS["page_height_mm"]) < 1
        )
        results.append(check(
            is_a4,
            f"Секция {index}: {width} × {height} мм "
            f"(требуется A4: {REQUIREMENTS['page_width_mm']} × "
            f"{REQUIREMENTS['page_height_mm']} мм)",
            severity="error",
        ))
    return results

def check_margins(doc: Document) -> list:
    """Проверка полей."""
    results = []
    if not doc.sections:
        return [check(False, "В документе нет секций — невозможно проверить поля")]

    section = doc.sections[0]

    top = mm_from_emu(section.top_margin)
    bottom = mm_from_emu(section.bottom_margin)
    left = mm_from_emu(section.left_margin)
    right = mm_from_emu(section.right_margin)

    results.append(check(
        abs(top - REQUIREMENTS["top_margin_mm"]) < 1,
        f"Верхнее поле: {top} мм (требуется {REQUIREMENTS['top_margin_mm']} мм)"
    ))
    results.append(check(
        abs(bottom - REQUIREMENTS["bottom_margin_mm"]) < 1,
        f"Нижнее поле: {bottom} мм (требуется {REQUIREMENTS['bottom_margin_mm']} мм)"
    ))
    results.append(check(
        abs(left - REQUIREMENTS["left_margin_mm"]) < 1,
        f"Левое поле: {left} мм (требуется {REQUIREMENTS['left_margin_mm']} мм — нестандартно!)"
    ))
    results.append(check(
        abs(right - REQUIREMENTS["right_margin_mm"]) < 1,
        f"Правое поле: {right} мм (требуется {REQUIREMENTS['right_margin_mm']} мм)"
    ))

    return results


def _get_normal_style_font(doc: Document) -> str:
    """Вернуть имя шрифта стиля Normal (подразумеваемый шрифт для runs без явного font.name)."""
    try:
        normal_style = doc.styles["Normal"]
        font_name = normal_style.font.name
        if font_name:
            return font_name
    except (KeyError, AttributeError):
        pass
    return ""


def check_fonts(doc: Document) -> list:
    """Проверка шрифта."""
    results = []
    font_counts = {}
    size_counts = {}

    for para in doc.paragraphs:
        for run in para.runs:
            name = run.font.name or "[default]"
            size = run.font.size.pt if run.font.size else None
            if name:
                font_counts[name] = font_counts.get(name, 0) + 1
            if size:
                size_counts[size] = size_counts.get(size, 0) + 1

    # Шрифт, подразумеваемый стилем Normal (для runs без явного font.name)
    normal_font = _get_normal_style_font(doc)

    # Основной шрифт (самый частый)
    if font_counts:
        main_font = max(font_counts, key=font_counts.get)

        if main_font == REQUIREMENTS["font_name"]:
            # Явно прописанный Times New Roman — всё хорошо
            results.append(check(
                True,
                f"Основной шрифт: {main_font}"
            ))
        elif main_font == "[default]":
            # Шрифт не прописан явно — значит берётся из стиля Normal.
            # Проверяем, что там именно Times New Roman.
            if normal_font == REQUIREMENTS["font_name"]:
                results.append(check(
                    True,
                    f"Основной шрифт: не указан явно в runs, но стиль Normal = {normal_font}",
                    severity="info"
                ))
            elif not normal_font:
                results.append(check(
                    False,
                    f"Шрифт не определён: run'ы без font.name, стиль Normal без font. "
                    f"Требуется {REQUIREMENTS['font_name']} — проверь вручную в Word",
                    severity="warning"
                ))
            else:
                results.append(check(
                    False,
                    f"Стиль Normal использует шрифт '{normal_font}' вместо требуемого "
                    f"{REQUIREMENTS['font_name']}"
                ))
        else:
            results.append(check(
                False,
                f"Основной шрифт: {main_font} (требуется {REQUIREMENTS['font_name']})"
            ))

        # Другие шрифты как предупреждение. Требуемый шрифт (например, Times New Roman)
        # никогда не считается «чужим», даже если main_font = "[default]" (runs без явного
        # font.name, но стиль Normal = TNR) — в этом случае явные TNR-runs — это нормальное
        # поведение, а не нарушение.
        other_fonts = [
            f for f in font_counts
            if f != main_font
            and f != "[default]"
            and f != REQUIREMENTS["font_name"]
        ]
        if other_fonts:
            results.append(check(
                False,
                f"В документе найдены другие шрифты: {', '.join(other_fonts)}",
                severity="warning"
            ))

    # Основной размер
    if size_counts:
        main_size = max(size_counts, key=size_counts.get)
        results.append(check(
            abs(main_size - REQUIREMENTS["font_size_pt"]) < 0.5,
            f"Основной размер шрифта: {main_size} pt (требуется {REQUIREMENTS['font_size_pt']} pt)"
        ))

    return results


def check_line_spacing(doc: Document) -> list:
    """Проверка междустрочного интервала (методичка МПГУ: 1,5).

    Смотрит параметры абзацев и стиля Normal. python-docx возвращает
    line_spacing как float (1.5 = 1.5) или как Pt-значение в особых случаях.
    line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE также засчитывается.
    """
    from docx.enum.text import WD_LINE_SPACING
    results = []

    # Стиль Normal — ожидаемая базовая настройка
    try:
        normal = doc.styles["Normal"]
        normal_ls = normal.paragraph_format.line_spacing
        normal_rule = normal.paragraph_format.line_spacing_rule
    except (KeyError, AttributeError):
        normal_ls = None
        normal_rule = None

    # Определяем диапазон тела работы: от «Аннотация»/«Введение» (после титульника)
    # до «Список использованной литературы» (исключая библиографию, приложения, клятву).
    # Титульник явно в single-интервале (это корректно по методичке для компактности),
    # и клятва — в служебном формате (таблица). Их исключаем.
    body_start_idx = 0
    body_end_idx = len(doc.paragraphs)
    for i, p in enumerate(doc.paragraphs):
        text_lower = p.text.strip().lower()
        if body_start_idx == 0 and text_lower in (
            "аннотация", "содержание", "оглавление", "введение"
        ):
            body_start_idx = i
        if body_start_idx > 0 and text_lower in (
            "список использованной литературы", "список литературы", "библиография"
        ):
            body_end_idx = i
            break
    if body_start_idx == 0 and len(doc.paragraphs) > 15:
        body_start_idx = 15  # fallback: первые 15 абзацев — титульник

    # Подсчёт по реальным абзацам с текстом (только в теле)
    spacing_counts = {}
    non_empty = 0
    for p in doc.paragraphs[body_start_idx:body_end_idx]:
        if not p.text.strip():
            continue
        # Служебные строки (прочерки, клятва) — исключаем
        text = p.text.strip()
        if "выполнена мной совершенно самостоятельно" in text.lower():
            continue
        if "___________" in text:
            continue
        non_empty += 1
        ls = p.paragraph_format.line_spacing
        rule = p.paragraph_format.line_spacing_rule
        # Если абзац не переопределил интервал — берём из стиля
        if ls is None and rule is None:
            ls_effective = normal_ls
            rule_effective = normal_rule
        else:
            ls_effective = ls
            rule_effective = rule

        if rule_effective == WD_LINE_SPACING.ONE_POINT_FIVE:
            key = "1.5 (rule)"
        elif isinstance(ls_effective, (int, float)) and ls_effective is not None:
            # 1.5 с допустимой погрешностью
            if abs(ls_effective - 1.5) < 0.05:
                key = "1.5"
            elif abs(ls_effective - 1.0) < 0.05:
                key = "1.0 (single)"
            elif abs(ls_effective - 2.0) < 0.05:
                key = "2.0 (double)"
            else:
                key = f"{ls_effective:.2f}"
        else:
            key = "не задан"
        spacing_counts[key] = spacing_counts.get(key, 0) + 1

    if non_empty == 0:
        return [check(True, "Пустой документ — интервал не проверен", severity="info")]

    # Самый частый
    main_spacing = max(spacing_counts, key=spacing_counts.get)
    main_count = spacing_counts[main_spacing]
    main_ratio = main_count / non_empty

    if main_spacing in ("1.5", "1.5 (rule)") and main_ratio >= 0.8:
        results.append(check(
            True,
            f"Междустрочный интервал 1,5 применён в {main_count}/{non_empty} абзацах "
            f"({main_ratio*100:.0f}%) — соответствует методичке"
        ))
    elif main_spacing in ("1.5", "1.5 (rule)"):
        results.append(check(
            False,
            f"Междустрочный интервал 1,5 применён только в {main_ratio*100:.0f}% абзацев. "
            f"Остальные: {dict((k, v) for k, v in spacing_counts.items() if k not in ('1.5', '1.5 (rule)'))}. "
            f"Проверь в Word: выделить всё (Ctrl+A) → межстрочный интервал 1,5.",
            severity="warning"
        ))
    else:
        results.append(check(
            False,
            f"Основной междустрочный интервал — «{main_spacing}» ({main_count} абзацев). "
            f"Методичка МПГУ требует 1,5. Выдели всё и поменяй в Word.",
            severity="error"
        ))

    return results


def check_first_line_indent(doc: Document) -> list:
    """Проверка отступа первой строки абзаца (методичка МПГУ: 1,25 см).

    Проверяем только абзацы основного текста (не заголовки, не таблицы
    содержания, не подписи). Допустимая погрешность: 0.1 см.

    КРИТИЧНО: пропускаем ВСЕ абзацы до первого заголовка «Аннотация»
    или «Содержание» — это титульник, где по определению нет отступов
    (имя автора, научрука, название кафедры, год, город и т.п.).
    Без этого валидатор ложно ругается на «Скориков Николай Александрович»,
    «доцент, канд. пед. наук» и т.п.
    """
    results = []

    EXPECTED_CM = 1.25
    TOLERANCE = 0.1

    # Определяем индекс первого «не-титульного» абзаца: заголовок «Аннотация»
    # или «Содержание» или «Введение» или «Глава»
    body_start_idx = 0
    for i, p in enumerate(doc.paragraphs):
        text_lower = p.text.strip().lower()
        if text_lower in ("аннотация", "содержание", "оглавление", "введение"):
            body_start_idx = i
            break
        if text_lower.startswith(("глава ",)):
            body_start_idx = i
            break
    # Если ничего из этого не нашли — берём первые 15 абзацев как титульник
    if body_start_idx == 0 and len(doc.paragraphs) > 15:
        body_start_idx = 15

    # Классифицируем абзацы: основной текст vs служебные
    heading_styles = {"Heading 1", "Heading 2", "Heading 3", "ГлаваМПГУ", "Title"}
    # Служебные маркеры — прочерки, плейсхолдеры, подписи под таблицами
    service_patterns = [
        "_______",  # прочерки подписей/заполнения
        "[Для обновления",
        "⚠️",  # предупреждения скрипта
        "Ф.И.О.",
        "Источник:",  # подпись таблицы
        "выполнена мной совершенно самостоятельно",  # клятва
    ]

    correct = 0
    wrong = 0
    wrong_examples = []

    # ВАЖНО: начинаем с body_start_idx, пропуская весь титульник
    for p in doc.paragraphs[body_start_idx:]:
        text = p.text.strip()
        if not text or len(text) < 20:
            continue  # короткие строки (заголовки, подписи) — пропускаем
        style_name = (p.style.name if p.style else "") or ""
        if style_name in heading_styles:
            continue
        # Служебные абзацы (клятва, плейсхолдеры) — не считаем
        if any(marker in text for marker in service_patterns):
            continue
        # Абзац начинается со скобки — типичная подпись под таблицей/рисунком
        if text.startswith("(") and text.endswith(")") and len(text) < 80:
            continue
        # Параграфы, которые по внешнему виду — заголовки (центрированные, bold)
        try:
            if p.alignment is not None and int(p.alignment) == 1:  # CENTER
                continue
        except (TypeError, ValueError):
            pass

        indent_emu = p.paragraph_format.first_line_indent
        if indent_emu is None:
            # Не задано в абзаце — берём из стиля Normal (там 1,25 см — это корректно)
            correct += 1
            continue
        try:
            indent_cm = indent_emu.cm
        except AttributeError:
            indent_cm = float(indent_emu) / 360000  # EMU → см
        if abs(indent_cm - EXPECTED_CM) <= TOLERANCE:
            correct += 1
        else:
            wrong += 1
            if len(wrong_examples) < 3:
                wrong_examples.append(f"{text[:40]}… ({indent_cm:.2f} см)")

    total = correct + wrong
    if total == 0:
        return [check(True, "Нет абзацев основного текста для проверки отступа", severity="info")]

    ratio = correct / total
    if ratio >= 0.85:
        results.append(check(
            True,
            f"Отступ первой строки 1,25 см — в {correct}/{total} абзацах ({ratio*100:.0f}%)"
        ))
    elif ratio >= 0.6:
        results.append(check(
            False,
            f"Отступ 1,25 см применён только в {ratio*100:.0f}% абзацев. "
            f"Примеры с неверным отступом: {', '.join(wrong_examples)}. "
            f"В Word: Ctrl+A → абзац → первая строка → 1,25 см.",
            severity="warning"
        ))
    else:
        results.append(check(
            False,
            f"Отступ 1,25 см НЕ соблюдён ({correct}/{total} абзацев корректны). "
            f"Методичка требует 1,25 см для красной строки. Поправь в Word.",
            severity="error"
        ))

    return results


def check_font_color(doc: Document) -> list:
    """Проверка цвета шрифта (методичка: «Цвет — чёрный»).

    Находит все непустые run'ы с явно заданным цветом и проверяет,
    что ни один не выбивается за пределы чёрного (RGB 0,0,0) или
    очень тёмного серого. Особенно проверяет заголовки — стандартные
    стили Word Heading 1/2 по умолчанию синие (#365F91, #4F81BD),
    и если цвет в run не переопределён, работа сдаётся с синими главами.
    """
    results = []

    nonblack_runs = []  # (text_preview, rgb_hex, style_name)
    heading_styles = {"Heading 1", "Heading 2", "Heading 3", "ГлаваМПГУ"}

    for para in doc.paragraphs:
        style_name = (para.style.name if para.style else "") or ""
        for run in para.runs:
            if not run.text.strip():
                continue
            color = run.font.color
            rgb = color.rgb if color and color.rgb else None
            if rgb is None:
                # Цвет не задан на уровне run — берётся из стиля.
                # Если стиль Heading — предупреждаем отдельно.
                if style_name in heading_styles:
                    # В docx стиль Heading обычно синий — это риск
                    nonblack_runs.append((
                        run.text[:40],
                        "inherits from style",
                        style_name
                    ))
                continue
            # Проверяем: чёрный или близко к нему
            r, g, b = rgb[0], rgb[1], rgb[2]
            if r > 30 or g > 30 or b > 30:
                # Не чёрный
                hex_repr = f"#{r:02X}{g:02X}{b:02X}"
                nonblack_runs.append((run.text[:40], hex_repr, style_name))

    if not nonblack_runs:
        results.append(check(
            True,
            "Цвет шрифта везде чёрный (или близко к нему)"
        ))
        return results

    # Группируем по цвету для краткости
    color_counts = {}
    for _, hex_repr, style in nonblack_runs:
        key = (hex_repr, style)
        color_counts[key] = color_counts.get(key, 0) + 1

    for (hex_repr, style), count in sorted(color_counts.items(), key=lambda x: -x[1])[:5]:
        if hex_repr == "inherits from style":
            results.append(check(
                False,
                f"Стиль «{style}»: {count} run'ов без явного цвета шрифта. "
                f"Стандартный {style} в Word — синий (#365F91 или #4F81BD), "
                f"а методичка МПГУ требует чёрный. Проверь глазами в Word.",
                severity="error"
            ))
        else:
            results.append(check(
                False,
                f"Найден не-чёрный цвет {hex_repr}: {count} run'ов "
                f"(стиль «{style or 'Normal'}»). Методичка: «Цвет — чёрный».",
                severity="error"
            ))

    return results


def check_annotation_content(doc: Document) -> list:
    """Проверка содержимого аннотации (методичка МПГУ).

    Методичка требует, чтобы аннотация содержала:
    - Название работы
    - Объём (количество страниц)
    - Число использованных источников
    - Ключевые слова (5-7 штук)
    - Объект / предмет исследования
    - Цель / задачи / актуальность

    Объём — до 0.5 страницы (~800-1000 символов максимум).
    """
    results = []

    # Собираем текст аннотации между заголовком «Аннотация» и следующим разделом
    paragraphs = list(doc.paragraphs)
    start_idx = None
    for i, p in enumerate(paragraphs):
        if p.text.strip().lower() == "аннотация":
            start_idx = i + 1
            break

    if start_idx is None:
        # Нет секции — другой checker уже ругнулся на это
        return [check(True, "Аннотация не найдена (проверить через check_structure)", severity="info")]

    stop_keywords = ("содержание", "оглавление", "введение", "глава")
    end_idx = len(paragraphs)
    for i in range(start_idx, len(paragraphs)):
        tl = paragraphs[i].text.strip().lower()
        if any(tl.startswith(sw) for sw in stop_keywords) and len(tl) < 80:
            end_idx = i
            break

    annotation_text = "\n".join(p.text for p in paragraphs[start_idx:end_idx]).strip()

    if len(annotation_text) < 100:
        results.append(check(
            False,
            f"Аннотация слишком короткая ({len(annotation_text)} симв.) или пуста. "
            "По методичке — до 0.5 страницы, ~500-1000 симв., с перечислением "
            "объёма, источников, объекта, цели, ключевых слов.",
            severity="warning"
        ))
        return results

    # Объём (количество страниц): «45 страниц», «45 стр.», «на 45 страницах», «45 с.»
    if not re.search(r"\b\d{2,3}\s*(?:стр\w*|с\.)", annotation_text, re.IGNORECASE):
        results.append(check(
            False,
            "В аннотации не указан объём работы (например, «Работа изложена на 55 страницах»). "
            "Методичка требует указания количества страниц.",
            severity="warning"
        ))

    # Число источников: «N источников», «использовано N источников»
    # Количество источников — ловим оба порядка: «42 источника» и «источников: 42»
    if not re.search(
        r"\b\d{1,3}\s*источник\w*|источник\w*[\s:—–-]*\d{1,3}\b",
        annotation_text,
        re.IGNORECASE
    ):
        results.append(check(
            False,
            "В аннотации не указано число использованных источников "
            "(например, «Список литературы включает 45 источников»).",
            severity="warning"
        ))

    # Ключевые слова: «Ключевые слова:» или «Key words:»
    if not re.search(r"ключевые\s+слова", annotation_text, re.IGNORECASE):
        results.append(check(
            False,
            "В аннотации нет раздела «Ключевые слова» (5-7 штук по методичке).",
            severity="warning"
        ))

    # Объём: не должен превышать 0.5 стр ≈ 1200 символов (жёсткий предел)
    if len(annotation_text) > 1500:
        results.append(check(
            False,
            f"Аннотация слишком длинная ({len(annotation_text)} симв.). "
            "По методичке — до 0.5 страницы (~1000 симв., абсолютный максимум ~1500).",
            severity="warning"
        ))

    # Если все проверки прошли
    has_errors = any(not r["ok"] for r in results)
    if not has_errors:
        results.append(check(
            True,
            f"Аннотация содержит объём работы, число источников, ключевые слова "
            f"({len(annotation_text)} симв.) — формально корректна"
        ))

    return results


def check_structure(doc: Document) -> list:
    """Проверка наличия обязательных структурных частей.

    Ловит не любое упоминание слова в тексте (баг старой версии: «в
    заключении главы 1...» засчитывалось как «Заключение»), а именно
    самостоятельный заголовок раздела. Признаки самостоятельного
    заголовка: короткая строка + применён стиль Heading ИЛИ полужирный
    хотя бы в одном run ИЛИ выравнивание по центру.
    """
    results = []

    required = {
        "аннотация": "Аннотация",
        "содержание": ("Содержание / Оглавление", ("содержание", "оглавление")),
        "введение": "Введение",
        "глава": ("Хотя бы одна Глава",
                  # Для главы допустим любой вариант написания
                  ("глава 1", "глава 2", "глава 3", "глава i", "глава ii", "глава iii")),
        "заключение": "Заключение",
        "список": ("Список литературы",
                   ("список использованной литературы", "список литературы", "библиография")),
    }

    def is_standalone_heading(para, key_variants) -> bool:
        """Параграф — самостоятельный заголовок раздела?"""
        text = para.text.strip()
        if len(text) > 100:
            return False
        text_lower = text.lower()
        # Сначала проверяем, что текст начинается с одного из ключей раздела
        if not any(text_lower.startswith(kv) for kv in key_variants):
            return False
        # И что это действительно заголовок, а не упоминание в середине текста:
        # (а) стиль Heading
        style_name = (para.style.name if para.style else "") or ""
        if style_name.startswith("Heading") or "глава" in style_name.lower():
            return True
        # (б) выравнивание по центру (типичный для заголовков разделов МПГУ)
        if para.alignment is not None and int(para.alignment) == 1:  # 1 = CENTER
            return True
        # (в) любой bold-run в параграфе
        for run in para.runs:
            if run.bold:
                return True
        # (г) короткая строка, совпадающая с самим заголовком (без лишних слов)
        # — например, просто "Введение" без продолжения
        return text_lower in key_variants or any(text_lower == kv for kv in key_variants)

    for key, value in required.items():
        if isinstance(value, tuple):
            title, variants = value
        else:
            title = value
            variants = (key,)

        found = any(is_standalone_heading(p, variants) for p in doc.paragraphs)
        results.append(check(
            found,
            f"Раздел '{title}' — {'найден' if found else 'НЕ НАЙДЕН'}",
            severity="error" if not found else "info"
        ))

    return results


def check_personal_pronouns(doc: Document) -> list:
    """Проверка наличия личных местоимений.

    Важно: перед проверкой удаляются из текста все инициалы
    (паттерны типа «И.Я.», «А.М.», «Я.Л.»), потому что regex \\bя\\b
    с re.IGNORECASE иначе матчится на «Я» в инициалах педагогов
    (Лернер И.Я., Коломинский Я.Л. — классика МПГУ). Это было бы
    десятки ложных срабатываний на типичной теоретической главе.
    Также удаляются «Ё.О.» на всякий случай.
    """
    results = []
    full_text_raw = "\n".join(p.text for p in doc.paragraphs)

    # Удаляем инициалы из текста перед проверкой местоимений.
    # Паттерны: «И.Я.», «И. Я.», «И.Я», «А.Б.В.» — одна или две заглавных буквы с точками.
    # Также «И.О.» после или перед фамилией.
    initial_pattern = re.compile(
        r"\b[А-ЯЁA-Z]\.\s?[А-ЯЁA-Z]\.(?:\s?[А-ЯЁA-Z]\.)?"
    )
    full_text = initial_pattern.sub(" ", full_text_raw)
    # Плюс одиночные инициалы типа «И.» перед фамилией — защищаем «И» и тому подобное
    single_initial_pattern = re.compile(r"\b[А-ЯЁA-Z]\.")
    full_text = single_initial_pattern.sub(" ", full_text)

    found_errors = []
    for pattern in PERSONAL_PRONOUNS:
        if pattern in PRONOUNS_SOFT:
            continue  # soft-list проверяем отдельно
        matches = re.findall(pattern, full_text, re.IGNORECASE)
        if matches:
            label = pattern.replace(r"\b", "").strip("^$\\")
            found_errors.append(f"{label}: {len(matches)} раз")

    found_warnings = []
    for pattern in PRONOUNS_SOFT:
        matches = re.findall(pattern, full_text, re.IGNORECASE)
        if matches:
            label = pattern.replace(r"\b", "").strip("^$\\")
            found_warnings.append(f"{label}: {len(matches)} раз")

    if found_errors:
        results.append(check(
            False,
            f"Найдены ЗАПРЕЩЁННЫЕ местоимения: {', '.join(found_errors)}. "
            "Замени на безличные конструкции!"
        ))
    else:
        results.append(check(True, "Запрещённых личных местоимений не найдено"))

    if found_warnings:
        results.append(check(
            False,
            f"Найдены условно-допустимые местоимения: {', '.join(found_warnings)}. "
            "Проверь по методичке твоей кафедры — может требоваться замена.",
            severity="warning"
        ))

    return results


def check_ai_cliches(doc: Document) -> list:
    """Проверка признаков ИИ-текста: характерные клише.

    v6.26-friends: фразы из персонального CLICHE_ALLOWLIST (state-файл,
    поле cliche_allowlist) НЕ учитываются. Это позволяет каждому
    пользователю в группе иметь индивидуальный набор «допустимых» клише
    и тем снизить негативную сигнатуру (одинаковое отсутствие одних и
    тех же фраз у группы пользователей одного скилла).
    """
    results = []
    full_text = "\n".join(p.text for p in doc.paragraphs).lower()

    # Эффективный список клише = глобальный минус персональный allowlist
    effective_cliches = [c for c in AI_CLICHES if c not in CLICHE_ALLOWLIST]

    found = []
    total_count = 0
    for cliche in effective_cliches:
        count = full_text.count(cliche)
        if count > 0:
            found.append((cliche, count))
            total_count += count

    # Информационное сообщение, если allowlist активен
    if CLICHE_ALLOWLIST:
        results.append(check(
            True,
            f"Активен персональный cliche_allowlist ({len(CLICHE_ALLOWLIST)} фраз "
            f"из state-файла) — эти клише не учитываются.",
            severity="info"
        ))

    if total_count == 0:
        results.append(check(True, "ИИ-клише не найдены"))
    elif total_count <= 3:
        top = ", ".join(f"«{c}» ({n})" for c, n in sorted(found, key=lambda x: -x[1])[:3])
        results.append(check(
            True,
            f"ИИ-клише встречаются редко ({total_count} шт. всего). "
            f"Топ: {top}. Это в пределах нормы.",
            severity="info"
        ))
    elif total_count <= 8:
        top = ", ".join(f"«{c}» ({n})" for c, n in sorted(found, key=lambda x: -x[1])[:5])
        results.append(check(
            False,
            f"Повышенное содержание ИИ-клише: {total_count} шт. "
            f"Топ: {top}. Рекомендуется сократить.",
            severity="warning"
        ))
    else:
        top = ", ".join(f"«{c}» ({n})" for c, n in sorted(found, key=lambda x: -x[1])[:5])
        results.append(check(
            False,
            f"КРИТИЧНО: много ИИ-клише ({total_count} шт.). "
            f"Топ: {top}. Работа воспринимается как ИИ-текст. "
            f"Переработай начала абзацев (см. humanizer-techniques.md)."
        ))

    return results


def check_paragraph_rhythm(doc: Document) -> list:
    """Проверка ритма абзацев — не слишком ли одинаковые по длине."""
    results = []

    # Берём только содержательные абзацы (игнорируя короткие заголовки)
    paragraphs = [p.text for p in doc.paragraphs if len(p.text) > 50]
    if len(paragraphs) < 10:
        return [check(True, "Слишком мало абзацев для анализа ритма", severity="info")]

    lengths = [len(p) for p in paragraphs]
    mean = statistics.mean(lengths)
    stdev = statistics.stdev(lengths) if len(lengths) > 1 else 0

    # Коэффициент вариации = stdev / mean
    cv = stdev / mean if mean > 0 else 0

    if cv < 0.25:
        results.append(check(
            False,
            f"Слишком ровный ритм абзацев (CV={cv:.2f}, требуется >0.3). "
            f"Средняя длина {mean:.0f} символов, разброс маленький. "
            f"Признак ИИ-текста! Разбей или объедини некоторые абзацы, чтобы было разнообразие.",
            severity="warning"
        ))
    elif cv < 0.35:
        results.append(check(
            True,
            f"Ритм абзацев приемлемый, но монотонный (CV={cv:.2f}). "
            f"Можно улучшить, разбавив короткими (2 предложения) и длинными (7-8 предложений) абзацами.",
            severity="info"
        ))
    else:
        results.append(check(True, f"Хороший ритм абзацев (CV={cv:.2f})"))

    return results


def check_consecutive_same_starts(doc: Document) -> list:
    """Проверка: нет ли подряд абзацев с одинаковыми первыми словами."""
    results = []
    paragraphs = [p.text.strip() for p in doc.paragraphs if len(p.text) > 50]

    consecutive_count = 0
    max_consecutive = 0
    prev_start = ""

    problematic_starts = []

    for para in paragraphs:
        # Первые 2 слова
        words = para.split()[:2]
        start = " ".join(words).lower()
        if start == prev_start and start:
            consecutive_count += 1
            if consecutive_count > max_consecutive:
                max_consecutive = consecutive_count
                problematic_starts.append(start)
        else:
            consecutive_count = 1
        prev_start = start

    if max_consecutive >= 3:
        results.append(check(
            False,
            f"Найдено {max_consecutive} абзацев подряд, начинающихся одинаково. "
            f"Это признак шаблонного текста. Варьируй начала абзацев.",
            severity="warning"
        ))
    else:
        results.append(check(True, "Начала абзацев разнообразны"))

    return results


def _extract_citation_numbers(text: str) -> list:
    """Извлечь номера источников из всех типов ссылок.

    Покрывает: [15], [15, с. 23], [15, с. 23-25], [15; 17], [15, 17, 19],
    [Цит. по: 27, с. 235], [См.: 12; 13].
    Возвращает список всех номеров (с повторениями) в порядке появления.
    """
    numbers = []
    for match in re.finditer(r"\[([^\[\]]+)\]", text):
        content = match.group(1)
        # Убираем «с. N» и «стр. N» — это номера страниц, не источников
        cleaned = re.sub(r"с\.\s*\d+(?:-\d+)?", "", content)
        cleaned = re.sub(r"стр\.\s*\d+(?:-\d+)?", "", cleaned)
        # Извлекаем остальные числа — это номера источников
        for num_match in re.finditer(r"\b(\d+)\b", cleaned):
            n = int(num_match.group(1))
            if 1 <= n <= 500:
                numbers.append(n)
    return numbers


def check_citations(doc: Document) -> list:
    """Проверка наличия ссылок в тексте.

    Использует общий парсер _extract_citation_numbers, который понимает
    ссылки всех типов ([N], [N, с. X], [N; M], [Цит. по: N, с. X]).
    """
    results = []
    full_text = "\n".join(p.text for p in doc.paragraphs)

    citations = _extract_citation_numbers(full_text)

    if len(citations) < 20:
        results.append(check(
            True,
            f"В тексте найдено {len(citations)} ссылок. "
            f"Это ниже рабочего ориентира скилла (20+), но методички ИМО не "
            f"задают формального минимума. Сверь число с требованиями кафедры и "
            f"проверь, что каждый источник из списка упомянут в тексте.",
            severity="info"
        ))
    else:
        results.append(check(
            True,
            f"Ссылок в тексте: {len(citations)} (уникальных источников: {len(set(citations))})",
            severity="info"
        ))

    # Проверка: в заключении не должно быть ссылок!
    # ВАЖНО: определяем «заключение» как самостоятельный заголовок, а не любой абзац,
    # начинающийся со слова «Заключение». Абзацы типа «Заключение первой главы...»
    # раньше давали false-positive (триггерили режим «в заключении» посреди главы 1).
    def _is_conclusion_heading(p) -> bool:
        text = p.text.strip()
        text_lower = text.lower().rstrip(".")
        # Самостоятельный короткий заголовок: «Заключение» (и близкие варианты)
        if text_lower not in ("заключение",):
            return False
        # Дополнительно — должен иметь признаки заголовка:
        # (а) Heading-стиль, (б) центрированный, (в) жирный run, (г) просто короткий
        style_name = (p.style.name if p.style else "") or ""
        if style_name.startswith("Heading"):
            return True
        if p.alignment is not None and int(p.alignment) == 1:
            return True
        if any(r.bold for r in p.runs):
            return True
        # Если просто «Заключение» одной строкой без пунктуации — тоже заголовок
        return len(text) <= 15

    in_conclusion = False
    conclusion_citations = 0
    for para in doc.paragraphs:
        if _is_conclusion_heading(para):
            in_conclusion = True
            continue
        text_lower = para.text.strip().lower()
        if in_conclusion and (text_lower.startswith("список") or
                              text_lower.startswith("библиография") or
                              text_lower.startswith("приложение")):
            in_conclusion = False
            continue
        if in_conclusion:
            conclusion_citations += len(_extract_citation_numbers(para.text))

    if conclusion_citations > 0:
        results.append(check(
            False,
            f"В заключении найдено {conclusion_citations} ссылок. "
            "По методичке МПГУ в заключении ссылок и цитат БЫТЬ НЕ ДОЛЖНО!"
        ))
    else:
        results.append(check(True, "В заключении нет ссылок — хорошо"))

    return results


def check_surnames_format(doc: Document) -> list:
    """Проверка: фамилии в тексте должны быть с инициалами."""
    results = []
    full_text = "\n".join(p.text for p in doc.paragraphs)

    # Список НЕ-фамилий с теми же окончаниями (прилагательные, названия организаций, географические)
    NOT_SURNAMES = {
        # Прилагательные на -ский/-ская/-ское/-ий/-ая/-ое
        "теоретическая", "теоретический", "теоретическое",
        "практическая", "практический", "практическое",
        "аналитическая", "аналитический", "аналитическое",
        "эмпирическая", "эмпирический", "эмпирическое",
        "общественная", "общественный", "общественное",
        "педагогическая", "педагогический", "педагогическое",
        "психологическая", "психологический", "психологическое",
        "методическая", "методический", "методическое",
        "техническая", "технический", "техническое",
        "электронная", "электронный", "электронное",
        "российская", "российский", "российское",
        "статистическая", "статистический", "статистическое",
        "педагогических", "практических", "теоретических",
        "исследовательская", "исследовательский",
        "информационная", "информационный", "информационное",
        # Географические
        "московский", "московская", "московское",
        "петербургский", "петербургская",
        "санкт-петербургский",
        # Институциональные
        "государственный", "государственная", "государственное",
        "федеральный", "федеральная", "федеральное",
        "университетский", "университетская",
        "городской", "городская", "городское",
        # Частотные частицы / вводные
        "данный", "данная", "данное", "данные", "данных",
        "самый", "самая", "самое",
        # Причастия на -ский/-ская/вид
        "описательный", "описательная",
        "сравнительный", "сравнительная",
        # Пед. терминология
        "деятельностный", "деятельностная",
        "системный", "системная", "системное", "системные", "системных",
        "когнитивный", "когнитивная",
        # Дополнительные ходовые (найдены аудитом v6.10)
        "комплексный", "комплексная", "комплексное", "комплексные",
        "индустриальный", "индустриальная", "индустриальное",
        "культурный", "культурная", "культурное",
        "традиционный", "традиционная", "традиционное",
        "функциональный", "функциональная", "функциональное",
        "оперативный", "оперативная", "оперативное",
        "учебный", "учебная", "учебное",
        "служебный", "служебная", "служебное",
        "организационный", "организационная", "организационное",
        "финансовый", "финансовая", "финансовое",
        "социальный", "социальная", "социальное",
        "экологический", "экологическая", "экологическое",
        "цифровой", "цифровая", "цифровое", "цифровые", "цифровых",
        "структурный", "структурная", "структурное",
        "европейский", "европейская", "европейское",
        "православный", "православная",
        "качественный", "качественная", "качественное",
        "количественный", "количественная", "количественное",
        "современный", "современная", "современное", "современных",
        "научный", "научная", "научное", "научных",
        "образовательный", "образовательная", "образовательное",
        "нормативный", "нормативная", "нормативное",
        "типовой", "типовая", "типовое",
        "основной", "основная", "основное", "основные", "основных",
        "дополнительный", "дополнительная", "дополнительное",
        "внутренний", "внутренняя", "внутреннее",
        "внешний", "внешняя", "внешнее",
        "программный", "программная", "программное",
        "сетевой", "сетевая", "сетевое",
        "мобильный", "мобильная", "мобильное",
    }

    # Ищем слова с типичными фамильными окончаниями
    surname_pattern = re.compile(
        r"\b([А-Я][а-я]{3,})(ов|ова|ев|ева|ин|ина|ский|ская|цкий|цкая)\b"
    )

    surnames_without_initials = []
    for match in surname_pattern.finditer(full_text):
        full_word = match.group(0).lower()
        # Пропускаем известные не-фамилии
        if full_word in NOT_SURNAMES:
            continue
        start = max(0, match.start() - 15)
        context_before = full_text[start:match.start()]
        # Если перед словом есть инициалы (буква + точка + пробел) — всё ок
        if not re.search(r"[А-Я]\.\s*[А-Я]\.\s*$", context_before):
            # Исключения: если инициалы стоят сразу ПОСЛЕ — тоже ок
            after = full_text[match.end():match.end()+10]
            if re.search(r"^\s*[А-Я]\.\s*[А-Я]\.", after):
                continue
            # Исключаем слова в начале предложения — вероятно, это не фамилия
            if context_before.rstrip().endswith(".") or not context_before.strip():
                continue
            surnames_without_initials.append(match.group(0))

    unique = list(set(surnames_without_initials))[:10]

    if len(unique) > 3:
        results.append(check(
            False,
            f"Возможно, фамилии без инициалов: {', '.join(unique)}... "
            "По методичке инициалы должны стоять ПЕРЕД фамилией через пробел. "
            "Проверь вручную!",
            severity="warning"
        ))
    else:
        results.append(check(True, "Фамилии в целом оформлены с инициалами"))

    return results


def _looks_like_chapter_heading(para, text: str) -> bool:
    """Проверяет, похож ли абзац на настоящий заголовок главы (а не строку оглавления).

    Признаки НАСТОЯЩЕГО заголовка:
    - Стиль Heading 1/2 / "ГлаваМПГУ" (если применён)
    - Полужирное начертание
    - Короткая строка (заголовок обычно укладывается в одну строку)
    - НЕТ в конце номера страницы (типа «... 10»)
    - НЕТ паттернов оглавления (длинные цепочки точек-заполнителей, tab'ы)
    """
    tl = text.lower()
    if not re.match(r"^глав[аы]?\s+[ivxlcm\d]+\b", tl):
        return False

    # 1. Отсекаем явные признаки строки оглавления
    # Номер страницы в конце: "Глава I. Тема ... 10" или "Глава I Тема\t10"
    if re.search(r"\.\.\.\.+\s*\d+\s*$", text):
        return False
    if re.search(r"\t+\d+\s*$", text):
        return False
    if re.search(r"\s+\.\s*\.\s*\.\s*\.", text):
        # Много разрозненных точек-заполнителей
        return False
    # Номер страницы после пробелов без других слов между: «Глава I 10» или «Глава I ... 10»
    if re.search(r"\.\s*\.\s*\.\s*\d+\s*$", text):
        return False

    # 2. Заголовок главы обычно короткий (< 120 символов)
    if len(text) > 150:
        return False

    # 3. Если это стиль Heading 1/2 — точно заголовок
    style_name = (para.style.name if para.style else "") or ""
    if style_name.startswith("Heading") or "глава" in style_name.lower():
        return True

    # 4. Если bold хотя бы один run — вероятно заголовок
    for run in para.runs:
        if run.bold:
            return True

    # 5. Fallback: короткая строка, начинается с «Глава», не похожая на оглавление
    # — считаем заголовком, если длина < 80
    return len(text) < 80


def check_chapter_lengths(doc: Document) -> list:
    """Проверка длины глав и общего объёма работы.

    Фильтрует строки оглавления (с номерами страниц / точками-заполнителями) —
    они не должны считаться настоящими главами.
    """
    results = []

    # Собираем главы по заголовкам
    chapters = []
    current = None

    for p in doc.paragraphs:
        text = p.text.strip()
        tl = text.lower()

        # Определяем начало главы (строгая проверка — не оглавление)
        if _looks_like_chapter_heading(p, text):
            if current is not None:
                chapters.append(current)
            current = {"title": text, "paragraphs": [], "chars": 0}
        elif current is not None and text:
            # Останавливаемся на заключении или списке литературы
            if tl.startswith("заключение") or tl.startswith("список"):
                chapters.append(current)
                current = None
            else:
                current["paragraphs"].append(text)
                current["chars"] += len(text)

    if current is not None:
        chapters.append(current)

    if not chapters:
        return [check(True, "Главы не найдены (возможно, нестандартные заголовки)", severity="info")]

    # Оцениваем длину: примерно 3000 символов на страницу с учётом пробелов
    # Ёмкость страницы А4 при требованиях методички МПГУ:
    # - поля 35/10/20/20 мм → текстовая область 165 × 257 мм
    # - TNR 14 pt × 1.5 интервал → ~30-34 строки на страницу
    # - средняя строка 165 мм → 48-55 знаков
    # → реалистично 1500-1800 знаков на страницу
    CHARS_PER_PAGE = 1800

    for i, ch in enumerate(chapters, 1):
        pages = ch["chars"] / CHARS_PER_PAGE
        if pages < 5:
            results.append(check(
                False,
                f"Глава {i} «{ch['title'][:40]}...»: ~{pages:.1f} стр. — "
                f"очень мало по эвристике баланса. Проверь, раскрыта ли функция "
                f"главы и согласована ли такая структура с научным руководителем.",
                severity="warning"
            ))
        elif pages < 8:
            results.append(check(
                False,
                f"Глава {i} «{ch['title'][:40]}...»: ~{pages:.1f} стр. — "
                f"ниже рабочего ориентира 8 стр. Это не формальный порог допуска: "
                f"оцени полноту главы по её задачам и профилю программы.",
                severity="warning"
            ))
        elif pages > 25:
            results.append(check(
                False,
                f"Глава {i} «{ch['title'][:40]}...»: ~{pages:.1f} стр. — слишком много "
                f"для рабочего ориентира баланса (12-20 стр.); проверь структуру по плану",
                severity="warning"
            ))
        else:
            results.append(check(
                True,
                f"Глава {i}: ~{pages:.1f} стр. (в рабочем диапазоне эвристики)",
                severity="info"
            ))

    # Общий объём.
    # Базовые методички ИМО:
    # - обычная (теоретическая) ВКР: 50-60 стр.
    # - проектная ВКР: 40-50 стр.
    # Используем широкий объединённый диапазон (35-65) как рабочий ориентир,
    # а более узкие — как справочную информацию. Это избавляет
    # от необходимости угадывать тип работы, но даёт студенту ориентир.
    total_chars = sum(ch["chars"] for ch in chapters)
    total_pages = total_chars / CHARS_PER_PAGE

    if 35 <= total_pages <= 65:
        verdict = "ok"
        severity_level = "info"
    elif total_pages < 35:
        verdict = "too_small"
        severity_level = "warning"
    else:
        verdict = "too_big"
        severity_level = "warning"

    results.append(check(
        verdict == "ok",
        f"Суммарный объём глав: ~{total_pages:.1f} стр. "
        f"(базовые ориентиры ИМО: проектная ВКР 40-50 стр., обычная 50-60 стр.; "
        f"точный диапазон определяется программой)",
        severity=severity_level
    ))

    return results


def check_figure_table_references(doc: Document) -> list:
    """Проверка: все ли таблицы и рисунки упомянуты в тексте."""
    results = []
    full_text = "\n".join(p.text for p in doc.paragraphs)

    # Ищем таблицы и рисунки по подписям
    table_labels = re.findall(r"Таблица\s+(\d+)", full_text)
    figure_labels = re.findall(r"Рисунок\s+(\d+)", full_text)

    # Ищем упоминания в тексте (в форме "в таблице N", "см. табл. N", "на рисунке N", "см. рис. N")
    table_refs_patterns = [
        r"табл(?:ица|ицы|ице|ицу|ицей)?\s*(\d+)",
        r"табл\.\s*(\d+)",
    ]
    figure_refs_patterns = [
        r"рис(?:унок|унка|унке|унком|унков)?\s*(\d+)",
        r"рис\.\s*(\d+)",
    ]

    table_refs = set()
    for pat in table_refs_patterns:
        table_refs.update(re.findall(pat, full_text, re.IGNORECASE))

    figure_refs = set()
    for pat in figure_refs_patterns:
        figure_refs.update(re.findall(pat, full_text, re.IGNORECASE))

    # Таблицы, которые есть, но не упомянуты
    unique_tables = set(table_labels)
    unreferenced_tables = unique_tables - table_refs
    unique_figures = set(figure_labels)
    unreferenced_figures = unique_figures - figure_refs

    if unique_tables:
        if unreferenced_tables:
            results.append(check(
                False,
                f"Таблицы {sorted(unreferenced_tables)} не упомянуты в тексте. "
                f"Каждая таблица должна иметь ссылку в тексте («в таблице 1», «см. табл. 1»).",
                severity="warning"
            ))
        else:
            results.append(check(True, f"Все {len(unique_tables)} таблиц(ы) упомянуты в тексте"))

    if unique_figures:
        if unreferenced_figures:
            results.append(check(
                False,
                f"Рисунки {sorted(unreferenced_figures)} не упомянуты в тексте. "
                f"Каждый рисунок должен иметь ссылку в тексте («на рисунке 1», «см. рис. 1»).",
                severity="warning"
            ))
        else:
            results.append(check(True, f"Все {len(unique_figures)} рисунок(ов) упомянуты в тексте"))

    if not unique_tables and not unique_figures:
        results.append(check(
            True,
            "Таблиц и рисунков не найдено (для IT-ВКР странно — обычно есть)",
            severity="info"
        ))

    return results


def check_toc_filled(doc: Document) -> list:
    """Проверка: оглавление реально заполнено (не остался плейсхолдер).

    Скрипт create_vkr_docx.py вставляет TOC как поле Word с плейсхолдером
    «[Для обновления содержания: щёлкните правой кнопкой → Обновить поле]».
    Если студент забыл нажать F9 в Word, сдаст работу с пустым оглавлением.
    Ищем типичные признаки пустого TOC и ругаемся.
    """
    results = []

    # Находим параграф с заголовком «Содержание»
    paragraphs = list(doc.paragraphs)
    toc_start = None
    for i, p in enumerate(paragraphs):
        if p.text.strip().lower() in ("содержание", "оглавление"):
            toc_start = i
            break

    if toc_start is None:
        return [check(True, "Содержание не найдено — проверка пропущена", severity="info")]

    # Смотрим следующие 30 параграфов после заголовка — там должно быть оглавление
    toc_content = []
    for p in paragraphs[toc_start + 1: toc_start + 31]:
        text = p.text.strip()
        if not text:
            continue
        # Следующий крупный раздел (Введение, Глава) — конец TOC
        if re.match(r"^(введение|глава\s+[ivxlcm\d])", text.lower()):
            break
        toc_content.append(text)

    toc_text = "\n".join(toc_content)

    # Признак пустого TOC: плейсхолдер, квадратные скобки, или очень короткий текст
    if "[Для обновления" in toc_text or "щёлкните правой" in toc_text:
        results.append(check(
            False,
            "Оглавление НЕ обновлено — остался плейсхолдер «[Для обновления содержания…]». "
            "Открой файл в Word, щёлкни правой кнопкой по оглавлению → «Обновить поле» → "
            "«Обновить целиком» (или F9). Без этого работа уйдёт на нормоконтроль с пустым "
            "оглавлением.",
            severity="error"
        ))
    elif len(toc_text) < 50:
        results.append(check(
            False,
            f"Оглавление подозрительно пустое (всего {len(toc_text)} символов). "
            "Проверь в Word: должны быть строки с заголовками и номерами страниц.",
            severity="warning"
        ))
    else:
        # Ищем номера страниц — признак заполненного TOC
        page_numbers_found = len(re.findall(r"\.\.+\s*\d+\s*$", toc_text, re.MULTILINE))
        if page_numbers_found >= 3:
            results.append(check(
                True,
                f"Оглавление заполнено (найдено {page_numbers_found}+ строк с номерами страниц)"
            ))
        else:
            results.append(check(
                False,
                "Оглавление заполнено текстом, но без типичных номеров страниц в конце строк. "
                "Проверь в Word — возможно, нужен F9 для автогенерации.",
                severity="warning"
            ))

    return results


def check_chapter_conclusions(doc: Document) -> list:
    """Проверка: в каждой главе есть «Выводы по Главе X».

    Методичка МПГУ требует завершать каждую главу отдельным разделом
    с выводами. Типичные формулировки: «Выводы по Главе I», «Выводы по
    первой главе», «Выводы по Главе 1». Ищем все три варианта.
    """
    results = []

    # Сначала считаем количество глав (через тот же детектор, что check_chapter_lengths)
    chapter_count = 0
    for p in doc.paragraphs:
        if _looks_like_chapter_heading(p, p.text.strip()):
            chapter_count += 1

    if chapter_count == 0:
        return [check(True, "Главы не найдены — проверка выводов пропущена", severity="info")]

    # Теперь ищем все «Выводы по Главе...»
    # Варианты: «Выводы по Главе I», «Выводы по Главе 1», «Выводы по первой главе»
    full_text = "\n".join(p.text for p in doc.paragraphs).lower()
    conclusions_re = re.compile(
        r"\bвыводы\s+по\s+(?:главе\s+[ivxlcm\d]+|первой\s+главе|второй\s+главе|третьей\s+главе)\b",
        re.IGNORECASE,
    )
    matches = conclusions_re.findall(full_text)

    if len(matches) >= chapter_count:
        results.append(check(
            True,
            f"Найдено {len(matches)} блоков «Выводы по Главе» на {chapter_count} глав(ы) — достаточно"
        ))
    elif len(matches) > 0:
        results.append(check(
            False,
            f"Найдено {len(matches)} блоков «Выводы по Главе», а глав — {chapter_count}. "
            f"Если утверждённый план или научрук требуют выводы по каждой главе, "
            f"добавь недостающие блоки.",
            severity="warning"
        ))
    else:
        results.append(check(
            False,
            f"Ни одного блока «Выводы по Главе X» не найдено (глав в работе: {chapter_count}). "
            f"Это общеакадемическая конвенция (методичка МПГУ напрямую не требует, "
            f"но практически все кафедры её ожидают). Добавь короткий блок «Выводы по Главе N» "
            f"в конце каждой главы — 3-5 тезисов на 0.5 страницы.",
            severity="warning"
        ))

    return results


def check_pilot_sample_size(doc: Document, profile: str = "generic") -> list:
    """Эвристически проверяет размер выборки пилота.

    В базовой методичке порог 5 человек относится к частной образовательной
    практике. Для других пилотов минимум задаёт программа или метод проверки.
    """
    results = []
    full_text = " ".join(p.text for p in doc.paragraphs)

    private_practice = bool(re.search(
        r"частн\w*\s+практик|репетитор", full_text, re.IGNORECASE
    ))

    # Слово «пилот/апробация/выборка» рядом с числом
    patterns = [
        # Частная практика: допускаем более длинное описание между контекстом и числом.
        r"(?:частн\w*\s+практик|репетитор)[^\d\n]{0,200}?(\d{1,3})\s*(?:человек|участник|респондент|школьник|студент|обучающ|учащ|пользовател)",
        # Любые символы (тире, запятые, слова) между «пилот/апробация» и числом
        r"(?:пилот\w*|апробаци\w+|эксперимент\w*)[^\d\n]{0,120}?(\d{1,3})\s*(?:человек|участник|респондент|школьник|студент|обучающ|учащ|пользовател)",
        # Число перед ключевым словом
        r"(\d{1,3})\s*(?:человек|участник|респондент|школьник|студент|обучающ|учащ|пользовател)[^\d\n]{0,120}?(?:пилот\w*|апробаци\w+|эксперимент\w*)",
        # «выборка … N [учащ/студент/…]»
        r"выборк\w+[^\d\n]{0,30}?(\d{1,3})\s*(?:человек|участник|респондент|школьник|студент|обучающ|учащ)",
    ]

    found_numbers = []
    for pat in patterns:
        for m in re.finditer(pat, full_text, re.IGNORECASE):
            n = int(m.group(1))
            if 1 <= n <= 500:
                found_numbers.append(n)

    if not found_numbers:
        if profile == "mpgu-09-project":
            results.append(check(
                False,
                "Для проектной ВКР 09.03.02 не найдено конкретное число участников "
                "пилота. Укажи, где, когда и с кем проведён тестовый запуск. Для "
                "частной образовательной практики требуется не менее 5 участников; "
                "для других баз методичка числовой минимум не задаёт.",
                severity="warning",
            ))
            return results
        results.append(check(
            True,
            "Конкретное число участников пилота не найдено — проверка пропущена. "
            "Для частной образовательной практики базовая методичка требует не "
            "менее 5 человек; в остальных случаях проверь профиль программы.",
            severity="info"
        ))
        return results

    min_n = min(found_numbers)
    if private_practice and min_n < 5:
        results.append(check(
            False,
            f"Для пилота в частной практике обнаружена выборка {min_n} человек. "
            f"Базовая методичка требует не менее 5 участников для этого случая.",
            severity="error"
        ))
    elif min_n < 5:
        results.append(check(
            True,
            f"Выборка пилота: {min_n} человек. Универсальный минимум методичкой "
            f"не задан; обоснуй размер методом проверки и сверь с кафедрой.",
            severity="info"
        ))
    else:
        results.append(check(
            True,
            f"Выборка пилота: {min_n}+ человек; числовой порог сверь с профилем программы",
            severity="info"
        ))

    return results


def check_pedagogical_frame(doc: Document, profile: str = "generic") -> list:
    """Проверяет образовательную рамку с учётом выбранного профиля."""
    results = []

    full_text = "\n".join(p.text for p in doc.paragraphs).lower()

    # Маркеры нужны для классификации контекста, а не для универсального запрета.
    pedagogical_markers = [
        "целевая аудитория",
        "учащи",     # учащиеся, учащихся
        "обучающи",  # обучающиеся, обучающихся
        "школьник",
        "студент",
        "преподавател",
        "дидактическ",
        "образовательн",  # образовательный, образовательная, образовательные
        "учебн",    # учебный, учебная, учебное
        "апробаци",  # апробация, апробации
        "методическ",
        "педагогическ",
        "дистанционн",  # дистанционное обучение
        "пре-пост",
        "пост-тест",
        "пре-тест",
        "усвоени",  # усвоение материала
    ]

    found = [m for m in pedagogical_markers if m in full_text]

    if len(found) >= 5:
        results.append(check(
            True,
            f"Педагогический контекст есть ({len(found)} маркеров: {', '.join(found[:5])}…)"
        ))
    elif len(found) >= 2:
        results.append(check(
            profile != "mpgu-09-project",
            f"Есть отдельные образовательные маркеры ({', '.join(found)}). "
            f"Для проектной ВКР 09.03.02 должны быть явно описаны образовательный "
            f"продукт, целевая аудитория, методические основания и результаты пилота.",
            severity="warning" if profile == "mpgu-09-project" else "info"
        ))
    else:
        results.append(check(
            profile != "mpgu-09-project",
            "Образовательный контекст не выражен. В профиле mpgu-09-project "
            "методичка 09.03.02 требует образовательный продукт, целевую аудиторию "
            "и методическое обоснование. Для generic и mpgu-09-regular эта "
            "эвристика не создаёт ошибку.",
            severity="error" if profile == "mpgu-09-project" else "info"
        ))

    return results


def check_mpgu_09_profile(doc: Document, profile: str = "generic") -> list:
    """Проверяет специальные требования методички 09.03.02 к проектной ВКР."""
    if profile == "generic":
        return [check(
            True,
            "Универсальный профиль: специальные требования 09.03.02 не применены",
            severity="info",
        )]
    if profile == "mpgu-09-regular":
        return [check(
            True,
            "Обычная ВКР 09.03.02: фиксированное число глав и обязательный пилот "
            "методичкой не установлены",
            severity="info",
        )]

    results = []
    chapter_headings = [
        p.text.strip()
        for p in doc.paragraphs
        if _looks_like_chapter_heading(p, p.text.strip())
    ]
    results.append(check(
        len(chapter_headings) == 3,
        f"Обнаружено глав: {len(chapter_headings)}; для проектной ВКР 09.03.02 "
        "методичка задаёт три главы: теоретическую, аналитическую и проектную. "
        "Иная структура допустима только по утверждённому плану научного руководителя.",
        severity="error",
    ))

    full_text = "\n".join(p.text for p in doc.paragraphs).lower()
    pilot_found = bool(re.search(
        r"\b(?:пилот\w*|апробаци\w*|тестов\w*\s+внедрен\w*)\b",
        full_text,
        re.IGNORECASE,
    ))
    results.append(check(
        pilot_found,
        "Описание пилотирования или апробации найдено"
        if pilot_found
        else "Для проектной ВКР 09.03.02 не найдено описание пилотирования, "
             "апробации или тестового внедрения. Технические тесты могут дополнять "
             "пилот, но не заменяют его без согласованного исключения.",
        severity="error",
    ))
    return results


def check_tables(doc: Document) -> list:
    """D7: Проверка оформления таблиц по методичке МПГУ.

    Требования методички:
    - «Таблица N» в правом верхнем углу над заголовком
    - Заголовок таблицы над таблицей, по центру, полужирный, строчные (кроме первой прописной)
    - Без точки в конце заголовка
    - Каждая таблица упомянута в тексте

    Проверяем эвристически по контексту вокруг каждой таблицы в документе.
    """
    results = []

    # Собираем таблицы с индексами абзацев вокруг
    body_elements = list(doc.element.body.iter())
    # Фильтруем служебные таблицы клятвы/последнего листа (структура add_last_page).
    # Критерий: таблица целиком состоит из ячеек с текстом клятвы ИЛИ только с прочерками ИЛИ
    # короткими подписями (ФИО/даты, < 40 симв.) — и находится в самом конце документа.
    # Содержательные таблицы с данными попадают в тело работы и имеют разнообразное содержимое.
    all_tables = doc.tables

    oath_marker = "выполнена мной совершенно самостоятельно"
    dash_marker = "___________________"

    def is_service_table(t):
        # Считаем ячейки с маркерами клятвы/прочерками
        total_cells = 0
        service_cells = 0
        for row in t.rows:
            for cell in row.cells:
                text = cell.text.strip().lower()
                total_cells += 1
                if oath_marker in text:
                    service_cells += 1
                elif dash_marker in text:
                    service_cells += 1
        # Если >60% ячеек — служебные, вся таблица служебная
        return total_cells > 0 and service_cells / total_cells >= 0.6

    tables = [t for t in all_tables if not is_service_table(t)]
    total = len(tables)

    if total == 0:
        results.append(check(
            True,
            "Содержательных таблиц в работе не найдено (в большинстве ВКР-проектов ожидается 1-3 таблицы)",
            severity="info"
        ))
        return results

    full_text = "\n".join(p.text for p in doc.paragraphs)
    paragraphs = list(doc.paragraphs)
    para_texts = [p.text for p in paragraphs]

    # Найти для каждой таблицы ближайший предыдущий текстовый абзац (кандидат на заголовок)
    # Упрощённая эвристика: ищем в тексте N упоминаний "Таблица N" или "табл. N"
    table_label_pattern = re.compile(r"\bТаблица\s+\d+\b|\bтабл\.?\s*\d+\b", re.IGNORECASE)
    labels_found = table_label_pattern.findall(full_text)

    if len(labels_found) < total:
        results.append(check(
            False,
            f"Найдено {total} таблиц в документе, но меток «Таблица N» только "
            f"{len(labels_found)}. Каждая таблица должна быть подписана меткой "
            f"«Таблица N» в правом верхнем углу и упомянута в тексте.",
            severity="warning"
        ))
    else:
        results.append(check(
            True,
            f"Найдено {total} таблиц и {len(labels_found)} меток «Таблица N» — согласовано"
        ))

    # Проверка, что ни одна метка «Таблица N» не заканчивается точкой
    # (методичка: после номера таблицы точка не ставится)
    dot_after_number = re.findall(r"\bТаблица\s+\d+\.\s", full_text)
    if dot_after_number:
        results.append(check(
            False,
            f"После номера таблицы не должна стоять точка (найдено {len(dot_after_number)} случаев). "
            f"Правильно: «Таблица 1» (без точки), заголовок на следующей строке.",
            severity="warning"
        ))

    # Проверка, что в тексте есть упоминание таблиц в одной из типичных форм.
    # Покрываем частые обороты: «в таблице», «из таблицы», «согласно таблице»,
    # «данные таблицы», «таблица N показывает/содержит/демонстрирует/иллюстрирует»,
    # «как видно из таблицы», «см. табл.».
    mentions = re.findall(
        r"\b(?:"
            r"в\s+таблице|"
            r"из\s+таблицы|"
            r"согласно\s+таблице|"
            r"данные\s+таблицы|"
            r"как\s+видно\s+из\s+таблицы|"
            r"см\.\s*табл\.?|"
            r"в\s+табл\.?|"
            r"таблица\s+\d+\s+(?:показывает|содержит|демонстрирует|иллюстрирует|отражает|представляет)"
        r")\s*\d*",
        full_text,
        re.IGNORECASE,
    )
    if len(mentions) == 0 and total > 0:
        results.append(check(
            False,
            f"В тексте работы нет явных упоминаний таблиц («см. табл. 1», «в таблице 2 представлено...»). "
            f"Каждая таблица должна быть упомянута в основном тексте.",
            severity="warning"
        ))

    return results


def check_cross_references(doc: Document) -> list:
    """D8: Проверка соответствия ссылок [N, с. XX] в тексте номерам в списке литературы.

    Типичная ошибка: студент сортирует список литературы после того, как расставил
    ссылки — номера плывут, а ссылки в тексте остаются со старыми номерами.

    Использует общий парсер `_extract_citation_numbers`, который понимает
    ссылки всех типов ([N], [N, с. X], [N; M], [Цит. по: N, с. X]).
    """
    results = []

    # 1. Извлекаем все ссылки из тела текста через общий парсер
    full_text = "\n".join(p.text for p in doc.paragraphs)
    cited_numbers = set(_extract_citation_numbers(full_text))

    # 2. Ищем секцию "Список литературы" и извлекаем номера
    paragraphs = [p.text for p in doc.paragraphs]

    start_idx = None
    for i, p in enumerate(paragraphs):
        p_lower = p.strip().lower()
        if (p_lower.startswith("список использованной литературы")
                or p_lower == "список литературы"
                or p_lower == "библиография"):
            start_idx = i + 1
            break

    if start_idx is None:
        results.append(check(
            False,
            "Раздел «Список литературы» не найден — проверить оформление невозможно.",
            severity="warning"
        ))
        return results

    # Ищем конец (приложения / клятва / конец)
    end_idx = len(paragraphs)
    for i in range(start_idx, len(paragraphs)):
        p_lower = paragraphs[i].strip().lower()
        if p_lower.startswith("приложение") or p_lower.startswith("клятва"):
            end_idx = i
            break

    # Номера в списке литературы — "1. ...", "2. ..."
    listed_numbers = set()
    for para in paragraphs[start_idx:end_idx]:
        para = para.strip()
        if not para:
            continue
        m = re.match(r"^(\d+)\.\s+", para)
        if m:
            listed_numbers.add(int(m.group(1)))

    if not listed_numbers:
        results.append(check(
            False,
            "В списке литературы не найдено пронумерованных записей. "
            "Проверить формат вручную.",
            severity="warning"
        ))
        return results

    # 3. Сравниваем
    missing_in_list = cited_numbers - listed_numbers  # цитированы, но нет в списке
    unused_in_text = listed_numbers - cited_numbers  # в списке есть, но в тексте не упомянуты

    results.append(check(
        True,
        f"Источников в списке: {len(listed_numbers)}. "
        f"Номеров в ссылках по тексту: {len(cited_numbers)}",
        severity="info"
    ))

    if missing_in_list:
        sample = sorted(missing_in_list)[:10]
        more = f" (ещё {len(missing_in_list) - 10})" if len(missing_in_list) > 10 else ""
        results.append(check(
            False,
            f"Ссылки в тексте указывают на номера {sample}{more}, которых НЕТ в списке литературы. "
            f"Вероятно, список был пересортирован после расстановки ссылок. "
            f"Проверь соответствие номеров!",
            severity="error"
        ))

    if unused_in_text:
        sample = sorted(unused_in_text)[:10]
        more = f" (ещё {len(unused_in_text) - 10})" if len(unused_in_text) > 10 else ""
        results.append(check(
            False,
            f"В списке литературы есть источники {sample}{more}, которые НЕ упоминаются в тексте. "
            f"Методичка требует, чтобы все источники из списка были отражены в работе.",
            severity="warning"
        ))

    if not missing_in_list and not unused_in_text:
        results.append(check(
            True,
            "Все ссылки в тексте соответствуют номерам в списке литературы, "
            "и все источники из списка используются в тексте."
        ))

    return results


def check_unresolved_placeholders(doc: Document) -> list:
    """Находит маркеры незаполненного черновика перед финальной сдачей."""
    chunks = [p.text for p in doc.paragraphs]
    chunks.extend(
        cell.text
        for table in doc.tables
        for row in table.rows
        for cell in row.cells
    )
    full_text = "\n".join(chunks)
    patterns = [
        r"\[(?:N|X|XX|XXX)\]",
        r"\[(?:список|вывод|цитата|результат|значение|число|дата|название|ФИО)[^\]]*\]",
        r"\[(?:ПРОВЕРИТЬ|ТРЕБУЕТ\s+УТОЧНЕНИЯ|ВСТАВИТЬ|ЗАПОЛНИТЬ)[^\]]*\]",
        r"\{\{[^{}]{1,100}\}\}",
        r"\b(?:TODO|TBD|FIXME)\b",
    ]
    found = []
    for pattern in patterns:
        found.extend(m.group(0) for m in re.finditer(pattern, full_text, re.IGNORECASE))
    unique = list(dict.fromkeys(found))
    if unique:
        sample = ", ".join(unique[:10])
        suffix = f"; ещё {len(unique) - 10}" if len(unique) > 10 else ""
        return [check(
            False,
            f"Остались маркеры незаполненного черновика: {sample}{suffix}. "
            "Замени их подтверждёнными данными или удали зависимые утверждения.",
            severity="error",
        )]
    return [check(True, "Незаполненные маркеры черновика не найдены", severity="info")]


# ========== ГЛАВНАЯ ФУНКЦИЯ ==========

def validate_vkr(
    docx_path: str,
    verbose: bool = False,
    profile: str = "generic",
) -> dict:
    """Валидация ВКР. Возвращает dict с результатами."""
    if profile not in VALIDATION_PROFILES:
        return {
            "error": f"Неизвестный профиль: {profile}. Допустимо: "
                     f"{', '.join(VALIDATION_PROFILES)}"
        }
    path = Path(docx_path)
    if not path.exists():
        return {"error": f"Файл не найден: {docx_path}"}

    try:
        doc = Document(path)
    except Exception as e:
        return {"error": f"Не удалось открыть файл: {e}"}

    all_checks = {
        "Формат страницы": check_page_size(doc),
        "Поля страницы": check_margins(doc),
        "Шрифт и размер": check_fonts(doc),
        "Междустрочный интервал": check_line_spacing(doc),
        "Отступ первой строки": check_first_line_indent(doc),
        "Цвет шрифта": check_font_color(doc),
        "Содержимое аннотации": check_annotation_content(doc),
        "Структура работы": check_structure(doc),
        "Выводы по главам": check_chapter_conclusions(doc),
        "Оглавление заполнено": check_toc_filled(doc),
        "Незаполненные маркеры": check_unresolved_placeholders(doc),
        "Профиль методички": check_mpgu_09_profile(doc, profile),
        "Образовательный контекст (по профилю)": check_pedagogical_frame(doc, profile),
        "Выборка пилота (для проекта)": check_pilot_sample_size(doc, profile),
        "Длина глав и объём": check_chapter_lengths(doc),
        "Ссылки на таблицы и рисунки": check_figure_table_references(doc),
        "Оформление таблиц": check_tables(doc),
        "Личные местоимения": check_personal_pronouns(doc),
        "ИИ-клише": check_ai_cliches(doc),
        "Ритм абзацев": check_paragraph_rhythm(doc),
        "Начала абзацев": check_consecutive_same_starts(doc),
        "Ссылки на источники": check_citations(doc),
        "Соответствие ссылок и списка литературы": check_cross_references(doc),
        "Оформление фамилий": check_surnames_format(doc),
    }

    # Подсчёт
    total_errors = 0
    total_warnings = 0
    total_passed = 0
    for group in all_checks.values():
        for result in group:
            if result["ok"]:
                total_passed += 1
            elif result["severity"] == "error":
                total_errors += 1
            elif result["severity"] == "warning":
                total_warnings += 1

    return {
        "path": str(path),
        "profile": profile,
        "summary": {
            "passed": total_passed,
            "warnings": total_warnings,
            "errors": total_errors,
        },
        "checks": all_checks,
    }


def print_report(report: dict, verbose: bool = False):
    """Вывод отчёта в консоль."""
    if "error" in report:
        print(f"❌ ОШИБКА: {report['error']}")
        return

    print(f"\n{'='*70}")
    print(f"  ВАЛИДАЦИЯ ВКР: {report['path']}")
    print(f"  ПРОФИЛЬ: {report.get('profile', 'generic')}")
    print(f"{'='*70}\n")

    for group_name, results in report["checks"].items():
        print(f"\n📋 {group_name}")
        print("-" * 70)
        for result in results:
            if result["ok"]:
                icon = "✅"
            elif result["severity"] == "warning":
                icon = "⚠️ "
            else:
                icon = "❌"
            print(f"  {icon} {result['message']}")

    print(f"\n{'='*70}")
    s = report["summary"]
    print(f"  ИТОГО: ✅ {s['passed']}  ⚠️ {s['warnings']}  ❌ {s['errors']}")
    print(f"{'='*70}\n")

    if s["errors"] > 0:
        print("❌ Есть критические ошибки! Работу нужно доработать перед сдачей.")
    elif s["warnings"] > 0:
        print("⚠️  Есть предупреждения. Рекомендуется проверить и улучшить.")
    else:
        print("✅ Работа прошла базовую валидацию!")
    print()


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Валидатор ВКР для МПГУ")
    parser.add_argument("docx_path", help="Путь к .docx файлу ВКР")
    parser.add_argument("--verbose", "-v", action="store_true", help="Подробный вывод")
    parser.add_argument("--json", action="store_true", help="Вывод в JSON")
    parser.add_argument(
        "--profile",
        choices=VALIDATION_PROFILES,
        default="generic",
        help=(
            "Профиль требований: generic, обычная ВКР 09.03.02 или "
            "проектная ВКР 09.03.02"
        ),
    )
    args = parser.parse_args()

    report = validate_vkr(args.docx_path, args.verbose, args.profile)

    if args.json:
        # Сериализуем отчёт в JSON
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print_report(report, args.verbose)


if __name__ == "__main__":
    main()
