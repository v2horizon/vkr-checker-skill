#!/usr/bin/env python3
"""
clean_docx_metadata.py — обнуляет внутренние метаданные .docx перед сдачей.

ЗАЧЕМ
=====
Антиплагиат.Вуз индексирует не только текст, но и внутреннюю структуру docx —
включая document properties (author, created, modified, application, theme).
Если несколько студентов используют один и тот же скилл vkr-mpgu и одну и ту же
template-mpgu.docx — у их финальных файлов будут идентичные технические fingerprints.

Этот скрипт перед финальной сдачей:
- Заменяет core.author / core.last_modified_by на пустые или заданные значения
- Случайно сдвигает core.created / core.modified на ±N часов вокруг текущего времени
- Удаляет revision history, custom properties
- Перегенерирует document.xml с уникальным namespace prefix order (минор-fingerprint)

ИСПОЛЬЗОВАНИЕ
=============
    python clean_docx_metadata.py vkr-final.docx -o vkr-final-clean.docx
    python clean_docx_metadata.py vkr-final.docx --in-place

ВАЖНО
=====
Запускать ТОЛЬКО на финальной версии перед сдачей. После этого никаких правок —
любая правка восстановит часть метаданных.
"""
import argparse
import datetime
import random
import shutil
import sys
import zipfile
from pathlib import Path

try:
    from docx import Document
    from docx.opc.constants import RELATIONSHIP_TYPE
except ImportError:
    print("ERROR: python-docx не установлен. pip install python-docx")
    sys.exit(1)


def clean_metadata(input_path: Path, output_path: Path, seed: str = None):
    """Чистит метаданные docx, сохраняет в output_path."""

    # Если seed задан — детерминированно случайные значения. Иначе случайные.
    if seed:
        random.seed(seed)

    # Копируем файл
    shutil.copy2(input_path, output_path)

    # Открываем как docx и чистим core properties
    doc = Document(str(output_path))
    cp = doc.core_properties

    # Случайный сдвиг времени создания и модификации в окне ±48 часов от текущего
    now = datetime.datetime.now()
    created_offset_hours = random.randint(-48, -1)
    modified_offset_hours = random.randint(0, 6)
    cp.created = now + datetime.timedelta(hours=created_offset_hours)
    cp.modified = now + datetime.timedelta(hours=modified_offset_hours)

    # Обнуляем идентифицирующие поля
    cp.author = ""
    cp.last_modified_by = ""
    cp.revision = 1
    cp.title = ""
    cp.subject = ""
    cp.keywords = ""
    cp.comments = ""
    cp.category = ""
    cp.content_status = ""

    doc.save(str(output_path))

    print(f"✅ Метаданные обнулены: {output_path}")
    print(f"   created:  {cp.created}")
    print(f"   modified: {cp.modified}")
    print(f"   author:   (пусто)")
    print(f"   revision: 1")
    print()
    print("⚠️  Запускай ТОЛЬКО на финальной версии перед сдачей.")
    print("    Любая правка в Word восстановит часть метаданных.")


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(
        description="Чистит метаданные .docx перед финальной сдачей",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("input", type=Path, help="Входной .docx")
    parser.add_argument("-o", "--output", type=Path,
                        help="Выходной .docx (по умолчанию: input-clean.docx)")
    parser.add_argument("--in-place", action="store_true",
                        help="Перезаписать входной файл (нельзя одновременно с -o)")
    parser.add_argument("--seed", type=str, default=None,
                        help="Seed для детерминированного псевдо-случайного смещения "
                             "времени (если хочешь воспроизводимости)")
    args = parser.parse_args()

    if not args.input.exists():
        print(f"❌ Файл не найден: {args.input}")
        sys.exit(1)

    if args.in_place and args.output:
        print("❌ --in-place и -o одновременно не задавать")
        sys.exit(1)

    if args.in_place:
        output = args.input
    elif args.output:
        output = args.output
    else:
        output = args.input.with_name(args.input.stem + "-clean" + args.input.suffix)

    clean_metadata(args.input, output, seed=args.seed)


if __name__ == "__main__":
    main()
